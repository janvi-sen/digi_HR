from rest_framework import serializers
from .models import Epic
from django.contrib.auth import get_user_model

User = get_user_model()

class EpicSerializer(serializers.ModelSerializer):
    """
    Serializer for Epic model with CRUD operations
    """
    class Meta:
        model = Epic
        fields = [
            'id', 'name', 'description', 'tasks', 'status',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, data):
        """Validate epic dates and hours"""
        start_date = data.get('start_date')
        due_date = data.get('due_date')
        estimated_hours = data.get('estimated_hours')
        actual_hours = data.get('actual_hours')

        if start_date and due_date and start_date > due_date:
            raise serializers.ValidationError("Due date must be after start date")

        if estimated_hours is not None and estimated_hours < 0:
            raise serializers.ValidationError("Estimated hours cannot be negative")

        if actual_hours is not None and actual_hours < 0:
            raise serializers.ValidationError("Actual hours cannot be negative")

        return data

class EpicListSerializer(serializers.ModelSerializer):
    """
    Lightweight serializer for epic lists
    """
    class Meta:
        model = Epic
        fields = [
            'id', 'name', 'status', 'created_at'
        ] 