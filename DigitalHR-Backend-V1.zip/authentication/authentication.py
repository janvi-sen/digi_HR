from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken
from django.contrib.auth import get_user_model
from rest_framework import exceptions
from django.conf import settings

User = get_user_model()


class ActiveUserJWTAuthentication(JWTAuthentication):
    """
    Custom JWT Authentication that checks if the user is active
    """
    
    def get_user(self, validated_token):
        """
        Override get_user to check if user is active
        """
        try:
            # Get the user ID claim from settings
            user_id_claim = settings.SIMPLE_JWT.get('USER_ID_CLAIM', 'user_id')
            user_id = validated_token[user_id_claim]
        except KeyError:
            raise InvalidToken("Token contained no recognizable user identification")

        try:
            user = User.objects.get(**{User.USERNAME_FIELD: user_id})
        except User.DoesNotExist:
            raise InvalidToken("User not found")

        # Check if user is active
        if not user.active:
            raise exceptions.AuthenticationFailed("User account is deactivated")

        return user 