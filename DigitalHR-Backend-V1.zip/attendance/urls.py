from django.urls import path
from . import views

app_name = 'attendance'

urlpatterns = [
    # Clock in/out URLs
    path('clock-in/', views.clock_in, name='clock_in'),
    path('clock-out/', views.clock_out, name='clock_out'),
    
    # Attendance list URL (enhanced with all entry types)
    path('attendance/', views.list_attendance, name='list_attendance'),
    path('calendar/', views.attendance_calendar, name='attendance_calendar'),
    path('weekly-attendance/', views.get_weekly_attendance, name='get_weekly_attendance'),
    path('clock-in-status/', views.get_clock_in_status, name='get_clock_in_status'),
    
    # Task URLs
    path('tasks/', views.list_tasks, name='list_tasks'),
    path('tasks/grouped/', views.get_grouped_tasks, name='get_grouped_tasks'),
    path('tasks/create/', views.create_task, name='create_task'),
    path('tasks/<int:task_id>/update/', views.update_task, name='update_task'),
    
    
] 