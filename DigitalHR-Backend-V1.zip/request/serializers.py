import uuid
from rest_framework import serializers
from .models import Leave, WFH, Reimbursement, TravelRequest, EmergencyFundRequest, CompOffCreditRequest, Complaint, ComplaintAttachment, Separation, DevicesPeripherals, IPPatentSupportRequest, IPPatentSupportAttachment
from employees.models import Employee
from django.utils import timezone
from datetime import datetime

class LeaveSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    designation = serializers.SerializerMethodField()
    available_leaves = serializers.SerializerMethodField()
    applied_days = serializers.SerializerMethodField()
    applied_dates = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    class Meta:
        model = Leave
        fields = [
            'id', 'employee', 'employee_name', 'designation',
            'leave_type', 'from_date', 'to_date', 'applied_days',
            'applied_dates', 'description', 'status', 'available_leaves',
            'created_at', 'approved_at', 'approved_by', 'comments', 'employee_profile_photo', 'documents'
        ]
        read_only_fields = ['employee', 'status', 'approved_at', 'approved_by', 'comments']
    
    def get_employee_name(self, obj):
        return f"{obj.employee.full_name}"
    
    def get_designation(self, obj):
        return obj.employee.designation
    
    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url
    
    def get_available_leaves(self, obj):
        employee = obj.employee
        return {
            'PL': employee.leaves_allotted['PL'] - employee.leaves_taken['PL'],
            'SL': employee.leaves_allotted['SL'] - employee.leaves_taken['SL'],
            'CL': employee.leaves_allotted['CL'] - employee.leaves_taken['CL'],
            'WFH': employee.leaves_allotted['WFH'] - employee.leaves_taken['WFH']
        }
    def get_applied_days(self, obj):
        return (obj.to_date - obj.from_date).days + 1
    
    def get_applied_dates(self, obj):
        return {
            'from_date': obj.from_date.strftime('%d %b %Y'),
            'to_date': obj.to_date.strftime('%d %b %Y')
        }
    def validate(self, data):
        # Validate dates
        from_date = data.get('from_date')
        to_date = data.get('to_date')
        
        if from_date and to_date:
            # Convert string dates to datetime objects if they're strings
            if isinstance(from_date, str):
                from_date = datetime.strptime(from_date, '%Y-%m-%d').date()
            if isinstance(to_date, str):
                to_date = datetime.strptime(to_date, '%Y-%m-%d').date()
            
            # Check if from_date is not in the past
            if from_date < timezone.now().date():
                raise serializers.ValidationError("From date cannot be in the past")
            
            # Check if to_date is not before from_date
            if to_date < from_date:
                raise serializers.ValidationError("To date cannot be before from date")
            
            # Check if leave duration is not more than 30 days
            duration = (to_date - from_date).days + 1
            if duration > 30:
                raise serializers.ValidationError("Leave duration cannot exceed 30 days")
            
            # Check for overlapping leaves
            employee = self.context.get('employee')
            if employee:
                self.validate_overlapping_leaves(from_date, to_date, employee)
        
        # Validate leave type
        leave_type = data.get('leave_type')
        if leave_type and leave_type not in ['CL', 'SL', 'PL', 'HD']:
            raise serializers.ValidationError("Invalid leave type. Must be one of: CL, SL, PL, HD")
        
        return data
    
    # def validate_leave_type(self, value):
    #     if value not in ['CL', 'SL', 'PL']:
    #         raise serializers.ValidationError("Invalid leave type. Must be one of: CL, SL, PL")
    #     return value
    
    # def validate_from_date(self, value):
    #     if value < timezone.now().date():
    #         raise serializers.ValidationError("From date cannot be in the past")
    #     return value
    
    # def validate_to_date(self, value):
    #     from_date = self.initial_data.get('from_date')
    #     if from_date:
    #         if isinstance(from_date, str):
    #             from_date = datetime.strptime(from_date, '%Y-%m-%d').date()
    #         if value < from_date:
    #             raise serializers.ValidationError("To date cannot be before from date")
    #     return value

    def validate_available_leaves(self, obj):
        employee = obj.employee
        leave_type = obj.leave_type
        days_requested = (obj.to_date - obj.from_date).days + 1
        print(f'days requested: {days_requested}')
        if leave_type == 'CL':
            if employee.leaves_allotted['CL'] - employee.leaves_taken['CL'] < days_requested:
                raise serializers.ValidationError("Not enough CL leaves available")
        elif leave_type == 'SL':
            if employee.leaves_allotted['SL'] - employee.leaves_taken['SL'] < days_requested:
                raise serializers.ValidationError("Not enough SL leaves available")
        elif leave_type == 'PL':
            if employee.leaves_allotted['PL'] - employee.leaves_taken['PL'] < days_requested:
                raise serializers.ValidationError("Not enough PL leaves available")
        return obj
    
    

class WFHSerializer(serializers.ModelSerializer):
    # employee_name = serializers.SerializerMethodField()
    duration = serializers.SerializerMethodField()
    employee_name = serializers.SerializerMethodField()
    designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    available_wfh = serializers.SerializerMethodField()
    class Meta:
        model = WFH
        fields = [
            'id', 'status', 'from_date', 'to_date', 'description',
            'comments', 'approved_at',
            'approved_by', 'created_at', 'updated_at', 'duration', 'employee_profile_photo', 'employee_name', 'designation', 'available_wfh'
        ]
        read_only_fields = ['id', 'status', 'approved_at', 'approved_by', 'created_at', 'updated_at']

    # def get_employee_name(self, obj):
    #     return f"{obj.employee.full_name}"
    
    def get_duration(self, obj):
        return (obj.to_date - obj.from_date).days + 1
    
    def validate(self, data):
        if data.get('from_date') and data.get('to_date'):
            if data['from_date'] > data['to_date']:
                raise serializers.ValidationError("End date must be after start date")
        return data

    def get_employee_name(self, obj):
        return f"{obj.employee.full_name}"
    
    def get_designation(self, obj):
        return obj.employee.designation
    
    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url
    
    def get_available_wfh(self, obj):
        employee = obj.employee
        return {
            'WFH': employee.leaves_allotted['WFH'] - employee.leaves_taken['WFH']
        }
    
class ReimbursementSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()

    project_name = serializers.CharField(source='project.name', read_only=True)
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    
    
    class Meta:
        model = Reimbursement
        fields = [
            'id', 'reimbursement_id', 'category', 'project', 'project_name', 'date', 'amount',
            'description', 'status', 'employee_name', 'employee', 'employee_designation',
            'employee_profile_photo', 'approved_at', 'approved_by', 'comments',
            'created_at', 'updated_at', 'bill_receipt_url', 'payment_receipt_url'
        ]
        read_only_fields = ['id', 'employee', 'status', 'approved_at', 'approved_by', 'created_at', 'updated_at']
    
    # employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    def get_employee_name(self, obj):
        return f"{obj.employee.full_name}"
        

    def get_employee_designation(self, obj):
        return obj.employee.designation

    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url

class TravelRequestSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    project_name = serializers.CharField(source='project.name', read_only=True)
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    class Meta:
        model = TravelRequest
        fields = [
            'id', 'subject', 'from_date', 'to_date', 'travel_location', 'project', 'project_name',
            'mode_of_transport', 'estimated_expense', 'status', 'employee_name', 'employee',
            'approved_at', 'approved_by', 'comments', 'employee_designation',
            'employee_profile_photo', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'status', 'approved_at', 'approved_by', 'created_at', 'updated_at', 'employee']

    def get_employee_name(self, obj):
        return f"{obj.employee.full_name}"
    
    def get_employee_designation(self, obj):
        return obj.employee.designation

    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url

    def validate(self, data):
        if data.get('from_date') and data.get('to_date'):
            if data['from_date'] > data['to_date']:
                raise serializers.ValidationError("End date must be after start date")
        return data

class EmergencyFundRequestSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    
    class Meta:
        model = EmergencyFundRequest
        fields = [
            'id', 'amount_requested', 'reason', 'fund_needed_date',
            'fund_repayment_date', 'repayment_plan', 'status', 'approved_at',
            'approved_by', 'comments', 'created_at', 'updated_at', 'employee_name',
            'employee_designation', 'employee_profile_photo'
        ]
        read_only_fields = ['id', 'status', 'approved_at', 'approved_by', 'created_at', 'updated_at']

    def get_employee_name(self, obj):
        return f"{obj.employee.full_name}"
    
    def get_employee_designation(self, obj):
        return obj.employee.designation

    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url

class CompOffCreditRequestSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    project_name = serializers.CharField(source='project.name', read_only=True)
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    available_comp_off_credits = serializers.SerializerMethodField()
    class Meta:
        model = CompOffCreditRequest
        fields = [
            'id', 'request_type', 'date', 'project', 'project_name',
            'reason', 'status',  'approved_at', 'approved_by', 'comments',
            'created_at', 'updated_at', 'employee_name', 'employee_designation',
            'employee_profile_photo', 'available_comp_off_credits'
        ]
        read_only_fields = ['id', 'status', 'approved_at', 'approved_by', 'created_at', 'updated_at']

    def get_employee_name(self, obj):
        return f"{obj.employee.full_name}"
    
    def get_employee_designation(self, obj):
        return obj.employee.designation

    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url
    
    def get_available_comp_off_credits(self, obj):
        cl_available = obj.employee.leaves_allotted['CL'] - obj.employee.leaves_taken['CL']

        return cl_available

class ComplaintAttachmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ComplaintAttachment
        fields = ['id', 'file_url', 'file_name', 'file_type', 'file_size', 'created_at']
        read_only_fields = ['id', 'created_at']

class ComplaintCreateSerializer(serializers.ModelSerializer):
    attachments = ComplaintAttachmentSerializer(many=True, required=False, read_only=True)

    class Meta:
        model = Complaint
        fields = ['id', 'title', 'date', 'description', 'attachments']
        read_only_fields = ['id', 'attachments']

    def validate(self, data):
        # Only title, date, and description are required
        errors = {}
        for field in ['title', 'date', 'description']:
            if not data.get(field):
                errors[field] = f"{field} is required."
        if errors:
            raise serializers.ValidationError(errors)
        return data

class ComplaintListSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    employee_email = serializers.SerializerMethodField()
    attachment_count = serializers.SerializerMethodField()
    attachment_urls = serializers.SerializerMethodField()
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    class Meta:
        model = Complaint
        fields = [
            'id', 'employee', 'employee_name', 'employee_email', 'title', 
            'date', 'description', 'status', 'priority', 'attachment_count',
            'attachment_urls', 'created_at', 'updated_at', 'employee_designation', 'employee_profile_photo'
        ]
        read_only_fields = ['id', 'employee', 'created_at', 'updated_at']
    
    def get_employee_name(self, obj):
        return obj.employee.full_name
    
    def get_employee_email(self, obj):
        return obj.employee.email
    
    def get_employee_designation(self, obj):
        return obj.employee.designation

    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url
    
    def get_attachment_count(self, obj):
        return obj.attachments.count()
    
    def get_attachment_urls(self, obj):
        """Get list of attachment URLs for the complaint"""
        return [attachment.file_url for attachment in obj.attachments.all()]

class SeparationCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Separation
        fields = [
            'id', 'preferred_date', 'reason', 'comments', 
            'notice_period_compliance', 'resignation_letter_url'
        ]
        read_only_fields = ['id']

    def validate(self, data):
        # Validate that preferred_date is not in the past
        preferred_date = data.get('preferred_date')
        if preferred_date and preferred_date < timezone.now().date():
            raise serializers.ValidationError("Preferred date cannot be in the past")
        
        # Validate reason is provided
        reason = data.get('reason')
        if not reason:
            raise serializers.ValidationError("Reason is required")
        
        return data 

class DevicesPeripheralsCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DevicesPeripherals
        fields = [
            'id', 'requested_item', 'purpose', 'preferred_brand', 
            'preferred_quantity', 'urgency', 'comments', 'delivery_location'
        ]
        read_only_fields = ['id']

    def validate(self, data):
        # Validate that preferred_quantity is positive
        preferred_quantity = data.get('preferred_quantity')
        if preferred_quantity and preferred_quantity <= 0:
            raise serializers.ValidationError("Preferred quantity must be greater than 0")
        
        # Validate that requested_item is provided
        requested_item = data.get('requested_item')
        if not requested_item:
            raise serializers.ValidationError("Requested item is required")
        
        return data


class DevicesPeripheralsListSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    employee_email = serializers.SerializerMethodField()
    delivery_location_name = serializers.SerializerMethodField()
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    class Meta:
        model = DevicesPeripherals
        fields = [
            'id', 'employee', 'employee_name', 'employee_email', 'requested_item',
            'purpose', 'preferred_brand', 'preferred_quantity', 'urgency', 'status',
            'comments', 'delivery_location', 'delivery_location_name',
            'created_at', 'updated_at', 'employee_designation', 'employee_profile_photo'
        ]
        read_only_fields = ['id', 'employee', 'created_at', 'updated_at']
    
    def get_employee_name(self, obj):
        return obj.employee.full_name
    
    def get_employee_email(self, obj):
        return obj.employee.email
    
    def get_delivery_location_name(self, obj):
        return obj.delivery_location.location_name if obj.delivery_location else None

    def get_employee_designation(self, obj):
        return obj.employee.designation
    
    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url


class SeparationListSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    employee_email = serializers.SerializerMethodField()
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    class Meta:
        model = Separation
        fields = [
            'id', 'employee', 'employee_name', 'employee_email', 'preferred_date',
            'reason', 'status', 'comments', 'notice_period_compliance',
            'resignation_letter_url', 'created_at', 'updated_at', 'employee_designation', 'employee_profile_photo'
        ]
        read_only_fields = ['id', 'employee', 'created_at', 'updated_at']
    
    def get_employee_name(self, obj):
        return obj.employee.full_name
    
    def get_employee_email(self, obj):
        return obj.employee.email 
    
    def get_employee_designation(self, obj):
        return obj.employee.designation
    
    def get_employee_profile_photo(self, obj):
        return obj.employee.profile_photo_url

class IPPatentSupportAttachmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = IPPatentSupportAttachment
        fields = ['id', 'file_url', 'file_name', 'file_type', 'file_size', 'created_at']
        read_only_fields = ['id', 'created_at']

class IPPatentSupportRequestCreateSerializer(serializers.ModelSerializer):
    team_member_emails = serializers.CharField(
        write_only=True,
        required=False,
        help_text="Comma-separated list of team member email addresses"
    )
    attachments = IPPatentSupportAttachmentSerializer(many=True, required=False, read_only=True)
    
    class Meta:
        model = IPPatentSupportRequest
        fields = ['project_name', 'description', 'protection_type', 'team_member_emails', 'attachments', 'priority_date']

    def validate_project_name(self, value):
        """Validate project name is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Project name cannot be empty")
        return value.strip()

    def validate_description(self, value):
        """Validate description is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Description cannot be empty")
        return value.strip()

    def validate_priority_date(self, value):
        """Validate priority date is not in the past"""
        if value and value < timezone.now().date():
            raise serializers.ValidationError("Priority date cannot be in the past")
        return value

    def validate_team_member_emails(self, value):
        """Validate team member emails and convert to employees"""
        if not value:
            return []
        
        # Split by comma and clean up
        email_list = [email.strip() for email in value.split(',') if email.strip()]
        
        employees = []
        invalid_emails = []
        
        for email in email_list:
            try:
                employee = Employee.objects.get(email=email)
                employees.append(employee)
            except Employee.DoesNotExist:
                invalid_emails.append(email)
        
        if invalid_emails:
            raise serializers.ValidationError(f"Employees not found for emails: {', '.join(invalid_emails)}")
        
        return employees

    def create(self, validated_data):
        team_member_emails = validated_data.pop('team_member_emails', [])
        request = self.context['request']
        
        # Create the IP Patent Support Request
        instance = IPPatentSupportRequest.objects.create(
            created_by=request.user.employee_profile,
            **validated_data
        )
        
        # Add team members
        if team_member_emails:
            instance.team_members.set(team_member_emails)
        
        return instance


class IPPatentSupportRequestUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = IPPatentSupportRequest
        fields = ['status', 'comments']

    def validate_status(self, value):
        """Validate status is valid"""
        valid_statuses = ['pending', 'approved', 'rejected']
        if value not in valid_statuses:
            raise serializers.ValidationError(f"Status must be one of: {', '.join(valid_statuses)}")
        return value


class IPPatentSupportRequestListSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(source='created_by.full_name', read_only=True)
    created_by_email = serializers.CharField(source='created_by.email', read_only=True)
    protection_type_display = serializers.CharField(source='get_protection_type_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    team_members_count = serializers.SerializerMethodField()
    attachments = IPPatentSupportAttachmentSerializer(many=True, read_only=True)
    attachment_count = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()
    team_members_details = serializers.SerializerMethodField()
    employee_name = serializers.SerializerMethodField()
    employee_email = serializers.SerializerMethodField()
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()

    class Meta:
        model = IPPatentSupportRequest
        fields = [
            'id', 'project_name', 'description', 'protection_type', 'protection_type_display',
            'status', 'status_display', 'priority_date', 'created_by_name', 'created_by_email',
            'created_by',
            'team_members_count', 'attachments', 'attachment_count', 'created_at', 'updated_at', 'employee_profile_photo', 'employee_name', 'employee_email', 'employee_designation', 'team_members_details'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_employee_name(self, obj):
        return obj.created_by.full_name
    
    def get_employee_email(self, obj):
        return obj.created_by.email
    
    def get_employee_designation(self, obj):
        return obj.created_by.designation
    
    def get_employee_profile_photo(self, obj):
        return obj.created_by.profile_photo_url
    
    def get_team_members_count(self, obj):
        return obj.team_members.count()
    
    def get_attachment_count(self, obj):
        return obj.attachments.count()

    def get_team_members_details(self, obj):
        """Return team members with their details"""
        team_members = []
        for member in obj.team_members.all():
            team_members.append({
                'id': member.id,
                'name': member.full_name,
                'email': member.email,
                'designation': member.designation
            })
        return team_members

    def get_attachment_count(self, obj):
        """Get count of attachments"""
        return obj.attachments.count()

class IPPatentSupportRequestSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(source='created_by.full_name', read_only=True)
    created_by_email = serializers.CharField(source='created_by.email', read_only=True)
    approved_by_name = serializers.CharField(source='approved_by.full_name', read_only=True)
    protection_type_display = serializers.CharField(source='get_protection_type_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    team_members_details = serializers.SerializerMethodField()
    attachments = IPPatentSupportAttachmentSerializer(many=True, read_only=True)
    attachment_count = serializers.SerializerMethodField()
    employee_name = serializers.SerializerMethodField()
    employee_email = serializers.SerializerMethodField()
    employee_designation = serializers.SerializerMethodField()
    employee_profile_photo = serializers.SerializerMethodField()


    class Meta:
        model = IPPatentSupportRequest
        fields = [
            'id', 'project_name', 'description', 'protection_type', 'protection_type_display',
            'attachments', 'attachment_count',
            'priority_date', 'status', 'status_display', 'created_by', 'created_by_name',
            'created_by_email', 'created_at', 'updated_at', 'approved_by', 'approved_by_name',
            'approved_at', 'comments', 'employee_name', 'employee_email', 'employee_designation', 'employee_profile_photo', 'team_members_details'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'approved_at']

    def get_employee_name(self, obj):
        return obj.created_by.full_name
    
    def get_employee_email(self, obj):
        return obj.created_by.email
    
    def get_employee_designation(self, obj):
        return obj.created_by.designation
    
    def get_employee_profile_photo(self, obj):
        return obj.created_by.profile_photo_url
    
    def get_team_members_details(self, obj):
        """Return team members with their details"""
        team_members = []
        for member in obj.team_members.all():
            team_members.append({
                'id': member.id,
                'name': member.full_name,
                'email': member.email,
                'designation': member.designation
            })
        return team_members

    def get_attachment_count(self, obj):
        """Get count of attachments"""
        return obj.attachments.count()