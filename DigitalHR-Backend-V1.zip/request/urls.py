from django.urls import path
from .views import (
    get_available_leaves_count, get_pending_requests_count, list_leave_requests, create_leave_request, update_leave_status,
    list_wfh_requests, create_wfh_request, update_wfh_status,
    list_reimbursement_requests, create_reimbursement_request, update_reimbursement_status,
    list_travel_requests, create_travel_request, update_travel_status,
    list_emergency_fund_requests, create_emergency_fund_request, update_emergency_fund_status,
    list_compoff_requests, create_compoff_request, update_compoff_status,
    create_complaint, list_complaints, update_complaint_status, create_separation_request,
    list_devices_peripherals_requests, create_devices_peripherals_request, update_devices_peripherals_status,
    list_separation_requests, update_separation_status, send_request_reminder,
    create_ip_patent_request, list_ip_patent_requests, get_ip_patent_request_detail, update_ip_patent_status, delete_ip_patent_request
)

urlpatterns = [
    # Leave request endpoints
    path('leaves/', list_leave_requests, name='list-leave-requests'),
    path('leaves/create/', create_leave_request, name='create-leave-request'),
    path('leaves/<int:request_id>/update-status/', update_leave_status, name='update-leave-status'),
    
    # WFH request endpoints
    path('wfh/', list_wfh_requests, name='list-wfh-requests'),
    path('wfh/create/', create_wfh_request, name='create-wfh-request'),
    path('wfh/<int:request_id>/update-status/', update_wfh_status, name='update-wfh-status'),
    
    # Reimbursement request endpoints
    path('reimbursements/', list_reimbursement_requests, name='list-reimbursement-requests'),
    path('reimbursements/create/', create_reimbursement_request, name='create-reimbursement-request'),
    path('reimbursements/<int:request_id>/update-status/', update_reimbursement_status, name='update-reimbursement-status'),
    
    # Travel request endpoints
    path('travel/', list_travel_requests, name='list-travel-requests'),
    path('travel/create/', create_travel_request, name='create-travel-request'),
    path('travel/<int:request_id>/update-status/', update_travel_status, name='update-travel-status'),
    
    # Emergency fund request endpoints
    path('emergency-fund/', list_emergency_fund_requests, name='list-emergency-fund-requests'),
    path('emergency-fund/create/', create_emergency_fund_request, name='create-emergency-fund-request'),
    path('emergency-fund/<int:request_id>/update-status/', update_emergency_fund_status, name='update-emergency-fund-status'),
    
    # Comp-off credit request endpoints
    path('compoff/', list_compoff_requests, name='list-compoff-requests'),
    path('compoff/create/', create_compoff_request, name='create-compoff-request'),
    path('compoff/<int:request_id>/update-status/', update_compoff_status, name='update-compoff-status'),

    # Complaint endpoints
    path('complaints/', list_complaints, name='list-complaints'),
    path('complaints/create/', create_complaint, name='create-complaint'),
    path('complaints/<int:complaint_id>/update-status/', update_complaint_status, name='update-complaint-status'),

    # Separation request endpoints
    path('separation/', list_separation_requests, name='list-separation-requests'),
    path('separation/create/', create_separation_request, name='create-separation-request'),
    path('separation/<int:request_id>/update-status/', update_separation_status, name='update-separation-status'),

    # Devices/Peripherals request endpoints
    path('devices-peripherals/', list_devices_peripherals_requests, name='list-devices-peripherals-requests'),
    path('devices-peripherals/create/', create_devices_peripherals_request, name='create-devices-peripherals-request'),
    path('devices-peripherals/<int:request_id>/update-status/', update_devices_peripherals_status, name='update-devices-peripherals-status'),
    
    # Reminder endpoint
    path('request-reminder/', send_request_reminder, name='send-request-reminder'),

    # IP & Patent Support Request CRUD operations
    path('ip-patent/', create_ip_patent_request, name='create_ip_patent_request'),
    path('ip-patent/list/', list_ip_patent_requests, name='list_ip_patent_requests'),
    path('ip-patent/<int:request_id>/', get_ip_patent_request_detail, name='get_ip_patent_request_detail'),
    path('ip-patent/<int:request_id>/update-status/', update_ip_patent_status, name='update_ip_patent_status'),
    path('ip-patent/<int:request_id>/delete/', delete_ip_patent_request, name='delete_ip_patent_request'),
    
    # Get pending requests count
    path('pending-requests-count/', get_pending_requests_count, name='get_pending_requests_count'),
    
    # Get available leaves count
    path('available-leaves-count/', get_available_leaves_count, name='get_available_leaves_count'),
] 