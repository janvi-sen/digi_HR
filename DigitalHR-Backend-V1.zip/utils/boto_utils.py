import boto3
import uuid
import os
from django.conf import settings
from botocore.exceptions import ClientError, NoCredentialsError
import logging
import urllib.parse
import json

logger = logging.getLogger(__name__)

class S3DocumentUploader:
    """
    S3 Document Upload utility class for employee documents
    """
    
    def __init__(self):
        """Initialize S3 client"""
        try:
            self.s3_client = boto3.client(
                's3',
                aws_access_key_id=getattr(settings, 'AWS_ACCESS_KEY_ID', None),
                aws_secret_access_key=getattr(settings, 'AWS_SECRET_ACCESS_KEY', None),
                region_name=getattr(settings, 'AWS_S3_REGION_NAME', 'us-east-1')
            )
            self.bucket_name = getattr(settings, 'AWS_STORAGE_BUCKET_NAME', 'digitalhr-bucket')
        except Exception as e:
            logger.error(f"Error initializing S3 client: {str(e)}")
            self.s3_client = None
            self.bucket_name = None
    
    def upload_document(self, file, email_id, document_type, document_collection, other_prefix = None, file_extension=None):
        """
        Upload document to S3
        """
        if not self.s3_client:
            return False, "S3 client not configured properly"
        try:
            # Get file extension
            if not file_extension:
                file_extension = self._get_file_extension(file.name)
            
            # Generate filename based on document type
            filename = self._generate_filename(document_type, file_extension)
            
            if document_collection == "personal_documents":
                # document type is the document type (PAN_Card, Aadhar_Card, etc.)
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{document_type}/"
            elif document_collection == "leave_supporting_documents":
                # Other prefix is the leave_type
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{document_type}/{other_prefix}/"
            elif document_collection == "selfies":
                # Other prefix is the date
                # Document type is the selfie_type (clock in or clock out)
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{other_prefix}/{document_type}/"
            
            elif document_collection == "reimbursements":
                # Other prefix is the reimbursement_id
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{other_prefix}/{document_type}/"
            
            elif document_collection == "profile_photos":
                # Other prefix is the email_id
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{document_type}/"
            
            elif document_collection == "policies":
                # Other prefix is the policy_code
                prefix = f"sciverse/policies/{document_type}/{other_prefix}/"
            
            elif document_collection == "complaints":
                # Other prefix is the complaint_id
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{other_prefix}/"
            
            elif document_collection == "separation_letters":
                # Other prefix is the separation_id
                prefix = f"sciverse/employees/{email_id}/{document_collection}/"
            
            elif document_collection == "ip_patent_support":
                # Other prefix is the ip_patent_support_id
                prefix = f"sciverse/employees/{email_id}/{document_collection}/{other_prefix}/"
            
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix
            )
            
            if 'Contents' in response:
                # Document exists, use the same path
                existing_key = response['Contents'][0]['Key']
                s3_key = existing_key
            else:
                # Generate new unique ID for this upload
                unique_id = str(uuid.uuid4())
                s3_key = f"{prefix}{unique_id}/{filename}"
            
            # Upload file to S3
            self.s3_client.upload_fileobj(
                file,
                self.bucket_name,
                s3_key,
                ExtraArgs={
                    'ContentType': self._get_content_type(file_extension),
                    'ServerSideEncryption': 'AES256'  # Encrypt files at rest
                }
            )
            
            # Update bucket policy to allow public read access
            bucket_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "PublicReadGetObject",
                        "Effect": "Allow",
                        "Principal": "*",
                        "Action": "s3:GetObject",
                        "Resource": f"arn:aws:s3:::{self.bucket_name}/*"
                    }
                ]
            }
            
            # Convert policy to JSON string
            policy_json = json.dumps(bucket_policy)
            
            # Update bucket policy
            self.s3_client.put_bucket_policy(
                Bucket=self.bucket_name,
                Policy=policy_json
            )
            
            # Generate file URL with URL encoding only for the final URL
            file_url = f"https://{self.bucket_name}.s3.amazonaws.com/{urllib.parse.quote(s3_key, safe='')}"
            
            return True, file_url
            
        except ClientError as e:
            error_message = f"AWS S3 error: {str(e)}"
            logger.error(error_message)
            return False, error_message
        except Exception as e:
            error_message = f"Upload error: {str(e)}"
            logger.error(error_message)
            return False, error_message
    
    def upload_selfie_image(self, file, email_id, selfie_type, date, file_extension=None):
        """
        Upload selfie image to S3
        """
        if not self.s3_client:
            return False, "S3 client not configured properly"
        
        try:
            # Get file extension
            if not file_extension:
                file_extension = self._get_file_extension(file.name)
            
            # Generate filename based on document type
            filename = self._generate_filename(selfie_type, file_extension)
            
            # Check if document of same type exists
            prefix = f"sciverse/employees/{email_id}/selfies/{date}/{selfie_type}/"
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix
            )
            
            if 'Contents' in response:
                # Document exists, use the same path
                existing_key = response['Contents'][0]['Key']
                s3_key = existing_key
            else:
                # Generate new unique ID for this upload
                unique_id = str(uuid.uuid4())
                s3_key = f"{prefix}{unique_id}/{filename}"
            
            # Upload file to S3
            self.s3_client.upload_fileobj(
                file,
                self.bucket_name,
                s3_key,
                ExtraArgs={
                    'ContentType': self._get_content_type(file_extension),
                    'ServerSideEncryption': 'AES256'  # Encrypt files at rest
                }
            )
            
            # Update bucket policy to allow public read access
            bucket_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "PublicReadGetObject",
                        "Effect": "Allow",
                        "Principal": "*",
                        "Action": "s3:GetObject",
                        "Resource": f"arn:aws:s3:::{self.bucket_name}/*"
                    }
                ]
            }
            
            # Convert policy to JSON string
            policy_json = json.dumps(bucket_policy)
            
            # Update bucket policy
            self.s3_client.put_bucket_policy(
                Bucket=self.bucket_name,
                Policy=policy_json
            )
            
            # Generate file URL with URL encoding only for the final URL
            file_url = f"https://{self.bucket_name}.s3.amazonaws.com/{urllib.parse.quote(s3_key, safe='')}"
            
            return True, file_url
            
        except ClientError as e:
            error_message = f"AWS S3 error: {str(e)}"
            logger.error(error_message)
            return False, error_message
        except Exception as e:
            error_message = f"Upload error: {str(e)}"
            logger.error(error_message)
            return False, error_message
    
    
    def upload_employee_document(self, file, email_id, document_type, file_extension=None):
        """
        Upload employee document to S3
        
        Args:
            file: File object to upload
            email_id: Employee email ID
            document_type: Type of document (e.g., 'RESUME', 'PAN_Card', etc.)
            file_extension: Optional file extension (will be extracted from file if not provided)
        
        Returns:
            tuple: (success: bool, file_url: str or error_message: str)
        """
        if not self.s3_client:
            return False, "S3 client not configured properly"
        
        try:
            # Get file extension
            if not file_extension:
                file_extension = self._get_file_extension(file.name)
            
            # Generate filename based on document type
            filename = self._generate_filename(document_type, file_extension)
            
            # Check if document of same type exists
            prefix = f"sciverse/employees/{email_id}/documents/{document_type}/"
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix
            )
            
            if 'Contents' in response:
                # Document exists, use the same path
                existing_key = response['Contents'][0]['Key']
                s3_key = existing_key
            else:
                # Generate new unique ID for this upload
                unique_id = str(uuid.uuid4())
                s3_key = f"{prefix}{unique_id}/{filename}"
            
            # Upload file to S3
            self.s3_client.upload_fileobj(
                file,
                self.bucket_name,
                s3_key,
                ExtraArgs={
                    'ContentType': self._get_content_type(file_extension),
                    'ServerSideEncryption': 'AES256'  # Encrypt files at rest
                }
            )
            
            # Update bucket policy to allow public read access
            bucket_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "PublicReadGetObject",
                        "Effect": "Allow",
                        "Principal": "*",
                        "Action": "s3:GetObject",
                        "Resource": f"arn:aws:s3:::{self.bucket_name}/*"
                    }
                ]
            }
            
            # Convert policy to JSON string
            policy_json = json.dumps(bucket_policy)
            
            # Update bucket policy
            self.s3_client.put_bucket_policy(
                Bucket=self.bucket_name,
                Policy=policy_json
            )
            
            # Generate file URL with URL encoding only for the final URL
            file_url = f"https://{self.bucket_name}.s3.amazonaws.com/{urllib.parse.quote(s3_key, safe='')}"
            
            return True, file_url
            
        except ClientError as e:
            error_message = f"AWS S3 error: {str(e)}"
            logger.error(error_message)
            return False, error_message
        except Exception as e:
            error_message = f"Upload error: {str(e)}"
            logger.error(error_message)
            return False, error_message
    
    def delete_employee_document(self, file_url):
        """
        Delete employee document from S3
        
        Args:
            file_url: Full S3 URL of the file to delete
        
        Returns:
            tuple: (success: bool, message: str)
        """
        if not self.s3_client:
            return False, "S3 client not configured properly"
        
        try:
            # Extract S3 key from URL
            s3_key = self._extract_s3_key_from_url(file_url)
            
            if not s3_key:
                return False, "Invalid S3 file URL"
            
            # Delete object from S3
            self.s3_client.delete_object(
                Bucket=self.bucket_name,
                Key=s3_key
            )
            
            return True, "File deleted successfully"
            
        except ClientError as e:
            error_message = f"AWS S3 delete error: {str(e)}"
            logger.error(error_message)
            return False, error_message
        except Exception as e:
            error_message = f"Delete error: {str(e)}"
            logger.error(error_message)
            return False, error_message
    
    def generate_presigned_url(self, file_url, expiration=3600):
        """
        Generate a presigned URL for private document access
        
        Args:
            file_url: S3 file URL
            expiration: URL expiration time in seconds (default: 1 hour)
        
        Returns:
            tuple: (success: bool, presigned_url: str or error_message: str)
        """
        if not self.s3_client:
            return False, "S3 client not configured properly"
        
        try:
            s3_key = self._extract_s3_key_from_url(file_url)
            
            if not s3_key:
                return False, "Invalid S3 file URL"
            
            presigned_url = self.s3_client.generate_presigned_url(
                'get_object',
                Params={'Bucket': self.bucket_name, 'Key': s3_key},
                ExpiresIn=expiration
            )
            
            return True, presigned_url
            
        except ClientError as e:
            error_message = f"Presigned URL error: {str(e)}"
            logger.error(error_message)
            return False, error_message
    
    def _get_file_extension(self, filename):
        """Extract file extension from filename"""
        return os.path.splitext(filename)[1].lower()
    
    def _generate_filename(self, document_type, file_extension):
        """Generate appropriate filename based on document type"""
        # Convert document type to lowercase for filename
        base_name = document_type.lower().replace('_', '')
        return f"{base_name}{file_extension}"
    
    def _get_content_type(self, file_extension):
        """Get appropriate content type based on file extension"""
        content_types = {
            '.pdf': 'application/pdf',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.doc': 'application/msword',
            '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        }
        return content_types.get(file_extension, 'application/octet-stream')
    
    def _extract_s3_key_from_url(self, file_url):
        """Extract S3 key from full S3 URL"""
        try:
            # Remove the base S3 URL to get the key
            base_url = f"https://{self.bucket_name}.s3.amazonaws.com/"
            if file_url.startswith(base_url):
                return file_url[len(base_url):]
            return None
        except Exception:
            return None


# Singleton instance
s3_uploader = S3DocumentUploader() 