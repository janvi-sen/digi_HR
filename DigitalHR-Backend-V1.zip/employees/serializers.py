from attendance.models import DailyAttendance, DailyTask
from policies.models import OfficeLocations
from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.utils import timezone
from .models import Employee, EmployeeDocument, EmployeeLocation
from utils.general_utils import EmailDomainValidator
from projects.models import Project
from epics.models import Epic
from request.models import WFH, Leave
import requests
from datetime import timedelta
from attendance.models import DailyAttendance
from policies.models import OfficeLocations
import math

def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Calculate distance between two coordinates using Haversine formula
    Returns distance in meters
    """
    # Convert latitude and longitude from degrees to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # Radius of earth in meters
    r = 6371000
    
    return c * r

def get_nearby_office_location(lat_long, max_distance_meters=50):
    """
    Find the nearest office location within the specified distance
    Returns the office location object if found, None otherwise
    """
    if not lat_long:
        return None
    
    try:
        # Parse the lat_long string
        lat_str, lon_str = lat_long.split(',')
        attendance_lat = float(lat_str.strip())
        attendance_lon = float(lon_str.strip())
        
        # Get all active office locations
        office_locations = OfficeLocations.objects.filter(is_active=True)
        
        nearest_location = None
        min_distance = float('inf')
        
        for location in office_locations:
            if location.lat_long:
                try:
                    # Parse office location coordinates
                    office_lat_str, office_lon_str = location.lat_long.split(',')
                    office_lat = float(office_lat_str.strip())
                    office_lon = float(office_lon_str.strip())
                    
                    # Calculate distance
                    distance = calculate_distance(
                        attendance_lat, attendance_lon,
                        office_lat, office_lon
                    )
                    
                    # Check if within max distance and closer than previous
                    if distance <= max_distance_meters and distance < min_distance:
                        min_distance = distance
                        nearest_location = location
                        
                except (ValueError, IndexError):
                    # Skip locations with invalid coordinates
                    continue
        
        return nearest_location
        
    except (ValueError, IndexError):
        # Invalid lat_long format
        return None

User = get_user_model()

# class EmployeeCreateSerializer(serializers.ModelSerializer):
#     """
#     Serializer for creating employee profiles
#     """
#     # password = serializers.CharField(write_only=True, min_length=8, required=False)
#     # confirm_password = serializers.CharField(write_only=True, required=False)
    
#     class Meta:
#         model = Employee
#         fields = [
#             'full_name', 'email', 'mobile_number', 'date_of_birth',
#             'gender', 'address', 'date_of_joining', 'department',
#             'designation', 'emergency_contact_name',
#             'emergency_contact_number', 'emergency_contact_relation',
#             'salary'
#         ]
#         extra_kwargs = {
#             'salary': {'write_only': True},
#         }
    
#     def validate_email(self, value):
#         """Validate email domain and uniqueness"""
#         # Check domain validation
#         is_valid, error_message = EmailDomainValidator.validate_email_domain(value)
#         if not is_valid:
#             raise serializers.ValidationError(error_message)
        
#         # Check if email already exists in User model
#         if User.objects.filter(email_id=value).exists():
#             raise serializers.ValidationError("A user with this email already exists.")
        
#         return value
    
#     def validate_mobile_number(self, value):
#         """Validate mobile number"""
#         # Remove any spaces or special characters
#         clean_number = ''.join(filter(str.isdigit, value))
        
#         # Check if it's a valid Indian mobile number
#         if len(clean_number) != 10 or not clean_number.startswith(('6', '7', '8', '9')):
#             raise serializers.ValidationError("Please enter a valid 10-digit mobile number.")
        
#         return clean_number
    
#     def validate(self, attrs):
#         """Cross-field validation"""
#         password = attrs.get('password')
#         confirm_password = attrs.get('confirm_password')
        
#         if password and confirm_password:
#             if password != confirm_password:
#                 raise serializers.ValidationError("Passwords do not match.")
        
#         return attrs
    
#     def create(self, validated_data):
#         """Create employee and associated user account"""
#         # Create user account first
#         user_data = {
#             'email_id': validated_data['email'],
#             'active': True
#         }
        
#         from django.contrib.auth.hashers import make_password
#         user = User.objects.create(
#             email_id=user_data['email_id'],
#             active=user_data['active']
#         )
        
#         # Create employee profile
#         validated_data['user'] = user
#         employee = Employee.objects.create(**validated_data)
        
#         return employee


class ProjectSerializer(serializers.ModelSerializer):
    epics = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = ['id', 'name', 'status', 'epics']
        
    def get_epics(self, obj):
        epics = obj.epics.all()
        return [{
            'id': epic.id,
            'name': epic.name,
            'status': epic.status
        } for epic in epics]


class EmployeeSerializer(serializers.ModelSerializer):
    """
    Serializer for retrieving and updating employee information
    """
    age = serializers.ReadOnlyField()
    years_of_experience = serializers.ReadOnlyField()
    user_email = serializers.CharField(source='user.email_id', read_only=True)
    profile_photo_display_url = serializers.ReadOnlyField()
    is_verified = serializers.BooleanField(source='user.is_verified', read_only=True)
    is_onboarded = serializers.BooleanField(source='user.is_onboarded', read_only=True)
    active = serializers.BooleanField(source='user.active', read_only=True)
    is_clocked_in = serializers.SerializerMethodField()
    on_leave = serializers.SerializerMethodField()
    projects = serializers.SerializerMethodField()
    reporting_location = serializers.SerializerMethodField()
    class Meta:
        model = Employee
        fields = [
            'id', 'employee_id', 'full_name', 'email', 'mobile_number',
            'date_of_birth', 'age', 'gender', 
            'profile_photo', 'profile_photo_url', 'profile_photo_display_url',
            'date_of_joining', 'years_of_experience', 'department', 'designation', 
            'employment_status', 'is_verified', 'is_onboarded', 'verification_date', 
            'onboarding_date', 'emergency_contact_name',
            'emergency_contact_number', 'emergency_contact_relation',
            'last_login', 'created_at', 'updated_at', 'user_email', 'current_address',
            'permanent_address', 'blood_group', 'is_onboarded', 'active', 'is_clocked_in', 'on_leave',
            'projects', 'total_experience', 'reporting_location'
        ]
        read_only_fields = [
            'id', 'employee_id', 'age', 'years_of_experience',
            'created_at', 'updated_at', 'user_email', 'profile_photo_display_url',
            'is_verified', 'is_onboarded', 'active', 'is_clocked_in', 'on_leave'
        ]
    
    def validate_email(self, value):
        """Validate email domain"""
        is_valid, error_message = EmailDomainValidator.validate_email_domain(value)
        if not is_valid:
            raise serializers.ValidationError(error_message)
        return value
    
    def validate_profile_photo(self, value):
        """Validate profile photo upload"""
        if value:
            # Check file size (max 5MB)
            if value.size > 5 * 1024 * 1024:
                raise serializers.ValidationError("Profile photo size cannot exceed 5MB.")
            
            # Check file extension
            allowed_extensions = ['.jpg', '.jpeg', '.png', '.gif']
            import os
            ext = os.path.splitext(value.name)[1].lower()
            if ext not in allowed_extensions:
                raise serializers.ValidationError(
                    f"File type not allowed. Allowed types: {', '.join(allowed_extensions)}"
                )
        
        return value
    
    def get_is_clocked_in(self, obj):
        """Check if employee is clocked in"""
        return DailyAttendance.objects.filter(employee=obj, is_clocked_out=False, date=timezone.now().date()).exists()
    
    def get_on_leave(self, obj):
        """Check if employee is on leave"""
        from request.models import Leave
        return Leave.objects.filter(employee=obj, status='approved', from_date__lte=timezone.now().date(), to_date__gte=timezone.now().date()).exists()

    def get_projects(self, obj):
        projects = obj.assigned_projects.all()
        return ProjectSerializer(projects, many=True).data

    def get_reporting_location(self, obj):
        if obj.reporting_location:
            return obj.reporting_location.location_name
        return None



class EmployeeUpdateSerializer(serializers.ModelSerializer):
    """
    Serializer for updating employee information with restricted fields
    """
    
    class Meta:
        model = Employee
        fields = [
            'full_name', 'mobile_number', 'date_of_birth', 'gender',
            'profile_photo', 'profile_photo_url',
            'department', 'designation', 'emergency_contact_name',
            'emergency_contact_number', 'emergency_contact_relation', 'current_address',
            'permanent_address', 'blood_group'
        ]
        
        # Explicitly restrict these fields from being updated
        read_only_fields = [
            'id', 'employee_id', 'email', 'date_of_joining', 'employment_status',
            'is_verified', 'is_onboarded', 'verification_date', 'onboarding_date',
            'last_login', 'created_at', 'updated_at', 'user_email', 'salary'
        ]
    
    def validate_mobile_number(self, value):
        """Validate mobile number"""
        # Remove any spaces or special characters
        clean_number = ''.join(filter(str.isdigit, value))
        
        # Check if it's a valid Indian mobile number
        if len(clean_number) != 10 or not clean_number.startswith(('6', '7', '8', '9')):
            raise serializers.ValidationError("Please enter a valid 10-digit mobile number.")
        
        return clean_number
    
    def validate_profile_photo(self, value):
        """Validate profile photo upload"""
        if value:
            # Check file size (max 5MB)
            if value.size > 5 * 1024 * 1024:
                raise serializers.ValidationError("Profile photo size cannot exceed 5MB.")
            
            # Check file extension
            allowed_extensions = ['.jpg', '.jpeg', '.png', '.gif']
            import os
            ext = os.path.splitext(value.name)[1].lower()
            if ext not in allowed_extensions:
                raise serializers.ValidationError(
                    f"File type not allowed. Allowed types: {', '.join(allowed_extensions)}"
                )
        
        return value
    
    def validate(self, attrs):
        """Additional validation to prevent restricted field updates"""
        
        # List of fields that should never be updated via this serializer
        restricted_fields = [
            'email', 'employee_id', 'date_of_joining', 'employment_status',
            'is_verified', 'is_onboarded', 'verification_date', 'onboarding_date',
            'last_login', 'salary'
        ]
        
        # Check if any restricted fields are in the request data
        for field in restricted_fields:
            if field in attrs:
                raise serializers.ValidationError(
                    f"Field '{field}' cannot be updated through this endpoint."
                )
        
        return attrs


class EmployeeListSerializer(serializers.ModelSerializer):
    """
    Lightweight serializer for employee lists
    """
    age = serializers.ReadOnlyField()
    profile_photo_display_url = serializers.ReadOnlyField()
    is_verified = serializers.BooleanField(source='user.is_verified', read_only=True)
    is_onboarded = serializers.BooleanField(source='user.is_onboarded', read_only=True)
    active = serializers.BooleanField(source='user.active', read_only=True)
    project_contribution = serializers.SerializerMethodField()
    is_birthday_today = serializers.SerializerMethodField()
    attendance_percentage = serializers.SerializerMethodField()
    assigned_projects = serializers.SerializerMethodField()
    is_clocked_in = serializers.SerializerMethodField()
    clocked_in_location = serializers.SerializerMethodField()
    on_leave = serializers.SerializerMethodField()
    on_wfh = serializers.SerializerMethodField()
    
    
    class Meta:
        model = Employee
        fields = [
            'id', 'employee_id', 'full_name', 'email', 'personal_email', 'mobile_number',
            'profile_photo_display_url', 'department', 'designation', 
            'employment_status', 'is_verified', 'age', 'date_of_joining', 'is_onboarded',
            'is_onboarded', 'active', 'project_contribution', 'is_birthday_today',
            'attendance_percentage', 'assigned_projects', 'is_clocked_in', 'on_leave', 
            'gender', 'is_core', 'on_wfh', 'clocked_in_location'
        ]
    
    def get_assigned_projects(self, obj):
        """Get list of projects the employee is involved in"""
        team_projects = obj.assigned_projects.values('name')
        assigned_projects = []
        for project in team_projects:
            assigned_projects.append(project['name'])
        
        # Get all projects where employee has completed tasks
        # task_projects = Project.objects.filter(
        #     dailytask__employee=obj,
        #     dailytask__end_time__isnull=False
        # ).distinct().values('name')
        
        # Combine both sets of projects and remove duplicates
        # all_projects = list(team_projects) + list(task_projects)
        # unique_projects = {project['id']: project for project in all_projects}.values()
        
        return list(assigned_projects)
    
    def get_project_contribution(self, obj):
        """Calculate project contribution based on completed tasks"""
        
        # Get all projects where employee is a team member
        projects = Project.objects.filter(team_members=obj)
        
        # Get all completed tasks for these projects
        completed_tasks = DailyTask.objects.filter(
            employee=obj,
            project__in=projects,
            end_time__isnull=False
        ).count()
        
        # Get total tasks for these projects
        total_tasks = DailyTask.objects.filter(
            project__in=projects
        ).count()
        
        if total_tasks == 0:
            return 0
        
        return int((completed_tasks / total_tasks) * 100)
    
    def get_is_birthday_today(self, obj):
        """Check if today is employee's birthday"""
        today = timezone.now().date()
        
        if not obj.date_of_birth:
            return False
            
        return (today.month == obj.date_of_birth.month and 
                today.day == obj.date_of_birth.day)
    
    def get_attendance_percentage(self, obj):
        """Calculate attendance percentage for the current month"""
        
        today = timezone.now().date()
        first_day_of_month = today.replace(day=1)
        
        # Get total working days in the month (excluding weekends)
        #TODO: Add holidays and leave days and also the working saturdays
        working_days = 0
        current_date = first_day_of_month
        print(current_date, today)
        
        while current_date <= today:
            if current_date.weekday() < 5:  # 0-4 are weekdays
                working_days += 1
            current_date += timedelta(days=1)  # Use timedelta for proper date arithmetic
        
        if working_days == 0:
            return 0
        
        # Get attendance records for the month
        attendance_records = DailyAttendance.objects.filter(
            employee=obj,
            date__gte=first_day_of_month,
            date__lte=today,
            is_clocked_out=True  # Only count completed attendance
        ).count()
        
        return int((attendance_records / working_days) * 100)

    def get_is_clocked_in(self, obj):
        """Check if employee is clocked in"""
        
        return DailyAttendance.objects.filter(employee=obj, is_clocked_out=False, date=timezone.now().date()).exists()
    
    def get_on_leave(self, obj):
        """Check if employee is on leave"""
        return Leave.objects.filter(employee=obj, status='approved', from_date__lte=timezone.now().date(), to_date__gte=timezone.now().date()).exists()

    def get_on_wfh(self, obj):
        """Get WFH information for the employee"""
        return WFH.objects.filter(employee=obj, status='approved', from_date__lte=timezone.now().date(), to_date__gte=timezone.now().date()).exists()

    def get_clocked_in_location(self, obj):
        """Get clocked in location for the employee"""
        location = None
        attendance = DailyAttendance.objects.filter(employee=obj, is_clocked_out=False, date=timezone.now().date()).first()
        if attendance:
            location = get_nearby_office_location(attendance.lat_long)
            location = location.location_name
            
        return location

class EmployeeDocumentSerializer(serializers.ModelSerializer):
    """
    Serializer for employee documents with S3 upload support
    """
    uploaded_by_name = serializers.CharField(source='uploaded_by.email_id', read_only=True)
    verified_by_name = serializers.CharField(source='verified_by.email_id', read_only=True)
    document_file = serializers.FileField(write_only=True)  # For upload only
    file_size = serializers.SerializerMethodField()

    
    class Meta:
        model = EmployeeDocument
        fields = [
            'id', 'document_type', 'document_file', 'document_file_url',
            'is_verified', 'verified_by', 'verified_by_name', 'verified_at',
            'uploaded_by', 'uploaded_by_name', 'notes', 'file_size',
            'created_at', 'updated_at', 'email_id'
        ]
        read_only_fields = ['id', 'uploaded_by', 'document_file_url', 'created_at', 'updated_at']
    
    def get_file_size(self, obj):
        """Get file size from the uploaded file or return placeholder"""
        # Since we're using S3, we don't have direct access to file size
        # This could be enhanced to store file size separately if needed
        return "Available on S3"
    
    def validate_document_file(self, value):
        """Validate document file - only PDF and JPEG allowed"""
        # Check file size (max 10MB)
        if value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("File size cannot exceed 10MB.")
        
        # Check file extension - only PDF and JPEG allowed
        import os
        ext = os.path.splitext(value.name)[1].lower()
        allowed_extensions = ['.pdf', '.jpg', '.jpeg']
        
        if ext not in allowed_extensions:
            raise serializers.ValidationError(
                f"File type not allowed. Only PDF and JPEG files are accepted. Got: {ext}"
            )
        
        return value
    
    def create(self, validated_data):
        """Create document and upload to S3"""
        from utils.boto_utils import s3_uploader
        
        # Extract file and employee info
        document_file = validated_data.pop('document_file')
        employee = validated_data.get('employee')
        document_type = validated_data.get('document_type')
        
        if not employee:
            raise serializers.ValidationError("Employee is required")
        
        # Upload file to S3
        success, result = s3_uploader.upload_document(
            file=document_file,
            email_id=employee.email,
            document_type=document_type,
            document_collection="personal_documents",
        )
        
        if not success:
            raise serializers.ValidationError(f"File upload failed: {result}")
        
        # Store S3 URL in the model
        validated_data['document_file_url'] = result
        
        # Create the document record
        document = EmployeeDocument.objects.create(**validated_data)
        
        return document
    
    def update(self, instance, validated_data):
        """Update document (if new file provided, upload to S3)"""
        from utils.boto_utils import s3_uploader
        
        # Check if new file is provided
        if 'document_file' in validated_data:
            document_file = validated_data.pop('document_file')
            
            # Delete old file from S3 if exists
            if instance.document_file_url:
                s3_uploader.delete_employee_document(instance.document_file_url)
            
            # Upload new file to S3
            success, result = s3_uploader.upload_document(
                file=document_file,
                email_id=instance.employee.email,
                document_type=instance.document_type,
                document_collection="personal_documents",
            )
            
            if not success:
                raise serializers.ValidationError(f"File upload failed: {result}")
            
            # Update S3 URL
            validated_data['document_file_url'] = result
        
        # Update other fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        
        instance.save()
        return instance


class EmployeeStatsSerializer(serializers.Serializer):
    """
    Serializer for employee statistics
    """
    total_employees = serializers.IntegerField()
    active_employees = serializers.IntegerField()
    verified_employees = serializers.IntegerField()
    onboarded_employees = serializers.IntegerField()
    departments = serializers.DictField()
    designations = serializers.DictField()


class TeamMemberSerializer(serializers.ModelSerializer):
    """
    Serializer for team members (employees reporting to a manager)
    """
    is_verified = serializers.BooleanField(source='user.is_verified', read_only=True)
    is_onboarded = serializers.BooleanField(source='user.is_onboarded', read_only=True)
    active = serializers.BooleanField(source='user.active', read_only=True)
    
    class Meta:
        model = Employee
        fields = [
            'id', 'employee_id', 'full_name', 'email', 'designation',
            'department', 'employment_status', 'is_verified', 'is_onboarded',
            'active', 'date_of_joining'
        ]


class EmployeeOnboardSerializer(serializers.ModelSerializer):
    """
    Serializer for onboarding existing users as employees
    """
    class Meta:
        model = Employee
        fields = [
            'email', 'full_name', 'mobile_number', 'date_of_birth',
            'gender', 'address', 'date_of_joining', 'department',
            'designation', 'emergency_contact_name',
            'emergency_contact_number', 'emergency_contact_relation', 'current_address',
            'permanent_address', 'blood_group'
        ]
        extra_kwargs = {
            'date_of_joining': {'required': False},
            'department': {'required': False},
            'designation': {'required': False},
        }

    
    def validate_email(self, value):
        """Validate email domain and check if user exists"""
        # Check domain validation
        
        print(f'valdiating email')
        is_valid, error_message = EmailDomainValidator.validate_email_domain(value)
        if not is_valid:
            raise serializers.ValidationError(error_message)
        
        # Check if user exists
        try:
            user = User.objects.get(email_id=value)
            
        except User.DoesNotExist:
            raise serializers.ValidationError("User with this email does not exist. Please register first.")
        
        # Check if user is already onboarded
        if user.is_onboarded:
            raise serializers.ValidationError("User is already onboarded.")
        
        return value
    
    def validate_mobile_number(self, value):
        """Validate mobile number"""
        # Remove any spaces or special characters
        clean_number = ''.join(filter(str.isdigit, value))
        
        # Check if it's a valid Indian mobile number
        if len(clean_number) != 10 or not clean_number.startswith(('6', '7', '8', '9')):
            raise serializers.ValidationError("Please enter a valid 10-digit mobile number.")
        
        return clean_number
    
    def create(self, validated_data):
        """Create employee profile for existing user"""
        email = validated_data['email']
        
        try:
            user = User.objects.get(email_id=email)
        except User.DoesNotExist:
            raise serializers.ValidationError("User with this email does not exist.")
        
        # Check if user is already onboarded
        if user.is_onboarded:
            raise serializers.ValidationError("User is already onboarded.")
        
        # Create employee profile
        validated_data['user'] = user
        employee = Employee.objects.create(**validated_data)
        
        # Mark user as onboarded
        user.is_onboarded = True
        user.save(update_fields=['is_onboarded'])
        
        return employee 

class AdminEmployeeUpdateSerializer(serializers.ModelSerializer):
    """
    Serializer for admin updates to employee details.
    All fields are optional, but at least one field must be provided.
    """
    email_id = serializers.EmailField(required=True)  # Required for lookup
    employee_id = serializers.CharField(required=False)
    department = serializers.CharField(required=False)
    designation = serializers.CharField(required=False)
    reporting_manager_email = serializers.EmailField(required=False)
    date_of_joining = serializers.DateField(required=False)
    appraisal_date = serializers.DateField(required=False)
    shift = serializers.CharField(required=False)
    uan_number = serializers.CharField(required=False)
    current_ctc = serializers.DecimalField(max_digits=10, decimal_places=2, required=False)
    shift_type = serializers.CharField(required=False)
    employment_type = serializers.CharField(required=False)
    location_id = serializers.IntegerField(required=False, write_only=True)  # For receiving location_id from request
    reporting_location_name = serializers.SerializerMethodField(read_only=True)  # For returning location data
    
    class Meta:
        model = Employee
        fields = [
            'email_id', 'employee_id', 'department', 'designation',
            'reporting_manager_email', 'date_of_joining', 'appraisal_date',
            'shift', 'uan_number', 'current_ctc', 'shift_type', 'employment_type', 
            'location_id', 'reporting_location_name'
        ]

    def validate(self, data):
        # Check if at least one field (other than email_id) is provided
        fields_to_check = set(data.keys()) - {'email_id'}
        if not fields_to_check:
            raise serializers.ValidationError("At least one field must be provided for update")

        # Validate reporting manager if provided
        if 'reporting_manager_email' in data:
            try:
                reporting_manager = Employee.objects.get(email=data['reporting_manager_email'])
                data['reporting_manager'] = reporting_manager
            except Employee.DoesNotExist:
                raise serializers.ValidationError({
                    'reporting_manager_email': 'Reporting manager not found'
                })

        # Validate location_id if provided
        if 'location_id' in data:
            try:
                from policies.models import OfficeLocations
                location = OfficeLocations.objects.get(id=data['location_id'])
                data['reporting_location'] = location
            except OfficeLocations.DoesNotExist:
                raise serializers.ValidationError({
                    'location_id': 'Office location not found with this ID'
                })

        # Validate employee exists
        try:
            Employee.objects.get(email=data['email_id'])
        except Employee.DoesNotExist:
            raise serializers.ValidationError({
                'email_id': 'Employee not found'
            })

        return data

    def update(self, instance, validated_data):
        # Remove email_id and location_id as they're only used for lookup
        validated_data.pop('email_id', None)
        validated_data.pop('location_id', None)
        
        # Update each field that was provided
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        
        instance.save()
        return instance
    
    def get_reporting_location_name(self, obj):
        if obj.reporting_location:
            return {
                'id': obj.reporting_location.id,
                'location_name': obj.reporting_location.location_name,
                'full_address': obj.reporting_location.full_address,
                'is_active': obj.reporting_location.is_active,
                'lat_long': obj.reporting_location.lat_long
            }
        return None

class EmployeeLocationSerializer(serializers.ModelSerializer):
    """
    Serializer for EmployeeLocation model with reverse geocoding
    """
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    employee_email = serializers.CharField(source='employee.email', read_only=True)
    
    class Meta:
        model = EmployeeLocation
        fields = [
            'id', 'employee', 'employee_name', 'employee_email', 
            'lat_long', 'location_address',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'employee', 'employee_name', 'employee_email', 'created_at', 'updated_at']
    
    def validate_lat_long(self, value):
        """
        Validate latitude/longitude format
        Expected format: "latitude,longitude" (e.g., "12.9716,77.5946")
        """
        if not value:
            raise serializers.ValidationError("Latitude and longitude are required")
        
        try:
            # Split by comma and validate
            parts = value.split(',')
            if len(parts) != 2:
                raise serializers.ValidationError("Latitude and longitude must be in format: 'latitude,longitude'")
            
            lat, lng = float(parts[0].strip()), float(parts[1].strip())
            
            # Validate latitude range (-90 to 90)
            if not -90 <= lat <= 90:
                raise serializers.ValidationError("Latitude must be between -90 and 90")
            
            # Validate longitude range (-180 to 180)
            if not -180 <= lng <= 180:
                raise serializers.ValidationError("Longitude must be between -180 and 180")
            
            # Return normalized format
            return f"{lat},{lng}"
            
        except ValueError:
            raise serializers.ValidationError("Invalid latitude/longitude format. Use decimal numbers separated by comma")
    
    def create(self, validated_data):
        """
        Create location record and automatically get address from coordinates
        """
        # Get the employee from the request user
        employee = self.context['request'].user.employee_profile
        
        # Create the location record
        location = EmployeeLocation.objects.create(
            employee=employee,
            **validated_data
        )
        
        # Get address from coordinates if not provided
        if location.lat_long and not location.location_address:
            try:
                address = self._get_address_from_coordinates(location.lat_long)
                if address:
                    location.location_address = address
                    location.save()
            except Exception as e:
                # Log the error but don't fail the creation
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"Failed to get address from coordinates: {str(e)}")
        
        return location
    
    def _get_address_from_coordinates(self, lat_long):
        """
        Get address from coordinates using reverse geocoding
        """
        try:
            import requests
            
            # Parse coordinates
            lat, lng = lat_long.split(',')
            
            # Use OpenStreetMap Nominatim API for reverse geocoding
            url = f"https://nominatim.openstreetmap.org/reverse"
            params = {
                'lat': lat,
                'lon': lng,
                'format': 'json',
                'addressdetails': 1
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract address components
                address_parts = []
                
                if 'display_name' in data:
                    return data['display_name']
                
                # Fallback: build address from components
                address_data = data.get('address', {})
                
                # Add house number and road
                if address_data.get('house_number'):
                    address_parts.append(address_data['house_number'])
                if address_data.get('road'):
                    address_parts.append(address_data['road'])
                
                # Add suburb/neighborhood
                if address_data.get('suburb'):
                    address_parts.append(address_data['suburb'])
                
                # Add city
                if address_data.get('city'):
                    address_parts.append(address_data['city'])
                elif address_data.get('town'):
                    address_parts.append(address_data['town'])
                elif address_data.get('village'):
                    address_parts.append(address_data['village'])
                
                # Add state
                if address_data.get('state'):
                    address_parts.append(address_data['state'])
                
                # Add postcode
                if address_data.get('postcode'):
                    address_parts.append(address_data['postcode'])
                
                # Add country
                if address_data.get('country'):
                    address_parts.append(address_data['country'])
                
                return ', '.join(address_parts) if address_parts else None
            
            return None
            
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Error in reverse geocoding: {str(e)}")
            return None

class EmployeeLocationCreateSerializer(serializers.ModelSerializer):
    """
    Simplified serializer for creating location records
    """
    class Meta:
        model = EmployeeLocation
        fields = ['lat_long']
    
    def validate_lat_long(self, value):
        """
        Validate latitude/longitude format
        """
        if not value:
            raise serializers.ValidationError("Latitude and longitude are required")
        
        try:
            # Split by comma and validate
            parts = value.split(',')
            if len(parts) != 2:
                raise serializers.ValidationError("Latitude and longitude must be in format: 'latitude,longitude'")
            
            lat, lng = float(parts[0].strip()), float(parts[1].strip())
            
            # Validate latitude range (-90 to 90)
            if not -90 <= lat <= 90:
                raise serializers.ValidationError("Latitude must be between -90 and 90")
            
            # Validate longitude range (-180 to 180)
            if not -180 <= lng <= 180:
                raise serializers.ValidationError("Longitude must be between -180 and 180")
            
            # Return normalized format
            return f"{lat},{lng}"
            
        except ValueError:
            raise serializers.ValidationError("Invalid latitude/longitude format. Use decimal numbers separated by comma")
    
    def create(self, validated_data):
        # Get the employee from the context
        employee = self.context['request'].user.employee_profile
        
        # Get address from coordinates
        lat_long = validated_data['lat_long']
        location_address = self._get_address_from_coordinates(lat_long)
        
        # Create the location record with employee
        return EmployeeLocation.objects.create(
            employee=employee,
            lat_long=lat_long,
            location_address=location_address
        )
    
    def _get_address_from_coordinates(self, lat_long):
        """
        Get address from coordinates using reverse geocoding
        """
        try:
            
            # Parse coordinates
            lat, lng = lat_long.split(',')
            
            # Use OpenStreetMap Nominatim API for reverse geocoding
            url = "https://nominatim.openstreetmap.org/reverse"
            params = {
                'lat': lat,
                'lon': lng,
                'format': 'json',
                'addressdetails': 1
            }
            
            headers = {
                'User-Agent': 'DigitalHR-Backend/1.0 (https://sciverse.co.in; contact@sciverse.co.in)'
            }
            
            print(f"Making request to: {url}")
            print(f"With params: {params}")
            print(f"With headers: {headers}")
            
            response = requests.get(url, params=params, headers=headers, timeout=10)
            print(f"Response status: {response.status_code}")
            print(f"Response headers: {response.headers}")
            print(f"Response content: {response.text[:500]}...")  # First 500 chars
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    print(f"Parsed JSON data: {data}")
                    
                    # Return the display name (full address)
                    if 'display_name' in data:
                        print(f"Found display_name: {data['display_name']}")
                        return data['display_name']
                    
                    # Fallback: build address from components
                    address_data = data.get('address', {})
                    address_parts = []
                    
                    # Add house number and road
                    if address_data.get('house_number'):
                        address_parts.append(address_data['house_number'])
                    if address_data.get('road'):
                        address_parts.append(address_data['road'])
                    
                    # Add suburb/neighborhood
                    if address_data.get('suburb'):
                        address_parts.append(address_data['suburb'])
                    
                    # Add city
                    if address_data.get('city'):
                        address_parts.append(address_data['city'])
                    elif address_data.get('town'):
                        address_parts.append(address_data['town'])
                    elif address_data.get('village'):
                        address_parts.append(address_data['village'])
                    
                    # Add state
                    if address_data.get('state'):
                        address_parts.append(address_data['state'])
                    
                    # Add postcode
                    if address_data.get('postcode'):
                        address_parts.append(address_data['postcode'])
                    
                    # Add country
                    if address_data.get('country'):
                        address_parts.append(address_data['country'])
                    
                    result = ', '.join(address_parts) if address_parts else None
                    print(f"Built address from components: {result}")
                    return result
                    
                except Exception as json_error:
                    print(f"Error parsing JSON: {json_error}")
                    return None
            
            print(f"Request failed with status: {response.status_code}")
            return None
            
        except Exception as e:
            print(f"Exception in reverse geocoding: {str(e)}")
            return None
