from django.urls import path
from . import views

app_name = 'announcements'

urlpatterns = [
    path('', views.list_announcements, name='list_announcements'),
    path('create/', views.create_announcement, name='create_announcement'),
    path('<int:announcement_id>/', views.get_announcement_detail, name='get_announcement_detail'),
    path('<int:announcement_id>/update/', views.update_announcement, name='update_announcement'),
    path('<int:announcement_id>/delete/', views.delete_announcement, name='delete_announcement'),
] 