from django.contrib import admin
from .models import Policy, OfficeLocations, PublicHoliday
# Register your models here.
admin.site.register(Policy)
admin.site.register(OfficeLocations)
admin.site.register(PublicHoliday)