from rest_framework import serializers
from django.contrib.auth.hashers import make_password, check_password
from django.utils import timezone
from datetime import timedelta
import random
import logging
from .models import User, OTP
from utils.general_utils import EmailDomainValidator
from utils.email_utils import EmailService

logger = logging.getLogger(__name__)

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    device_token = serializers.CharField()
    
    class Meta:
        model = User
        fields = ['email_id', 'password', 'created_at', 'device_token']
        extra_kwargs = {
            'email_id': {'validators': []},  # Remove default unique validators
        }
    
    def create(self, validated_data):
        email_id = validated_data['email_id']
        password = validated_data['password']
        device_token = validated_data['device_token']
        # Check if user already exists
        try:
            user = User.objects.get(email_id=email_id)
            # User exists, update their registration status and password
            user.is_registered = True
            user.active = True
            user.password = make_password(password)
            user.device_token = device_token
            user.save()
        except User.DoesNotExist:
            # User doesn't exist, create new user
            validated_data['password'] = make_password(password)
            validated_data['is_registered'] = True
            validated_data['active'] = True
            validated_data['device_token'] = device_token
            user = User.objects.create(**validated_data)
        
        # Send welcome email
        email_sent, email_error = EmailService.send_welcome_email(
            recipient_email=user.email_id,
            user_name=user.email_id.split('@')[0]  # Use email prefix as name
        )
        
        if not email_sent:
            logger.error(f"Failed to send welcome email: {email_error}")
        
        return user
    
    def validate_email_id(self, value):
        # Validate email domain first
        is_valid, error_message = EmailDomainValidator.validate_email_domain(value)
        if not is_valid:
            raise serializers.ValidationError(error_message)
        
        # Check if user already exists AND is already registered
        try:
            user = User.objects.get(email_id=value)
            if user.is_registered:
                raise serializers.ValidationError("User with this email is already registered.")
            # If user exists but is not registered, allow registration
        except User.DoesNotExist:
            # User doesn't exist, allow registration
            raise serializers.ValidationError("User with this email does not exist.")
        
        return value

class UserLoginSerializer(serializers.Serializer):
    email_id = serializers.EmailField()
    password = serializers.CharField(write_only=True)
    device_token = serializers.CharField()
    
    def validate(self, attrs):
        email_id = attrs.get('email_id')
        password = attrs.get('password')
        device_token = attrs.get('device_token')
        try:
            user = User.objects.get(email_id=email_id)
        except User.DoesNotExist:
            raise serializers.ValidationError("Invalid email or password.")
        
        if not user.active:
            raise serializers.ValidationError("User account is deactivated.")
        
        if not check_password(password, user.password):
            raise serializers.ValidationError("Invalid email or password.")
        
        attrs['user'] = user
        attrs['device_token'] = device_token
        return attrs

class OTPGenerateSerializer(serializers.Serializer):
    email_id = serializers.EmailField()
    otp_type = serializers.ChoiceField(choices=OTP.OTP_TYPE_CHOICES, default='login')
    
    def validate_email_id(self, value):
        # Validate email domain
        is_valid, error_message = EmailDomainValidator.validate_email_domain(value)
        if not is_valid:
            raise serializers.ValidationError(error_message)
            
        user = User.objects.filter(email_id=value).first()
        
        if not user:
        # except:
            print(f'there is a issue')
            user_obj = User.objects.create(email_id=value)
            user_obj.save()
            user = user_obj
        # except User.DoesNotExist:
        #     raise serializers.ValidationError("User with this email does not exist.")
        
        # if not user.active:
        #     raise serializers.ValidationError("User account is deactivated.")
        
        return value
    
    def validate(self, attrs):
        email_id = attrs.get('email_id')
        otp_type = attrs.get('otp_type')
        
        # Additional validation for password reset
        if otp_type == 'password_reset':
            try:
                user = User.objects.get(email_id=email_id)
                # For password reset, user should be verified (optional requirement)
                # if not user.verified:
                #     raise serializers.ValidationError("Account must be verified to reset password.")
            except User.DoesNotExist:
                pass  # Already handled in validate_email_id
        
        return attrs
    
    def create(self, validated_data):
        email_id = validated_data['email_id']
        otp_type = validated_data['otp_type']
        user = User.objects.get(email_id=email_id)
        
        # Generate 6-digit OTP
        otp_code = str(random.randint(100000, 999999))
        
        # Mark previous OTPs of the same type as used for this user
        try:
            OTP.objects.filter(
                email_id=user, 
                otp_type=otp_type, 
                is_used=False
            ).update(is_used=True)
        except:
            pass
        
        # Create new OTP
        otp_instance = OTP.objects.create(
            email_id=user,
            otp=otp_code,
            otp_type=otp_type
        )
        
        # Calculate expiry time
        expiry_time = otp_instance.created_at + timedelta(minutes=10)
        
        # Send OTP email
        email_sent, email_error = EmailService.send_otp_email(
            recipient_email=email_id,
            otp=otp_code,
            otp_expiry=expiry_time,
            otp_type=otp_type
        )
        
        if not email_sent:
            logger.error(f"Failed to send OTP email: {email_error}")
            # Note: We don't raise an error here as OTP is still valid
            # But in production, you might want to handle this differently
        
        return {
            'email_id': email_id,
            'otp': otp_code,
            'otp_type': otp_type,
            'expires_at': expiry_time,
            'email_sent': email_sent
        }

class OTPVerifySerializer(serializers.Serializer):
    email_id = serializers.EmailField()
    otp = serializers.CharField(max_length=6, min_length=6)
    otp_type = serializers.ChoiceField(choices=OTP.OTP_TYPE_CHOICES, default='login')
    
    def validate(self, attrs):
        email_id = attrs.get('email_id')
        otp_code = attrs.get('otp')
        otp_type = attrs.get('otp_type')
        
        try:
            user = User.objects.get(email_id=email_id)
        except User.DoesNotExist:
            raise serializers.ValidationError("User with this email does not exist.")
        
        # Find the most recent unused OTP of the specified type for this user
        try:
            otp_instance = OTP.objects.filter(
                email_id=user,
                otp=otp_code,
                otp_type=otp_type,
                is_used=False
            ).latest('created_at')
        except OTP.DoesNotExist:
            raise serializers.ValidationError(f"Invalid or expired {otp_type.replace('_', ' ')} OTP.")
        
        # Check if OTP is expired (10 minutes)
        expiry_time = otp_instance.created_at + timedelta(minutes=10)
        if timezone.now() > expiry_time:
            raise serializers.ValidationError(f"{otp_type.replace('_', ' ').title()} OTP has expired.")
        
        # Mark OTP as used
        otp_instance.is_used = True
        otp_instance.save()
        
        attrs['user'] = user
        attrs['otp_instance'] = otp_instance
        return attrs

class PasswordResetSerializer(serializers.Serializer):
    """
    Serializer for resetting password after OTP verification
    """
    email_id = serializers.EmailField()
    new_password = serializers.CharField(write_only=True, min_length=8)
    confirm_password = serializers.CharField(write_only=True)
    
    def validate_email_id(self, value):
        # Validate email domain
        is_valid, error_message = EmailDomainValidator.validate_email_domain(value)
        if not is_valid:
            raise serializers.ValidationError(error_message)
        return value
    
    def validate(self, attrs):
        new_password = attrs.get('new_password')
        confirm_password = attrs.get('confirm_password')
        
        if new_password != confirm_password:
            raise serializers.ValidationError("Passwords do not match.")
        
        return attrs 