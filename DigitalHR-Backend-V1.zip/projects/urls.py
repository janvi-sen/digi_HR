from django.urls import path
from . import views

app_name = 'projects'

urlpatterns = [
    path('', views.list_projects, name='list_projects'),
    path('create/', views.create_project, name='create_project'),
    path('<int:project_id>/', views.get_project_detail, name='get_project_detail'),
    path('<int:project_id>/update/', views.update_project, name='update_project'),
    path('<int:project_id>/delete/', views.delete_project, name='delete_project'),
] 