"""
Email utility functions for DigitalHR project.
"""

import logging
from django.conf import settings
from django.core.mail import EmailMultiAlternatives, send_mail
from django.template.loader import render_to_string
from django.utils import timezone
from datetime import datetime, timedelta
from django.utils.html import strip_tags
import pandas as pd
import firebase_admin
from firebase_admin import credentials, firestore

logger = logging.getLogger(__name__)

class EmailService:
    """
    Service class for handling email operations
    """
    
    @staticmethod
    def send_otp_email(recipient_email, otp, otp_expiry, otp_type='login'):
        """
        Send OTP email to user
        
        Args:
            recipient_email (str): Recipient's email address
            otp (str): 6-digit OTP
            otp_expiry (datetime): OTP expiration time
            otp_type (str): Type of OTP ('login' or 'password_reset')
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Format expiry time to IST
            formatted_expiry = otp_expiry.strftime('%Y-%m-%d %H:%M')
            
            # Determine email subject based on OTP type
            if otp_type == 'password_reset':
                subject = 'Your Password Reset OTP for Digital HR'
                purpose = 'password reset'
            else:
                subject = settings.OTP_EMAIL_SUBJECT
                purpose = 'login'
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .otp-box {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .otp-code {{
                            color: #2A5CAA;
                            font-size: 28px;
                            font-weight: bold;
                            letter-spacing: 3px;
                            margin: 10px 0;
                        }}
                        .security-notice {{
                            background: #F5F7FA;
                            padding: 15px;
                            border-left: 4px solid #2A5CAA;
                            margin: 20px 0;
                            border-radius: 0 4px 4px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                        .expiry-info {{
                            background: #fff3cd;
                            border: 1px solid #ffeaa7;
                            border-radius: 4px;
                            padding: 10px;
                            margin: 15px 0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🔐 Digital HR Security</h1>
                        <p>One-Time Password Verification</p>
                    </div>
                    
                    <div class="content">
                        <p>Dear User,</p>
                        
                        <p>Your One-Time Password (OTP) for <strong>Digital HR {purpose}</strong> is:</p>
                        
                        <div class="otp-box">
                            <div class="otp-code">{otp}</div>
                            <p><small>Enter this code to proceed</small></p>
                        </div>
                        
                        <div class="expiry-info">
                            <p><strong>⏰ Valid Until:</strong> {formatted_expiry} IST</p>
                            <p><small>This OTP will expire in 10 minutes from the time it was generated.</small></p>
                        </div>
                        
                        <div class="security-notice">
                            <p><strong>🛡️ Security Notice:</strong></p>
                            <ul style="margin: 5px 0; padding-left: 20px;">
                                <li>Do <strong>not</strong> share this OTP with anyone.</li>
                                <li>Digital HR will never ask for your OTP via phone or email.</li>
                                <li>If you did not request this, please <strong>contact support immediately</strong>.</li>
                                <li>This OTP can only be used once.</li>
                            </ul>
                        </div>
                        
                        <p>If you're having trouble accessing your account, please contact our support team.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Dear User,

            Your One-Time Password (OTP) for Digital HR {purpose} is: {otp}

            This OTP is valid until: {formatted_expiry} IST

            Security Notice:
            - Do not share this OTP with anyone.
            - If you did not request this, please contact support immediately.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[recipient_email]
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"OTP email sent successfully to {recipient_email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send OTP email to {recipient_email}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    @staticmethod
    def send_welcome_email(recipient_email, user_name=None):
        """
        Send welcome email to new user
        
        Args:
            recipient_email (str): Recipient's email address
            user_name (str): User's name (optional)
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = "Welcome to Digital HR!"
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🎉 Welcome to Digital HR!</h1>
                    </div>
                    
                    <div style="padding: 20px;">
                        <p>Dear {user_name or 'User'},</p>
                        
                        <p>Welcome to <strong>Digital HR</strong>! Your account has been successfully created.</p>
                        
                        <p>You can now access all HR services and manage your profile through our platform.</p>
                        
                        <p>If you have any questions, feel free to contact our support team.</p>
                        
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                    </div>
                </body>
            </html>
            """
            
            text_content = f"""
            Dear {user_name or 'User'},

            Welcome to Digital HR! Your account has been successfully created.

            You can now access all HR services and manage your profile through our platform.

            Thank you,
            The Digital HR Team
            """
            
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[recipient_email]
            )
            
            email.attach_alternative(html_content, "text/html")
            email.send()
            
            logger.info(f"Welcome email sent successfully to {recipient_email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send welcome email to {recipient_email}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_leave_request_email(leave_request, recipients):
        """
        Send leave request notification email to multiple recipients
        
        Args:
            leave_request (Leave): The leave request object
            recipients (list): List of recipient email addresses
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Leave Request: {leave_request.employee.full_name} ({leave_request.leave_type})"
            
            # Format dates
            from_date = leave_request.from_date.strftime('%d %b %Y')
            to_date = leave_request.to_date.strftime('%d %b %Y')
            duration = (leave_request.to_date - leave_request.from_date).days + 1
            
            # Get document URL if available
            document_url = leave_request.documents if leave_request.documents else 'NA'
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .leave-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                        .document-link {{
                            color: #2A5CAA;
                            text-decoration: none;
                        }}
                        .document-link:hover {{
                            text-decoration: underline;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>📅 Leave Request Notification</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear Team,</p>
                        
                        <p>A new leave request has been submitted:</p>
                        
                        <div class="leave-details">
                            <p><strong>Employee:</strong> {leave_request.employee.full_name}</p>
                            <p><strong>Leave Type:</strong> {leave_request.leave_type}</p>
                            <p><strong>From:</strong> {from_date}</p>
                            <p><strong>To:</strong> {to_date}</p>
                            <p><strong>Duration:</strong> {duration} day(s)</p>
                            <p><strong>Reason:</strong> {leave_request.description or 'Not specified'}</p>
                            <p><strong>Supporting Document:</strong> {
                                f'<a href="{document_url}" class="document-link">View Document</a>' if document_url != 'NA' else 'NA'
                            }</p>
                        </div>
                        
                        <p>Please review and take necessary action.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Leave Request Notification

            A new leave request has been submitted:

            Employee: {leave_request.employee.full_name}
            Leave Type: {leave_request.leave_type}
            From: {from_date}
            To: {to_date}
            Duration: {duration} day(s)
            Reason: {leave_request.description or 'Not specified'}
            Supporting Document: {document_url}

            Please review and take necessary action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Leave request notification email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send leave request notification email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_leave_status_update_email(leave_request, status, recipients,comments=None):
        """
        Send leave request status update notification email
        
        Args:
            leave_request (Leave): The leave request object
            status (str): New status of the leave request
            comments (str): Comments from the approver (optional)
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Leave Request {status.title()}: {leave_request.employee.full_name}"
            
            # Format dates
            from_date = leave_request.from_date.strftime('%d %b %Y')
            to_date = leave_request.to_date.strftime('%d %b %Y')
            duration = (leave_request.to_date - leave_request.from_date).days + 1
            
            # Get document URL if available
            document_url = leave_request.documents if leave_request.documents else 'NA'
            
            # Get approver name
            approver_name = leave_request.approved_by.full_name if leave_request.approved_by else 'HR Team'
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .leave-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .status-update {{
                            background: {'#d4edda' if status == 'approved' else '#f8d7da'};
                            border: 1px solid {'#c3e6cb' if status == 'approved' else '#f5c6cb'};
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                            color: {'#155724' if status == 'approved' else '#721c24'};
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                        .document-link {{
                            color: #2A5CAA;
                            text-decoration: none;
                        }}
                        .document-link:hover {{
                            text-decoration: underline;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>📅 Leave Request Update</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear {leave_request.employee.full_name},</p>
                        
                        <div class="status-update">
                            <h2>Your leave request has been <strong>{status.upper()}</strong></h2>
                            <p>By: {approver_name}</p>
                            {f'<p><strong>Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <p>Leave request details:</p>
                        
                        <div class="leave-details">
                            <p><strong>Leave Type:</strong> {leave_request.leave_type}</p>
                            <p><strong>From:</strong> {from_date}</p>
                            <p><strong>To:</strong> {to_date}</p>
                            <p><strong>Duration:</strong> {duration} day(s)</p>
                            <p><strong>Reason:</strong> {leave_request.description or 'Not specified'}</p>
                            <p><strong>Supporting Document:</strong> {
                                f'<a href="{document_url}" class="document-link">View Document</a>' if document_url != 'NA' else 'NA'
                            }</p>
                        </div>
                        
                        <p>If you have any questions, please contact the HR team.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Leave Request Update

            Dear {leave_request.employee.full_name},

            Your leave request has been {status.upper()}
            By: {approver_name}
            {f'Comments: {comments}' if comments else ''}

            Leave request details:
            Leave Type: {leave_request.leave_type}
            From: {from_date}
            To: {to_date}
            Duration: {duration} day(s)
            Reason: {leave_request.description or 'Not specified'}
            Supporting Document: {document_url}

            If you have any questions, please contact the HR team.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Leave status update email sent successfully to {leave_request.employee.email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send leave status update email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_wfh_request_email(wfh_request, recipients):
        """
        Send WFH request notification email to multiple recipients
        
        Args:
            wfh_request (WFH): The WFH request object
            recipients (list): List of recipient email addresses
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"WFH Request: {wfh_request.employee.full_name}"
            
            # Format dates
            from_date = wfh_request.from_date.strftime('%d %b %Y')
            to_date = wfh_request.to_date.strftime('%d %b %Y')
            duration = (wfh_request.to_date - wfh_request.from_date).days + 1
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .wfh-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🏠 WFH Request Notification</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear Team,</p>
                        
                        <p>A new WFH request has been submitted:</p>
                        
                        <div class="wfh-details">
                            <p><strong>Employee:</strong> {wfh_request.employee.full_name}</p>
                            <p><strong>From:</strong> {from_date}</p>
                            <p><strong>To:</strong> {to_date}</p>
                            <p><strong>Duration:</strong> {duration} day(s)</p>
                            <p><strong>Reason:</strong> {wfh_request.description or 'Not specified'}</p>
                        </div>
                        
                        <p>Please review and take necessary action.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            WFH Request Notification

            A new WFH request has been submitted:

            Employee: {wfh_request.employee.full_name}
            From: {from_date}
            To: {to_date}
            Duration: {duration} day(s)
            Reason: {wfh_request.description or 'Not specified'}

            Please review and take necessary action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"WFH request notification email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send WFH request notification email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_wfh_status_update_email(wfh_request, status, recipients, comments=None):
        """
        Send WFH request status update notification email
        
        Args:
            wfh_request (WFH): The WFH request object
            status (str): New status of the WFH request
            comments (str): Comments from the approver (optional)
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"WFH Request {status.title()}: {wfh_request.employee.full_name}"
            
            # Format dates
            from_date = wfh_request.from_date.strftime('%d %b %Y')
            to_date = wfh_request.to_date.strftime('%d %b %Y')
            duration = (wfh_request.to_date - wfh_request.from_date).days + 1
            
            # Get approver name
            approver_name = wfh_request.approved_by.full_name if wfh_request.approved_by else 'HR Team'
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .wfh-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .status-update {{
                            background: {'#d4edda' if status == 'approved' else '#f8d7da'};
                            border: 1px solid {'#c3e6cb' if status == 'approved' else '#f5c6cb'};
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                            color: {'#155724' if status == 'approved' else '#721c24'};
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🏠 WFH Request Update</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear {wfh_request.employee.full_name},</p>
                        
                        <div class="status-update">
                            <h2>Your WFH request has been <strong>{status.upper()}</strong></h2>
                            <p>By: {approver_name}</p>
                            {f'<p><strong>Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <p>WFH request details:</p>
                        
                        <div class="wfh-details">
                            <p><strong>From:</strong> {from_date}</p>
                            <p><strong>To:</strong> {to_date}</p>
                            <p><strong>Duration:</strong> {duration} day(s)</p>
                            <p><strong>Reason:</strong> {wfh_request.description or 'Not specified'}</p>
                        </div>
                        
                        <p>If you have any questions, please contact the HR team.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            WFH Request Update

            Your WFH request has been {status.upper()}
            By: {approver_name}
            {f'Comments: {comments}' if comments else ''}

            WFH request details:
            From: {from_date}
            To: {to_date}
            Duration: {duration} day(s)
            Reason: {wfh_request.description or 'Not specified'}

            If you have any questions, please contact the HR team.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"WFH status update email sent successfully to {wfh_request.employee.email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send WFH status update email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_compoff_request_email(compoff_request, recipients):
        """
        Send comp-off request notification email to multiple recipients
        
        Args:
            compoff_request (CompOffCreditRequest): The comp-off request object
            recipients (list): List of recipient email addresses
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Comp-off Request: {compoff_request.employee.full_name}"
            
            # Format date
            date = compoff_request.date.strftime('%d %b %Y')
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .compoff-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>⏰ Comp-off Request Notification</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear Team,</p>
                        
                        <p>A new comp-off request has been submitted:</p>
                        
                        <div class="compoff-details">
                            <p><strong>Employee:</strong> {compoff_request.employee.full_name}</p>
                            <p><strong>Project:</strong> {compoff_request.project.name}</p>
                            <p><strong>Date:</strong> {date}</p>
                            <p><strong>Type:</strong> {compoff_request.request_type}</p>
                            <p><strong>Reason:</strong> {compoff_request.reason or 'Not specified'}</p>
                        </div>
                        
                        <p>Please review and take necessary action.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Comp-off Request Notification

            A new comp-off request has been submitted:

            Employee: {compoff_request.employee.full_name}
            Project: {compoff_request.project.name}
            Date: {date}
            Type: {compoff_request.request_type}
            Reason: {compoff_request.reason or 'Not specified'}

            Please review and take necessary action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Comp-off request notification email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send comp-off request notification email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_compoff_status_update_email(compoff_request, status, recipients, comments=None):
        """
        Send comp-off request status update notification email
        
        Args:
            compoff_request (CompOffCreditRequest): The comp-off request object
            status (str): New status of the comp-off request
            comments (str): Comments from the approver (optional)
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Comp-off Request {status.title()}: {compoff_request.employee.full_name}"
            
            # Format date
            date = compoff_request.date.strftime('%d %b %Y')
            
            # Get approver name
            approver_name = compoff_request.approved_by.full_name if compoff_request.approved_by else 'HR Team'
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .compoff-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .status-update {{
                            background: {'#d4edda' if status == 'approved' else '#f8d7da'};
                            border: 1px solid {'#c3e6cb' if status == 'approved' else '#f5c6cb'};
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                            color: {'#155724' if status == 'approved' else '#721c24'};
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>⏰ Comp-off Request Update</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear {compoff_request.employee.full_name},</p>
                        
                        <div class="status-update">
                            <h2>Your comp-off request has been <strong>{status.upper()}</strong></h2>
                            <p>By: {approver_name}</p>
                            {f'<p><strong>Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <p>Comp-off request details:</p>
                        
                        <div class="compoff-details">
                            <p><strong>Project:</strong> {compoff_request.project.name}</p>
                            <p><strong>Date:</strong> {date}</p>
                            <p><strong>Type:</strong> {compoff_request.request_type}</p>
                            <p><strong>Reason:</strong> {compoff_request.reason or 'Not specified'}</p>
                        </div>
                        
                        <p>If you have any questions, please contact the HR team.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Comp-off Request Update

            Your comp-off request has been {status.upper()}
            By: {approver_name}
            {f'Comments: {comments}' if comments else ''}

            Comp-off request details:
            Project: {compoff_request.project.name}
            Date: {date}
            Type: {compoff_request.request_type}
            Reason: {compoff_request.reason or 'Not specified'}

            If you have any questions, please contact the HR team.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Comp-off status update email sent successfully to {compoff_request.employee.email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send comp-off status update email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_emergency_fund_request_email(emergency_fund_request, recipients):
        """
        Send emergency fund request notification email to multiple recipients
        
        Args:
            emergency_fund_request (EmergencyFundRequest): The emergency fund request object
            recipients (list): List of recipient email addresses
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Emergency Fund Request: {emergency_fund_request.employee.full_name}"
            
            # Format dates
            fund_needed_date = emergency_fund_request.fund_needed_date.strftime('%d %b %Y')
            repayment_date = emergency_fund_request.fund_repayment_date.strftime('%d %b %Y')
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .fund-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .amount {{
                            font-size: 24px;
                            color: #2A5CAA;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>💰 Emergency Fund Request</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear Team,</p>
                        
                        <p>A new emergency fund request has been submitted:</p>
                        
                        <div class="fund-details">
                            <p><strong>Employee:</strong> {emergency_fund_request.employee.full_name}</p>
                            <p class="amount">₹{emergency_fund_request.amount_requested:,.2f}</p>
                            <p><strong>Fund Needed By:</strong> {fund_needed_date}</p>
                            <p><strong>Repayment Date:</strong> {repayment_date}</p>
                            <p><strong>Reason:</strong> {emergency_fund_request.reason or 'Not specified'}</p>
                            <p><strong>Repayment Plan:</strong> {emergency_fund_request.repayment_plan or 'Not specified'}</p>
                        </div>
                        
                        <p>Please review and take necessary action.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Emergency Fund Request

            A new emergency fund request has been submitted:

            Employee: {emergency_fund_request.employee.full_name}
            Amount: ₹{emergency_fund_request.amount_requested:,.2f}
            Fund Needed By: {fund_needed_date}
            Repayment Date: {repayment_date}
            Reason: {emergency_fund_request.reason or 'Not specified'}
            Repayment Plan: {emergency_fund_request.repayment_plan or 'Not specified'}

            Please review and take necessary action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Emergency fund request notification email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send emergency fund request notification email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_emergency_fund_status_update_email(emergency_fund_request, status, recipients, comments=None):
        """
        Send emergency fund request status update notification email
        
        Args:
            emergency_fund_request (EmergencyFundRequest): The emergency fund request object
            status (str): New status of the emergency fund request
            comments (str): Comments from the approver (optional)
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Emergency Fund Request {status.title()}: {emergency_fund_request.employee.full_name}"
            
            # Format dates
            fund_needed_date = emergency_fund_request.fund_needed_date.strftime('%d %b %Y')
            repayment_date = emergency_fund_request.fund_repayment_date.strftime('%d %b %Y')
            
            # Get approver name
            approver_name = emergency_fund_request.approved_by.full_name if emergency_fund_request.approved_by else 'HR Team'
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .fund-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .status-update {{
                            background: {'#d4edda' if status == 'approved' else '#f8d7da'};
                            border: 1px solid {'#c3e6cb' if status == 'approved' else '#f5c6cb'};
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                            color: {'#155724' if status == 'approved' else '#721c24'};
                        }}
                        .amount {{
                            font-size: 24px;
                            color: #2A5CAA;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>💰 Emergency Fund Request Update</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear {emergency_fund_request.employee.full_name},</p>
                        
                        <div class="status-update">
                            <h2>Your emergency fund request has been <strong>{status.upper()}</strong></h2>
                            <p>By: {approver_name}</p>
                            {f'<p><strong>Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <div class="fund-details">
                            <p><strong>Amount Requested:</strong></p>
                            <p class="amount">₹{emergency_fund_request.amount:,.2f}</p>
                            <p><strong>Fund Needed By:</strong> {fund_needed_date}</p>
                            <p><strong>Repayment Date:</strong> {repayment_date}</p>
                            <p><strong>Reason:</strong> {emergency_fund_request.reason or 'Not specified'}</p>
                            <p><strong>Repayment Plan:</strong> {emergency_fund_request.repayment_plan or 'Not specified'}</p>
                        </div>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Emergency Fund Request Update

            Your emergency fund request has been {status.upper()}
            By: {approver_name}
            {f'Comments: {comments}' if comments else ''}

            Amount Requested: ₹{emergency_fund_request.amount:,.2f}
            Fund Needed By: {fund_needed_date}
            Repayment Date: {repayment_date}
            Reason: {emergency_fund_request.reason or 'Not specified'}
            Repayment Plan: {emergency_fund_request.repayment_plan or 'Not specified'}

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Emergency fund request status update email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send emergency fund request status update email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_reimbursement_request_email(reimbursement_request, recipients):
        """
        Send reimbursement request notification email to multiple recipients
        
        Args:
            reimbursement_request (ReimbursementRequest): The reimbursement request object
            recipients (list): List of recipient email addresses
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Reimbursement Request: {reimbursement_request.employee.full_name}"
            
            # Format date
            expense_date = reimbursement_request.date.strftime('%d %b %Y')
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .expense-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .amount {{
                            font-size: 24px;
                            color: #2A5CAA;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .request-id {{
                            background: #e9ecef;
                            padding: 10px;
                            border-radius: 4px;
                            margin: 10px 0;
                            font-family: monospace;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>💰 Reimbursement Request</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear Team,</p>
                        
                        <p>A new reimbursement request has been submitted:</p>
                        
                        <div class="expense-details">
                            <p><strong>Employee:</strong> {reimbursement_request.employee.full_name}</p>
                            <p><strong>Category:</strong> {reimbursement_request.category.title()}</p>
                            <p class="amount">₹{reimbursement_request.amount:,.2f}</p>
                            <p><strong>Date:</strong> {expense_date}</p>
                            <p><strong>Project:</strong> {reimbursement_request.project.name}</p>
                            <p><strong>Description:</strong> {reimbursement_request.description or 'Not specified'}</p>
                            <div class="request-id">
                                <strong>Request ID:</strong> {reimbursement_request.reimbursement_id}
                            </div>
                            <p><strong>Bill Receipt:</strong> <a href="{reimbursement_request.bill_receipt_url}">View Receipt</a></p>
                            {f'<p><strong>Payment Receipt:</strong> <a href="{reimbursement_request.payment_receipt_url}">View Receipt</a></p>' if reimbursement_request.payment_receipt_url else ''}
                        </div>
                        
                        <p>Please review and take necessary action.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Reimbursement Request

            A new reimbursement request has been submitted:

            Employee: {reimbursement_request.employee.full_name}
            Category: {reimbursement_request.category.title()}
            Amount: ₹{reimbursement_request.amount:,.2f}
            Date: {expense_date}
            Project: {reimbursement_request.project.name}
            Description: {reimbursement_request.description or 'Not specified'}
            Request ID: {reimbursement_request.reimbursement_id}
            Bill Receipt: {reimbursement_request.bill_receipt_url}
            {f'Payment Receipt: {reimbursement_request.payment_receipt_url}' if reimbursement_request.payment_receipt_url else ''}

            Please review and take necessary action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Reimbursement request notification email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send reimbursement request notification email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_reimbursement_status_update_email(reimbursement_request, status, recipients, comments=None):
        """
        Send reimbursement request status update notification email
        
        Args:
            reimbursement_request (ReimbursementRequest): The reimbursement request object
            status (str): New status of the reimbursement request
            recipients (list): List of recipient email addresses
            comments (str): Comments from the approver (optional)
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Reimbursement Request {status.title()}: {reimbursement_request.employee.full_name}"
            
            # Format date
            expense_date = reimbursement_request.date.strftime('%d %b %Y')
            
            # Get approver name
            approver_name = reimbursement_request.approved_by.full_name if reimbursement_request.approved_by else 'HR Team'
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .expense-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .status-update {{
                            background: {'#d4edda' if status == 'approved' else '#f8d7da'};
                            border: 1px solid {'#c3e6cb' if status == 'approved' else '#f5c6cb'};
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                            color: {'#155724' if status == 'approved' else '#721c24'};
                        }}
                        .amount {{
                            font-size: 24px;
                            color: #2A5CAA;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .request-id {{
                            background: #e9ecef;
                            padding: 10px;
                            border-radius: 4px;
                            margin: 10px 0;
                            font-family: monospace;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>💰 Reimbursement Request Update</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear {reimbursement_request.employee.full_name},</p>
                        
                        <div class="status-update">
                            <h2>Your reimbursement request has been <strong>{status.upper()}</strong></h2>
                            <div class="request-id">
                                <strong>Request ID:</strong> {reimbursement_request.reimbursement_id}
                            </div>
                            <p>By: {approver_name}</p>
                            {f'<p><strong>Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <div class="expense-details">
                            <p><strong>Category:</strong> {reimbursement_request.category.title()}</p>
                            <p class="amount">₹{reimbursement_request.amount:,.2f}</p>
                            <p><strong>Date:</strong> {expense_date}</p>
                            <p><strong>Project:</strong> {reimbursement_request.project.name}</p>
                            <p><strong>Description:</strong> {reimbursement_request.description or 'Not specified'}</p>
                            <p><strong>Bill Receipt:</strong> <a href="{reimbursement_request.bill_receipt_url}">View Receipt</a></p>
                            {f'<p><strong>Payment Receipt:</strong> <a href="{reimbursement_request.payment_receipt_url}">View Receipt</a></p>' if reimbursement_request.payment_receipt_url else ''}
                        </div>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Reimbursement Request Update

            Your reimbursement request has been {status.upper()}
            Request ID: {reimbursement_request.reimbursement_id}
            By: {approver_name}
            {f'Comments: {comments}' if comments else ''}

            Category: {reimbursement_request.category.title()}
            Amount: ₹{reimbursement_request.amount:,.2f}
            Date: {expense_date}
            Project: {reimbursement_request.project.name}
            Description: {reimbursement_request.description or 'Not specified'}
            Bill Receipt: {reimbursement_request.bill_receipt_url}
            {f'Payment Receipt: {reimbursement_request.payment_receipt_url}' if reimbursement_request.payment_receipt_url else ''}

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Reimbursement request status update email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send reimbursement request status update email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_travel_request_email(travel_request, recipients):
        """
        Send travel request notification email to multiple recipients
        
        Args:
            travel_request (TravelRequest): The travel request object
            recipients (list): List of recipient email addresses
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            subject = f"Travel Request: {travel_request.employee.full_name}"
            
            # Format dates
            from_date = travel_request.from_date.strftime('%d %b %Y')
            to_date = travel_request.to_date.strftime('%d %b %Y')
            
            # Create document links HTML
            
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .travel-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .route {{
                            display: flex;
                            align-items: center;
                            margin: 20px 0;
                            padding: 15px;
                            background: #fff;
                            border: 1px solid #e0e0e0;
                            border-radius: 8px;
                        }}
                        .route-arrow {{
                            margin: 0 15px;
                            color: #2A5CAA;
                            font-size: 20px;
                        }}
                        .location {{
                            flex: 1;
                            text-align: center;
                        }}
                        .amount {{
                            font-size: 24px;
                            color: #2A5CAA;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>✈️ Travel Request</h1>
                    </div>
                    
                    <div class="content">
                        <p>Dear Team,</p>
                        
                        <p>A new travel request has been submitted:</p>
                        
                        <div class="travel-details">
                            <p><strong>Employee:</strong> {travel_request.employee.full_name}</p>
                            <p><strong>Project:</strong> {travel_request.project.name}</p>
                            
                            <div class="route">
                                <div class="location">
                                    <strong>Travel Location:</strong><br>
                                    {travel_request.travel_location}
                                </div>
                            </div>
                            
                            <p><strong>Dates:</strong> {from_date} to {to_date}</p>
                            <p><strong>Subject:</strong> {travel_request.subject or 'Not specified'}</p>
                            
                        </div>
                        
                        <p>Please review and take necessary action.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version as fallback
            text_content = f"""
            Travel Request

            A new travel request has been submitted:

            Employee: {travel_request.employee.full_name}
            Project: {travel_request.project.name}
            
            Travel Location: {travel_request.travel_location}
            Dates: {from_date} to {to_date}
            Subject: {travel_request.subject or 'Not specified'}
            {f'Request Amount: ₹{travel_request.estimated_expense:,.2f}' if travel_request.estimated_expense else ''}

            Please review and take necessary action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Travel request notification email sent successfully to {', '.join(recipients)}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send travel request notification email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_travel_status_update_email(travel_request, status, recipients, comments=None):
        """
        Send travel request status update email
        
        Args:
            travel_request: TravelRequest object
            status (str): New status
            recipients (list): List of recipient email addresses
            comments (str): Optional comments from HR
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Format dates
            from_date = travel_request.from_date.strftime('%d %B %Y')
            to_date = travel_request.to_date.strftime('%d %B %Y')
            
            # Status-specific content
            status_info = {
                'pending': {
                    'color': '#FFA500',
                    'icon': '⏳',
                    'message': 'Your travel request is currently under review.'
                },
                'approved': {
                    'color': '#28A745',
                    'icon': '✅',
                    'message': 'Your travel request has been approved!'
                },
                'rejected': {
                    'color': '#DC3545',
                    'icon': '❌',
                    'message': 'Your travel request has been rejected.'
                }
            }
            
            status_data = status_info.get(status, status_info['pending'])
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .status-box {{
                            background: {status_data['color']}15;
                            border: 2px solid {status_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .status-icon {{
                            font-size: 48px;
                            margin-bottom: 10px;
                        }}
                        .status-text {{
                            color: {status_data['color']};
                            font-size: 24px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>✈️ Travel Request Update</h1>
                        <p>Status: {status.title()}</p>
                    </div>
                    
                    <div class="content">
                        <p>Dear <strong>{travel_request.employee.full_name}</strong>,</p>
                        
                        <div class="status-box">
                            <div class="status-icon">{status_data['icon']}</div>
                            <div class="status-text">{status.title()}</div>
                            <p>{status_data['message']}</p>
                        </div>
                        
                        <div class="details-box">
                            <h3>Travel Request Details:</h3>
                            <p><strong>Subject:</strong> {travel_request.subject}</p>
                            <p><strong>Destination:</strong> {travel_request.travel_location}</p>
                            <p><strong>Travel Period:</strong> {from_date} to {to_date}</p>
                            <p><strong>Mode of Transport:</strong> {travel_request.mode_of_transport}</p>
                            <p><strong>Estimated Expense:</strong> ₹{travel_request.estimated_expense}</p>
                            {f'<p><strong>Project:</strong> {travel_request.project.name}</p>' if travel_request.project else ''}
                        </div>
                        
                        {f'<div class="details-box"><h3>HR Comments:</h3><p>{comments}</p></div>' if comments else ''}
                        
                        <p>If you have any questions, please contact the HR department.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            Travel Request Status Update

            Dear {travel_request.employee.full_name},

            Your travel request has been {status}.

            Travel Request Details:
            - Subject: {travel_request.subject}
            - Destination: {travel_request.travel_location}
            - Travel Period: {from_date} to {to_date}
            - Mode of Transport: {travel_request.mode_of_transport}
            - Estimated Expense: ₹{travel_request.estimated_expense}
            {f'- Project: {travel_request.project.name}' if travel_request.project else ''}

            {f'HR Comments: {comments}' if comments else ''}

            If you have any questions, please contact the HR department.

            Thank you,
            The Digital HR Team
            """
            
            # Send email to all recipients
            for recipient in recipients:
                email = EmailMultiAlternatives(
                    subject=f'Travel Request {status.title()} - {travel_request.subject}',
                    body=text_content,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=[recipient]
                )
                email.attach_alternative(html_content, "text/html")
                email.send()
            
            logger.info(f"Travel status update email sent successfully to {recipients}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send travel status update email: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_complaint_notification(recipient_emails, employee_name, complaint_title, priority, description, attachment_count=0):
        """
        Send complaint notification email to multiple recipients
        
        Args:
            recipient_emails (list): List of recipient email addresses (employee + HR managers)
            employee_name (str): Name of the employee who created the complaint
            complaint_title (str): Title of the complaint
            priority (str): Priority level of the complaint
            description (str): Description of the complaint
            attachment_count (int): Number of attachments
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Priority-specific styling
            priority_info = {
                'low': {'color': '#28A745', 'icon': '🟢'},
                'medium': {'color': '#FFC107', 'icon': '🟡'},
                'high': {'color': '#DC3545', 'icon': '🔴'},
                'urgent': {'color': '#6F42C1', 'icon': '🟣'}
            }
            
            priority_data = priority_info.get(priority, priority_info['medium'])
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #FF6B35, #F7931E);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .priority-box {{
                            background: {priority_data['color']}15;
                            border: 2px solid {priority_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .priority-icon {{
                            font-size: 32px;
                            margin-bottom: 10px;
                        }}
                        .priority-text {{
                            color: {priority_data['color']};
                            font-size: 20px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>📝 New Complaint Filed</h1>
                        <p>Requires Attention</p>
                    </div>
                    
                    <div class="content">
                        <p>A new complaint has been filed that requires attention.</p>
                        
                        <div class="priority-box">
                            <div class="priority-icon">{priority_data['icon']}</div>
                            <div class="priority-text">{priority.title()} Priority</div>
                        </div>
                        
                        <div class="details-box">
                            <h3>Complaint Details:</h3>
                            <p><strong>Filed By:</strong> {employee_name}</p>
                            <p><strong>Title:</strong> {complaint_title}</p>
                            <p><strong>Priority:</strong> {priority.title()}</p>
                            <p><strong>Description:</strong></p>
                            <p style="background: #fff; padding: 15px; border-radius: 4px; border-left: 4px solid #FF6B35;">{description}</p>
                            {f'<p><strong>Attachments:</strong> {attachment_count} file(s) attached</p>' if attachment_count > 0 else '<p><strong>Attachments:</strong> No files attached</p>'}
                        </div>
                        
                        <p><strong>Action Required:</strong> Please review this complaint and take appropriate action.</p>
                        
                        <p>You can access the complaint through the Digital HR system.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            New Complaint Filed - Requires Attention

            A new complaint has been filed that requires attention.

            Complaint Details:
            - Filed By: {employee_name}
            - Title: {complaint_title}
            - Priority: {priority.title()}
            - Description: {description}
            - Attachments: {attachment_count} file(s) attached

            Action Required: Please review this complaint and take appropriate action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'New Complaint: {complaint_title} - {priority.title()} Priority',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipient_emails
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Complaint notification email sent successfully to {len(recipient_emails)} recipients")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send complaint notification email to {len(recipient_emails)} recipients: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_complaint_status_update(to_email, employee_name, complaint_title, status, comments=None):
        """
        Send complaint status update email to employee
        
        Args:
            to_email (str): Employee's email address
            employee_name (str): Name of the employee
            complaint_title (str): Title of the complaint
            status (str): New status of the complaint
            comments (str): Optional comments from HR
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Status-specific content
            status_info = {
                'pending': {
                    'color': '#FFA500',
                    'icon': '⏳',
                    'message': 'Your complaint is currently under review.'
                },
                'in_progress': {
                    'color': '#17A2B8',
                    'icon': '🔄',
                    'message': 'Your complaint is being processed.'
                },
                'resolved': {
                    'color': '#28A745',
                    'icon': '✅',
                    'message': 'Your complaint has been resolved!'
                },
                'closed': {
                    'color': '#6C757D',
                    'icon': '🔒',
                    'message': 'Your complaint has been closed.'
                }
            }
            
            status_data = status_info.get(status, status_info['pending'])
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .status-box {{
                            background: {status_data['color']}15;
                            border: 2px solid {status_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .status-icon {{
                            font-size: 48px;
                            margin-bottom: 10px;
                        }}
                        .status-text {{
                            color: {status_data['color']};
                            font-size: 24px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>📝 Complaint Status Update</h1>
                        <p>Status: {status.replace('_', ' ').title()}</p>
                    </div>
                    
                    <div class="content">
                        <p>Dear <strong>{employee_name}</strong>,</p>
                        
                        <div class="status-box">
                            <div class="status-icon">{status_data['icon']}</div>
                            <div class="status-text">{status.replace('_', ' ').title()}</div>
                            <p>{status_data['message']}</p>
                        </div>
                        
                        <div class="details-box">
                            <h3>Complaint Details:</h3>
                            <p><strong>Title:</strong> {complaint_title}</p>
                            <p><strong>Status:</strong> {status.replace('_', ' ').title()}</p>
                            {f'<p><strong>HR Comments:</strong></p><p style="background: #fff; padding: 15px; border-radius: 4px; border-left: 4px solid #2A5CAA;">{comments}</p>' if comments else ''}
                        </div>
                        
                        <p>If you have any questions, please contact the HR department.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            Complaint Status Update

            Dear {employee_name},

            Your complaint status has been updated to: {status.replace('_', ' ').title()}

            Complaint Details:
            - Title: {complaint_title}
            - Status: {status.replace('_', ' ').title()}
            {f'- HR Comments: {comments}' if comments else ''}

            If you have any questions, please contact the HR department.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'Complaint Status Update: {complaint_title}',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[to_email]
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Complaint status update email sent successfully to {to_email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send complaint status update email to {to_email}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_separation_notification(recipient_emails, employee_name, separation_reason, preferred_date, comments=None, resignation_letter_url=None):
        """
        Send separation request notification email to multiple recipients
        
        Args:
            recipient_emails (list): List of recipient email addresses (employee + HR managers)
            employee_name (str): Name of the employee who created the separation request
            separation_reason (str): Reason for separation
            preferred_date (str): Preferred separation date
            comments (str): Optional comments from employee
            resignation_letter_url (str): Optional URL to the resignation letter
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #DC3545, #C82333);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .alert-box {{
                            background: #f8d7da;
                            border: 2px solid #dc3545;
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .alert-icon {{
                            font-size: 48px;
                            margin-bottom: 10px;
                        }}
                        .alert-text {{
                            color: #721c24;
                            font-size: 24px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                        .document-link {{
                            background: #e3f2fd;
                            border: 1px solid #2196f3;
                            border-radius: 4px;
                            padding: 15px;
                            margin: 15px 0;
                            text-align: center;
                        }}
                        .document-link a {{
                            color: #1976d2;
                            text-decoration: none;
                            font-weight: bold;
                        }}
                        .document-link a:hover {{
                            text-decoration: underline;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🚪 Separation Request</h1>
                        <p>Employee Resignation Notification</p>
                    </div>
                    
                    <div class="content">
                        <p>A separation request has been submitted that requires attention.</p>
                        
                        <div class="alert-box">
                            <div class="alert-icon">⚠️</div>
                            <div class="alert-text">Separation Request</div>
                            <p>Employee has submitted resignation</p>
                        </div>
                        
                        <div class="details-box">
                            <h3>Separation Details:</h3>
                            <p><strong>Employee:</strong> {employee_name}</p>
                            <p><strong>Reason:</strong> {separation_reason.replace('_', ' ').title()}</p>
                            <p><strong>Preferred Date:</strong> {preferred_date}</p>
                            {f'<p><strong>Comments:</strong></p><p style="background: #fff; padding: 15px; border-radius: 4px; border-left: 4px solid #DC3545;">{comments}</p>' if comments else ''}
                            {f'<div class="document-link"><strong>📄 Resignation Letter:</strong><br><a href="{resignation_letter_url}" target="_blank">View Resignation Letter</a></div>' if resignation_letter_url else ''}
                        </div>
                        
                        <p><strong>Action Required:</strong> Please review this separation request and initiate the exit process.</p>
                        
                        <p>You can access the separation request through the Digital HR system.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            Separation Request - Employee Resignation Notification

            A separation request has been submitted that requires attention.

            Separation Details:
            - Employee: {employee_name}
            - Reason: {separation_reason.replace('_', ' ').title()}
            - Preferred Date: {preferred_date}
            {f'- Comments: {comments}' if comments else ''}
            {f'- Resignation Letter: {resignation_letter_url}' if resignation_letter_url else ''}

            Action Required: Please review this separation request and initiate the exit process.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'Separation Request: {employee_name}',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipient_emails
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Separation notification email sent successfully to {len(recipient_emails)} recipients")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send separation notification email to {len(recipient_emails)} recipients: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_separation_status_update(to_email, employee_name, separation_reason, status, comments=None, resignation_letter_url=None):
        """
        Send separation status update email to employee
        
        Args:
            to_email (str): Employee's email address
            employee_name (str): Name of the employee
            separation_reason (str): Reason for separation
            status (str): New status of the separation request
            comments (str): Optional comments from HR
            resignation_letter_url (str): Optional URL to the resignation letter
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Status-specific content
            status_info = {
                'pending': {
                    'color': '#FFA500',
                    'icon': '⏳',
                    'message': 'Your separation request is currently under review.'
                },
                'approved': {
                    'color': '#28A745',
                    'icon': '✅',
                    'message': 'Your separation request has been approved.'
                },
                'rejected': {
                    'color': '#DC3545',
                    'icon': '❌',
                    'message': 'Your separation request has been rejected.'
                }
            }
            
            status_data = status_info.get(status, status_info['pending'])
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #DC3545, #C82333);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .status-box {{
                            background: {status_data['color']}15;
                            border: 2px solid {status_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .status-icon {{
                            font-size: 48px;
                            margin-bottom: 10px;
                        }}
                        .status-text {{
                            color: {status_data['color']};
                            font-size: 24px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                        .document-link {{
                            background: #e3f2fd;
                            border: 1px solid #2196f3;
                            border-radius: 4px;
                            padding: 15px;
                            margin: 15px 0;
                            text-align: center;
                        }}
                        .document-link a {{
                            color: #1976d2;
                            text-decoration: none;
                            font-weight: bold;
                        }}
                        .document-link a:hover {{
                            text-decoration: underline;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🚪 Separation Status Update</h1>
                        <p>Status: {status.title()}</p>
                    </div>
                    
                    <div class="content">
                        <p>Dear <strong>{employee_name}</strong>,</p>
                        
                        <div class="status-box">
                            <div class="status-icon">{status_data['icon']}</div>
                            <div class="status-text">{status.title()}</div>
                            <p>{status_data['message']}</p>
                        </div>
                        
                        <div class="details-box">
                            <h3>Separation Details:</h3>
                            <p><strong>Reason:</strong> {separation_reason.replace('_', ' ').title()}</p>
                            <p><strong>Status:</strong> {status.title()}</p>
                            {f'<p><strong>HR Comments:</strong></p><p style="background: #fff; padding: 15px; border-radius: 4px; border-left: 4px solid #DC3545;">{comments}</p>' if comments else ''}
                            {f'<div class="document-link"><strong>📄 Your Resignation Letter:</strong><br><a href="{resignation_letter_url}" target="_blank">View Resignation Letter</a></div>' if resignation_letter_url else ''}
                        </div>
                        
                        <p>If you have any questions, please contact the HR department.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            Separation Status Update

            Dear {employee_name},

            Your separation request status has been updated to: {status.title()}

            Separation Details:
            - Reason: {separation_reason.replace('_', ' ').title()}
            - Status: {status.title()}
            {f'- HR Comments: {comments}' if comments else ''}
            {f'- Resignation Letter: {resignation_letter_url}' if resignation_letter_url else ''}

            If you have any questions, please contact the HR department.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'Separation Status Update: {status.title()}',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[to_email]
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Separation status update email sent successfully to {to_email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send separation status update email to {to_email}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_device_request_notification(recipient_emails, employee_name, requested_item, urgency, purpose=None, comments=None):
        """
        Send device/peripheral request notification email to multiple recipients
        
        Args:
            recipient_emails (list): List of recipient email addresses (employee + HR managers)
            employee_name (str): Name of the employee who created the request
            requested_item (str): Requested device/peripheral
            urgency (str): Urgency level
            purpose (str): Purpose of the request
            comments (str): Optional comments from employee
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Urgency-specific styling
            urgency_info = {
                'low': {'color': '#28A745', 'icon': '🟢'},
                'medium': {'color': '#FFC107', 'icon': '🟡'},
                'high': {'color': '#DC3545', 'icon': '🔴'}
            }
            
            urgency_data = urgency_info.get(urgency, urgency_info['medium'])
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .urgency-box {{
                            background: {urgency_data['color']}15;
                            border: 2px solid {urgency_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .urgency-icon {{
                            font-size: 32px;
                            margin-bottom: 10px;
                        }}
                        .urgency-text {{
                            color: {urgency_data['color']};
                            font-size: 20px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>💻 Device/Peripheral Request</h1>
                        <p>Requires IT/HR Attention</p>
                    </div>
                    
                    <div class="content">
                        <p>A new device/peripheral request has been submitted that requires attention.</p>
                        
                        <div class="urgency-box">
                            <div class="urgency-icon">{urgency_data['icon']}</div>
                            <div class="urgency-text">{urgency.title()} Urgency</div>
                        </div>
                        
                        <div class="details-box">
                            <h3>Request Details:</h3>
                            <p><strong>Employee:</strong> {employee_name}</p>
                            <p><strong>Requested Item:</strong> {requested_item.replace('_', ' ').title()}</p>
                            <p><strong>Urgency:</strong> {urgency.title()}</p>
                            {f'<p><strong>Purpose:</strong> {purpose}</p>' if purpose else ''}
                            {f'<p><strong>Comments:</strong></p><p style="background: #fff; padding: 15px; border-radius: 4px; border-left: 4px solid #2A5CAA;">{comments}</p>' if comments else ''}
                        </div>
                        
                        <p><strong>Action Required:</strong> Please review this request and take appropriate action.</p>
                        
                        <p>You can access the request through the Digital HR system.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            Device/Peripheral Request - Requires IT/HR Attention

            A new device/peripheral request has been submitted that requires attention.

            Request Details:
            - Employee: {employee_name}
            - Requested Item: {requested_item.replace('_', ' ').title()}
            - Urgency: {urgency.title()}
            {f'- Purpose: {purpose}' if purpose else ''}
            {f'- Comments: {comments}' if comments else ''}

            Action Required: Please review this request and take appropriate action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'Device Request: {requested_item.replace("_", " ").title()} - {urgency.title()} Urgency',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipient_emails
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Device request notification email sent successfully to {len(recipient_emails)} recipients")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send device request notification email to {len(recipient_emails)} recipients: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_device_request_status_update(to_email, employee_name, requested_item, status, comments=None):
        """
        Send device/peripheral request status update email to employee
        
        Args:
            to_email (str): Employee's email address
            employee_name (str): Name of the employee
            requested_item (str): Requested device/peripheral
            status (str): New status of the request
            comments (str): Optional comments from HR/IT
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Status-specific styling
            status_info = {
                'approved': {'color': '#28A745', 'icon': '✅', 'bg_color': '#d4edda'},
                'rejected': {'color': '#DC3545', 'icon': '❌', 'bg_color': '#f8d7da'},
                'pending': {'color': '#FFC107', 'icon': '⏳', 'bg_color': '#fff3cd'}
            }
            
            status_data = status_info.get(status, status_info['pending'])
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .status-box {{
                            background: {status_data['bg_color']};
                            border: 2px solid {status_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .status-icon {{
                            font-size: 32px;
                            margin-bottom: 10px;
                        }}
                        .status-text {{
                            color: {status_data['color']};
                            font-size: 20px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .details-box {{
                            background: #f8f9fa;
                            padding: 20px;
                            border-radius: 8px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>💻 Device Request Update</h1>
                        <p>Status: {status.title()}</p>
                    </div>
                    
                    <div class="content">
                        <p>Dear {employee_name},</p>
                        
                        <p>Your device/peripheral request has been updated.</p>
                        
                        <div class="status-box">
                            <div class="status-icon">{status_data['icon']}</div>
                            <div class="status-text">{status.title()}</div>
                        </div>
                        
                        <div class="details-box">
                            <h3>Request Details:</h3>
                            <p><strong>Requested Item:</strong> {requested_item.replace('_', ' ').title()}</p>
                            <p><strong>Status:</strong> {status.title()}</p>
                            {f'<p><strong>HR/IT Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <p>If you have any questions, please contact the HR/IT department.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            Device Request Status Update

            Dear {employee_name},

            Your device request status has been updated to: {status.title()}

            Request Details:
            - Requested Item: {requested_item.replace('_', ' ').title()}
            - Status: {status.title()}
            {f'- HR/IT Comments: {comments}' if comments else ''}

            If you have any questions, please contact the HR/IT department.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'Device Request Status Update: {requested_item.replace("_", " ").title()}',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[to_email]
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"Device request status update email sent successfully to {to_email}")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send device request status update email to {to_email}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_ip_patent_request_notification(recipient_emails, employee_name, project_name, protection_type, description, priority_date=None):
        """
        Send IP & Patent Support Request notification email to multiple recipients
        
        Args:
            recipient_emails (list): List of recipient email addresses (HR managers)
            employee_name (str): Name of the employee who created the request
            project_name (str): Name of the project
            protection_type (str): Type of IP protection required
            description (str): Description of the request
            priority_date (str): Priority date for the request
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .request-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .priority-info {{
                            background: #fff3cd;
                            border: 1px solid #ffeaa7;
                            border-radius: 6px;
                            padding: 15px;
                            margin: 15px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🔬 IP & Patent Support Request</h1>
                        <p>Requires Legal/HR Attention</p>
                    </div>
                    
                    <div class="content">
                        <p>A new IP & Patent Support Request has been submitted that requires attention.</p>
                        
                        <div class="request-details">
                            <h3>Request Details:</h3>
                            <p><strong>Employee:</strong> {employee_name}</p>
                            <p><strong>Project:</strong> {project_name}</p>
                            <p><strong>Protection Type:</strong> {protection_type}</p>
                            <p><strong>Description:</strong> {description}</p>
                            {f'<p><strong>Priority Date:</strong> {priority_date}</p>' if priority_date else ''}
                        </div>
                        
                        {f'''
                        <div class="priority-info">
                            <strong>⚠️ Priority Date:</strong> {priority_date}<br>
                            <small>This request has a priority date that may require immediate attention.</small>
                        </div>
                        ''' if priority_date else ''}
                        
                        <p><strong>Action Required:</strong> Please review this request and take appropriate action.</p>
                        
                        <p>You can access the request through the Digital HR system.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            IP & Patent Support Request - Requires Legal/HR Attention

            A new IP & Patent Support Request has been submitted that requires attention.

            Request Details:
            - Employee: {employee_name}
            - Project: {project_name}
            - Protection Type: {protection_type}
            - Description: {description}
            {f'- Priority Date: {priority_date}' if priority_date else ''}

            Action Required: Please review this request and take appropriate action.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'IP & Patent Support Request: {project_name}',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipient_emails
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"IP & Patent Support Request notification email sent successfully to {len(recipient_emails)} recipients")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send IP & Patent Support Request notification email to {len(recipient_emails)} recipients: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def send_ip_patent_status_update_email(ip_patent_request, status, recipients, comments=None):
        """
        Send IP & Patent Support Request status update email to multiple recipients
        
        Args:
            ip_patent_request (IPPatentSupportRequest): The IP patent request object
            status (str): New status of the request
            recipients (list): List of recipient email addresses
            comments (str): Optional comments from HR manager
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Status-specific styling
            status_info = {
                'approved': {'color': '#28A745', 'icon': '✅', 'bg_color': '#d4edda'},
                'rejected': {'color': '#DC3545', 'icon': '❌', 'bg_color': '#f8d7da'},
                'pending': {'color': '#FFC107', 'icon': '⏳', 'bg_color': '#fff3cd'}
            }
            
            status_data = status_info.get(status, status_info['pending'])
            
            # Format priority date
            priority_date = ip_patent_request.priority_date.strftime('%d %b %Y') if ip_patent_request.priority_date else 'Not specified'
            
            # Create HTML email content
            html_content = f"""
            <html>
                <head>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            line-height: 1.6;
                            color: #333;
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }}
                        .header {{
                            background: linear-gradient(135deg, #2A5CAA, #1E4A96);
                            color: white;
                            padding: 20px;
                            text-align: center;
                            border-radius: 8px 8px 0 0;
                        }}
                        .content {{
                            background: #ffffff;
                            padding: 30px;
                            border: 1px solid #e0e0e0;
                        }}
                        .status-box {{
                            background: {status_data['bg_color']};
                            border: 2px solid {status_data['color']};
                            border-radius: 8px;
                            padding: 20px;
                            text-align: center;
                            margin: 20px 0;
                        }}
                        .status-icon {{
                            font-size: 32px;
                            margin-bottom: 10px;
                        }}
                        .status-text {{
                            color: {status_data['color']};
                            font-size: 20px;
                            font-weight: bold;
                            margin: 10px 0;
                        }}
                        .request-details {{
                            background: #f8f9fa;
                            border: 2px solid #2A5CAA;
                            border-radius: 8px;
                            padding: 20px;
                            margin: 20px 0;
                        }}
                        .footer {{
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            border-radius: 0 0 8px 8px;
                            border-top: 1px solid #e0e0e0;
                        }}
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>🔬 IP & Patent Support Request Update</h1>
                        <p>Status: {status.title()}</p>
                    </div>
                    
                    <div class="content">
                        <p>The status of an IP & Patent Support Request has been updated.</p>
                        
                        <div class="status-box">
                            <div class="status-icon">{status_data['icon']}</div>
                            <div class="status-text">{status.title()}</div>
                        </div>
                        
                        <div class="request-details">
                            <h3>Request Details:</h3>
                            <p><strong>Employee:</strong> {ip_patent_request.created_by.full_name}</p>
                            <p><strong>Project:</strong> {ip_patent_request.project_name}</p>
                            <p><strong>Protection Type:</strong> {ip_patent_request.get_protection_type_display()}</p>
                            <p><strong>Description:</strong> {ip_patent_request.description}</p>
                            <p><strong>Priority Date:</strong> {priority_date}</p>
                            <p><strong>Status:</strong> {status.title()}</p>
                            {f'<p><strong>Comments:</strong> {comments}</p>' if comments else ''}
                        </div>
                        
                        <p>Please review the updated request and take any necessary follow-up actions.</p>
                    </div>
                    
                    <div class="footer">
                        <p>Thank you,<br>
                        <strong>The Digital HR Team</strong></p>
                        
                        <p><small>This is an automated message. Please do not reply to this email.</small></p>
                    </div>
                </body>
            </html>
            """
            
            # Create plain text version
            text_content = f"""
            IP & Patent Support Request Status Update

            The status of an IP & Patent Support Request has been updated.

            Request Details:
            - Employee: {ip_patent_request.created_by.full_name}
            - Project: {ip_patent_request.project_name}
            - Protection Type: {ip_patent_request.get_protection_type_display()}
            - Description: {ip_patent_request.description}
            - Priority Date: {priority_date}
            - Status: {status.title()}
            {f'- Comments: {comments}' if comments else ''}

            Please review the updated request and take any necessary follow-up actions.

            Thank you,
            The Digital HR Team
            """
            
            # Create email message
            email = EmailMultiAlternatives(
                subject=f'IP & Patent Support Request Status Update: {ip_patent_request.project_name}',
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=recipients
            )
            
            # Attach HTML version
            email.attach_alternative(html_content, "text/html")
            
            # Send email
            email.send()
            
            logger.info(f"IP & Patent Support Request status update email sent successfully to {len(recipients)} recipients")
            return True, None
            
        except Exception as e:
            error_msg = f"Failed to send IP & Patent Support Request status update email to {len(recipients)} recipients: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

def send_daily_eod_report():
    """
    Send daily EOD report to all employees with their clock in/out times and tasks
    """
    try:
        # Initialize Firebase
        if not firebase_admin._apps:
            cred = credentials.Certificate("digital-hr-production-firebase-adminsdk-fbsvc-d43b5b534c.json")
            firebase_admin.initialize_app(cred)
        db = firestore.client()
        
        # Get today's date in required format
        today = datetime.now().strftime('%d %B %Y')
        
        # Get all employees
        employees_ref = db.collection("employees")
        employee_docs = employees_ref.stream()
        
        # Prepare data for email
        rows = []
        for emp in employee_docs:
            email = emp.id
            data = emp.to_dict()
            tasks_by_date = data.get("tasks", {})
            
            # Get today's data
            today_data = tasks_by_date.get(today, {})
            
            # Process clock in/out times
            clock_in_time = today_data.get("clockInTime", "")
            if clock_in_time:
                if isinstance(clock_in_time, datetime):
                    clock_in_time = clock_in_time + timedelta(hours=5, minutes=30)
                else:
                    clock_in_time = datetime.fromtimestamp(clock_in_time/1000) + timedelta(hours=5, minutes=30)
                clock_in_time = clock_in_time.strftime('%I:%M %p')
            
            clock_out_time = today_data.get("clockOutTime", "")
            if clock_out_time:
                if isinstance(clock_out_time, datetime):
                    clock_out_time = clock_out_time + timedelta(hours=5, minutes=30)
                else:
                    clock_out_time = datetime.fromtimestamp(clock_out_time/1000) + timedelta(hours=5, minutes=30)
                clock_out_time = clock_out_time.strftime('%I:%M %p')
            
            # Process tasks
            tasks_completed = []
            project_ids = [key for key in today_data.keys() if isinstance(today_data[key], dict)]
            
            for project_id in project_ids:
                project_data = today_data[project_id]
                epic = project_data.get("epic", "")
                project_name = project_data.get("project", "")
                key_update = project_data.get('keyUpdate', "")
                seconds_worked = project_data.get('seconds', 0)
                hours_worked = round((seconds_worked / 3600), 2)
                
                tasks_completed.append({
                    "Project": project_name,
                    "Epic": epic,
                    "Key Update": key_update,
                    "Hours Worked": hours_worked,
                })
            
            # Calculate total hours worked
            total_hours = sum(task['Hours Worked'] for task in tasks_completed)
            
            rows.append({
                "Employee Email": email,
                "Clock In": clock_in_time or "Not Clocked In",
                "Clock Out": clock_out_time or "Not Clocked Out",
                "Total Hours": f"{total_hours:.2f}",
                "Tasks": tasks_completed
            })
        
        # Create HTML table
        html_content = f"""
        <html>
        <head>
            <style>
                table {{
                    border-collapse: collapse;
                    width: 100%;
                    margin-bottom: 20px;
                }}
                th, td {{
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }}
                th {{
                    background-color: #f2f2f2;
                }}
                .task-table {{
                    margin-top: 10px;
                    font-size: 0.9em;
                }}
                .task-table th, .task-table td {{
                    padding: 4px;
                }}
            </style>
        </head>
        <body>
            <h2>Daily EOD Report - {today}</h2>
            <table>
                <tr>
                    <th>Employee</th>
                    <th>Clock In</th>
                    <th>Clock Out</th>
                    <th>Total Hours</th>
                    <th>Tasks</th>
                </tr>
        """
        
        for row in rows:
            tasks_html = ""
            if row['Tasks']:
                tasks_html = "<table class='task-table'>"
                tasks_html += "<tr><th>Project</th><th>Epic</th><th>Update</th><th>Hours</th></tr>"
                for task in row['Tasks']:
                    tasks_html += f"""
                    <tr>
                        <td>{task['Project']}</td>
                        <td>{task['Epic']}</td>
                        <td>{task['Key Update']}</td>
                        <td>{task['Hours Worked']:.2f}</td>
                    </tr>
                    """
                tasks_html += "</table>"
            
            html_content += f"""
            <tr>
                <td>{row['Employee Email']}</td>
                <td>{row['Clock In']}</td>
                <td>{row['Clock Out']}</td>
                <td>{row['Total Hours']}</td>
                <td>{tasks_html}</td>
            </tr>
            """
        
        html_content += """
            </table>
        </body>
        </html>
        """
        
        # Send email
        subject = f"Daily EOD Report - {today}"
        from_email = settings.DEFAULT_FROM_EMAIL
        recipient_list = [settings.ADMIN_EMAIL]  # Add more recipients as needed
        
        send_mail(
            subject=subject,
            message=strip_tags(html_content),  # Plain text version
            from_email=from_email,
            recipient_list=recipient_list,
            html_message=html_content,
            fail_silently=False,
        )
        
        return True, "EOD report sent successfully"
        
    except Exception as e:
        return False, f"Error sending EOD report: {str(e)}" 