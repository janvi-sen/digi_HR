from django.contrib import admin
from .models import (
    Leave, WFH, Reimbursement, TravelRequest, EmergencyFundRequest, 
    CompOffCreditRequest, Complaint, ComplaintAttachment, Separation, 
    DevicesPeripherals, IPPatentSupportRequest, IPPatentSupportAttachment
)

# Register your models here.
admin.site.register(Leave)
admin.site.register(WFH)
admin.site.register(Reimbursement)
admin.site.register(TravelRequest)
admin.site.register(EmergencyFundRequest)
admin.site.register(CompOffCreditRequest)
admin.site.register(Separation)
admin.site.register(DevicesPeripherals)
admin.site.register(IPPatentSupportRequest)
admin.site.register(IPPatentSupportAttachment)