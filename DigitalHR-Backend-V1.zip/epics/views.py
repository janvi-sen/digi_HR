from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.core.paginator import Paginator
from django.db.models import Q

from .models import Epic
from .serializers import EpicSerializer, EpicListSerializer
from utils.general_utils import ApiResponse

# Create your views here.

@swagger_auto_schema(
    method='post',
    operation_description="Create a new epic",
    request_body=EpicSerializer,
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Epic created successfully",
            schema=EpicSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_epic(request):
    """Create a new epic"""
    serializer = EpicSerializer(data=request.data)
    if serializer.is_valid():
        epic = serializer.save(created_by=request.user)
        return ApiResponse.created(
            data=serializer.data,
            message="Epic created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='get',
    operation_description="Get list of epics with pagination and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('project_id', openapi.IN_QUERY, description="Filter by project", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('priority', openapi.IN_QUERY, description="Filter by priority", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search by title", type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response(
            description="Epics retrieved successfully",
            schema=EpicListSerializer(many=True)
        ),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_epics(request):
    """Get paginated list of epics with filtering options"""
    # Get query parameters
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    project_id = request.GET.get('project_id', '')
    status_filter = request.GET.get('status', '')
    priority_filter = request.GET.get('priority', '')
    search = request.GET.get('search', '')
    
    # Build query
    queryset = Epic.objects.all()
    
    # Apply filters
    if project_id:
        queryset = queryset.filter(project_id=project_id)
    
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    if priority_filter:
        queryset = queryset.filter(priority=priority_filter)
    
    if search:
        queryset = queryset.filter(
            Q(name__icontains=search) |
            Q(description__icontains=search)
        )
    
    # Order by created date
    queryset = queryset.order_by('-created_at')
    
    # Paginate
    paginator = Paginator(queryset, page_size)
    
    try:
        epics_page = paginator.page(page)
    except:
        return ApiResponse.error(
            message="Invalid page number",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Serialize data
    serializer = EpicListSerializer(epics_page.object_list, many=True)
    
    # Build pagination response
    pagination_data = {
        'count': paginator.count,
        'page': page,
        'page_size': page_size,
        'total_pages': paginator.num_pages,
        'has_next': epics_page.has_next(),
        'has_previous': epics_page.has_previous(),
        'results': serializer.data
    }
    
    return ApiResponse.success(
        data=pagination_data,
        message="Epics retrieved successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get epic details by ID",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Epic details retrieved successfully",
            schema=EpicSerializer
        ),
        404: openapi.Response(description="Epic not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_epic_detail(request, epic_id):
    """Get detailed information about a specific epic"""
    try:
        epic = Epic.objects.get(id=epic_id)
    except Epic.DoesNotExist:
        return ApiResponse.not_found("Epic not found")
    
    serializer = EpicSerializer(epic)
    
    return ApiResponse.success(
        data=serializer.data,
        message="Epic details retrieved successfully"
    )

@swagger_auto_schema(
    method='put',
    operation_description="Update epic information",
    request_body=EpicSerializer,
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Epic updated successfully",
            schema=EpicSerializer
        ),
        404: openapi.Response(description="Epic not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_epic(request, epic_id):
    """Update epic information"""
    try:
        epic = Epic.objects.get(id=epic_id)
    except Epic.DoesNotExist:
        return ApiResponse.not_found("Epic not found")
    
    serializer = EpicSerializer(epic, data=request.data, partial=True)
    
    if serializer.is_valid():
        updated_epic = serializer.save()
        return ApiResponse.success(
            data=serializer.data,
            message="Epic updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='delete',
    operation_description="Delete an epic",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(description="Epic deleted successfully"),
        404: openapi.Response(description="Epic not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_epic(request, epic_id):
    """Delete an epic"""
    try:
        epic = Epic.objects.get(id=epic_id)
    except Epic.DoesNotExist:
        return ApiResponse.not_found("Epic not found")
    
    epic.delete()
    
    return ApiResponse.success(
        message="Epic deleted successfully"
    )
