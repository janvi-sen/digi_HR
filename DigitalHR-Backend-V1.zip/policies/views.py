from django.shortcuts import render
from django.core.paginator import Paginator
from django.db.models import Q
from digitalhr import settings
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.parsers import MultiPartParser, FormParser
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from utils.boto_utils import S3DocumentUploader
from utils.general_utils import ApiResponse
from utils.constants import EXAMPLE_EMAIL
from employees.models import Employee
from .models import Policy, PolicyAcknowledgment, OfficeLocations, PublicHoliday
from .serializers import (
    PolicySerializer, PolicyCreateSerializer, PolicyListSerializer, 
    PolicyAcknowledgmentSerializer, PolicyAcknowledgmentUpdateSerializer,
    OfficeLocationsSerializer, OfficeLocationsCreateSerializer, OfficeLocationsUpdateSerializer,
    PublicHolidaySerializer, PublicHolidayCreateSerializer, PublicHolidayUpdateSerializer, PublicHolidayListSerializer
)
import os
from datetime import datetime

@swagger_auto_schema(
    method='post',
    operation_description="Create or update a policy document (HR Manager only)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'policy_name',
            openapi.IN_FORM,
            description="Name of the policy",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'policy_code',
            openapi.IN_FORM,
            description="Unique code for the policy",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'file',
            openapi.IN_FORM,
            description="PDF file of the policy document",
            type=openapi.TYPE_FILE,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Policy created successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "Policy created successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "policy_name": "Employee Handbook",
                        "policy_code": "EMP_HANDBOOK_2024",
                        "policy_url": "https://s3.amazonaws.com/bucket/policies/...",
                        "policy_version": 1,
                        "is_active": True,
                        "uploaded_by_name": "John Doe"
                    }
                }
            }
        ),
        200: openapi.Response(
            description="Policy updated with new version",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policy updated successfully with version 2",
                    "success": True,
                    "data": {
                        "id": 1,
                        "policy_name": "Employee Handbook",
                        "policy_code": "EMP_HANDBOOK_2024",
                        "policy_url": "https://s3.amazonaws.com/bucket/policies/...",
                        "policy_version": 2,
                        "is_active": True,
                        "uploaded_by_name": "John Doe"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error or invalid file"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can create/update policies")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_or_update_policy(request):
    """Create a new policy or update existing policy with incremental version"""
    try:
        # Check if user is HR manager
        employee = Employee.objects.get(email=request.user.email_id)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can create or update policies",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Validate input data
        serializer = PolicyCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        policy_name = serializer.validated_data['policy_name']
        policy_code = serializer.validated_data['policy_code']
        
        # Validate file
        file = request.FILES.get('file')
        if not file:
            return ApiResponse.error(
                message="Policy document file is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate file type (PDF only)
        if not file.content_type == 'application/pdf':
            return ApiResponse.error(
                message="Only PDF files are allowed for policy documents",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Check if policy already exists
        existing_policy = Policy.objects.filter(
            policy_code=policy_code,
            is_active=True
        ).first()
        
        if existing_policy:
            # Update existing policy with new version
            new_version = existing_policy.policy_version + 1
            
            # Upload new document to S3 with version in filename
            uploader = S3DocumentUploader()
            success, result = uploader.upload_document(
                email_id=request.user.email_id,
                document_collection="policies",
                other_prefix=f"{policy_code}_v{new_version}",
                document_type=policy_name,
                file=file,
            )
            
            if not success:
                return ApiResponse.error(
                    message=f"Failed to upload policy document: {result}",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            
            # Update existing policy
            existing_policy.policy_name = policy_name
            existing_policy.policy_url = result
            existing_policy.policy_version = new_version
            existing_policy.uploaded_by = employee
            existing_policy.save()
            
            serializer = PolicySerializer(existing_policy)
            return ApiResponse.success(
                data=serializer.data,
                message=f"Policy updated successfully with version {new_version}"
            )
        
        else:
            # Create new policy
            # Upload document to S3
            uploader = S3DocumentUploader()
            success, result = uploader.upload_document(
                email_id=request.user.email_id,
                document_collection="policies",
                other_prefix=f"{policy_code}_v1",
                document_type=policy_name,
                file=file,
            )
            
            if not success:
                return ApiResponse.error(
                    message=f"Failed to upload policy document: {result}",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            
            # Create new policy
        policy = Policy.objects.create(
            policy_name=policy_name,
            policy_code=policy_code,
            uploaded_by=employee,
                policy_url=result,
            policy_version=1,
            is_active=True
            )
            
        serializer = PolicySerializer(policy)
        return ApiResponse.created(
            data=serializer.data,
            message="Policy created successfully"
        )
            
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get list of all policies with pagination and search",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'page',
            openapi.IN_QUERY,
            description="Page number",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'page_size',
            openapi.IN_QUERY,
            description="Items per page (default: 20)",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'search',
            openapi.IN_QUERY,
            description="Search by policy name or code",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'is_active',
            openapi.IN_QUERY,
            description="Filter by active status",
            type=openapi.TYPE_BOOLEAN,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Policies retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policies retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 15,
                        "page": 1,
                        "page_size": 20,
                        "total_pages": 1,
                        "has_next": False,
                        "has_previous": False,
                        "results": [
                            {
                                "id": 1,
                                "policy_name": "Employee Handbook",
                                "policy_code": "EMP_HANDBOOK_2024",
                                "uploaded_by_name": "John Doe",
                                "uploaded_by_email": "john.doe@company.com",
                                "policy_url": "https://s3.amazonaws.com/bucket/policies/...",
                                "policy_version": 2,
                                "is_active": True,
                                "created_at": "2024-01-15T10:30:00Z",
                                "updated_at": "2024-01-20T14:45:00Z"
                            }
                        ]
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_policies(request):
    """Get paginated list of policies with search and filtering"""
    try:
        # Get query parameters
        page = int(request.GET.get('page', 1))
        page_size = int(request.GET.get('page_size', 20))
        search = request.GET.get('search', '').strip()
        is_active = request.GET.get('is_active')
        
        # Build query
        queryset = Policy.objects.all().select_related('uploaded_by')
        
        # Apply search filter
        if search:
            queryset = queryset.filter(
                Q(policy_name__icontains=search) |
                Q(policy_code__icontains=search)
            )
        
        # Apply active status filter
        if is_active is not None:
            is_active = is_active.lower() == 'true'
            queryset = queryset.filter(is_active=is_active)
        
        # Order by latest first
        queryset = queryset.order_by('-updated_at', '-created_at')
        
        # Paginate
        paginator = Paginator(queryset, page_size)
        
        try:
            policies_page = paginator.page(page)
        except:
            return ApiResponse.error(
                message="Invalid page number",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Serialize data
        serializer = PolicyListSerializer(policies_page.object_list, many=True)
        
        # Build pagination response
        pagination_data = {
            'count': paginator.count,
            'page': page,
            'page_size': page_size,
            'total_pages': paginator.num_pages,
            'has_next': policies_page.has_next(),
            'has_previous': policies_page.has_previous(),
            'results': serializer.data
        }
        
        return ApiResponse.success(
            data=pagination_data,
            message="Policies retrieved successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get detailed information about a specific policy",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Policy details retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policy details retrieved successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "policy_name": "Employee Handbook",
                        "policy_code": "EMP_HANDBOOK_2024",
                        "uploaded_by": {
                            "id": 1,
                            "full_name": "John Doe",
                            "email": "john.doe@company.com"
                        },
                        "uploaded_by_name": "John Doe",
                        "policy_url": "https://s3.amazonaws.com/bucket/policies/...",
                        "policy_version": 2,
                        "is_active": True,
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-20T14:45:00Z"
                    }
                }
            }
        ),
        404: openapi.Response(description="Policy not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_policy_detail(request, policy_id):
    """Get detailed information about a specific policy"""
    try:
        policy = Policy.objects.select_related('uploaded_by').get(id=policy_id)
        serializer = PolicySerializer(policy)
        
        return ApiResponse.success(
            data=serializer.data,
            message="Policy details retrieved successfully"
        )
        
    except Policy.DoesNotExist:
        return ApiResponse.not_found("Policy not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='put',
    operation_description="Update policy status (activate/deactivate) - HR Manager only",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['is_active'],
        properties={
            'is_active': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Active status of the policy"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Policy status updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policy status updated successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "policy_name": "Employee Handbook",
                        "policy_code": "EMP_HANDBOOK_2024",
                        "is_active": False,
                        "policy_version": 2
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update policy status"),
        404: openapi.Response(description="Policy not found")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_policy_status(request, policy_id):
    """Update policy status (activate/deactivate) - HR Manager only"""
    try:
        # Check if user is HR manager
        employee = Employee.objects.get(email=request.user.email_id)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can update policy status",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Get policy
        policy = Policy.objects.get(id=policy_id)
        
        # Validate input
        is_active = request.data.get('is_active')
        if is_active is None:
            return ApiResponse.error(
                message="is_active field is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        if not isinstance(is_active, bool):
            return ApiResponse.error(
                message="is_active must be a boolean value",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Update policy status
        policy.is_active = is_active
        policy.save()
        
        serializer = PolicySerializer(policy)
        
        status_text = "activated" if is_active else "deactivated"
        return ApiResponse.success(
            data=serializer.data,
            message=f"Policy {status_text} successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Policy.DoesNotExist:
        return ApiResponse.not_found("Policy not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get Terms and Conditions policy",
    responses={
        200: openapi.Response(
            description="Terms and Conditions policy retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Terms and Conditions policy retrieved successfully",
                    "success": True,
                    "data": {
                        "version": "1.0",
                        "content_type": "markdown",
                        "content": "Terms and Conditions policy content"
                    }
                }
            }
        ),
        404: openapi.Response(description="Terms and Conditions policy not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([AllowAny])
def get_terms_and_conditions(request):
    """Get terms and conditions"""
    
    file_path = os.path.join(settings.BASE_DIR, 'policies/static/terms_and_conditions.md')
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            data = {
                "version": "1.0",
                "content_type": "markdown",
                "content": content,
                "url": "https://digihr.s3.ap-south-1.amazonaws.com/sciverse/policies/privacy_policy.html"
            }
            return ApiResponse.success(data=data, message=f'Terms and Conditions')
    except FileNotFoundError:
        return ApiResponse.error(message="Not found", status_code=status.HTTP_404_NOT_FOUND)
    

@swagger_auto_schema(
    method='get',
    operation_description="Get privacy policy",
    responses={
        200: openapi.Response(
            description="Privacy policy retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Privacy policy retrieved successfully",
                    "success": True,
                    "data": {
                        "version": "1.0",
                        "content_type": "markdown",
                        "content": "Privacy policy content"
                    }
                }
            }
        ),
        404: openapi.Response(description="Privacy policy not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([AllowAny])
def get_privacy_policy(request):
    """Get terms and conditions"""
    
    file_path = os.path.join(settings.BASE_DIR, 'policies/static/privacy_policy.md')
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            data = {
                "version": "1.0",
                "content_type": "markdown",
                "content": content
            }
            return ApiResponse.success(data=data, message=f'Privacy Policy')
    except FileNotFoundError:
        return ApiResponse.error(message="Not found", status_code=status.HTTP_404_NOT_FOUND)

@swagger_auto_schema(
    method='post',
    operation_description="Create a new policy acknowledgment",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['policy_id', 'acknowledged_date'],
        properties={
            'policy_id': openapi.Schema(
                type=openapi.TYPE_INTEGER,
                description="ID of the policy"
            ),
            'acknowledged_date': openapi.Schema(
                type=openapi.TYPE_STRING,
                format="date",
                description="Date when the policy was acknowledged"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Policy acknowledgment created successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "Policy acknowledgment created successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "policy_id": 1,
                        "acknowledged_date": "2024-01-15"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can create policy acknowledgments")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_policy_acknowledgment(request):
    """Create a new policy acknowledgment"""
    try:
        # Check if user is HR manager
        employee = Employee.objects.get(email=request.user.email_id)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can create policy acknowledgments",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Validate input data
        serializer = PolicyAcknowledgmentSerializer(data=request.data)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        policy_id = serializer.validated_data['policy_id']
        acknowledged_date = serializer.validated_data['acknowledged_date']
        
        # Validate policy existence
        policy = Policy.objects.get(id=policy_id)
        
        # Create policy acknowledgment
        acknowledgment = PolicyAcknowledgment.objects.create(
            policy=policy,
            employee=employee,
            acknowledged_date=acknowledged_date
        )
        
        serializer = PolicyAcknowledgmentSerializer(acknowledgment)
        return ApiResponse.created(
            data=serializer.data,
            message="Policy acknowledgment created successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Policy.DoesNotExist:
        return ApiResponse.not_found("Policy not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='put',
    operation_description="Update policy acknowledgment status",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['is_acknowledged'],
        properties={
            'is_acknowledged': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Acknowledged status of the policy"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'policy_id',
            openapi.IN_PATH,
            description="ID of the policy",
            type=openapi.TYPE_INTEGER,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Policy acknowledgment status updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policy acknowledgment status updated successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "policy_id": 1,
                        "is_acknowledged": True
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update policy acknowledgments"),
        404: openapi.Response(description="Policy not found")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_policy_acknowledgment_status(request, policy_id):
    """Update policy acknowledgment status"""
    try:
        # Check if user is HR manager
        employee = Employee.objects.get(email=request.user.email_id)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can update policy acknowledgments",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Get policy acknowledgment
        acknowledgment = PolicyAcknowledgment.objects.get(policy_id=policy_id, employee=employee)
        
        # Validate input
        is_acknowledged = request.data.get('is_acknowledged')
        if is_acknowledged is None:
            return ApiResponse.error(
                message="is_acknowledged field is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        if not isinstance(is_acknowledged, bool):
            return ApiResponse.error(
                message="is_acknowledged must be a boolean value",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Update policy acknowledgment status
        acknowledgment.is_acknowledged = is_acknowledged
        acknowledgment.save()
        
        serializer = PolicyAcknowledgmentSerializer(acknowledgment)
        
        status_text = "acknowledged" if is_acknowledged else "unacknowledged"
        return ApiResponse.success(
            data=serializer.data,
            message=f"Policy acknowledgment {status_text} successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except PolicyAcknowledgment.DoesNotExist:
        return ApiResponse.not_found("Policy acknowledgment not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='put',
    operation_description="Employee acknowledges a specific policy (creates or updates acknowledgment)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['acknowledged'],
        properties={
            'acknowledged': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Whether the employee acknowledges the policy (must be True)"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'policy_id',
            openapi.IN_PATH,
            description="ID of the policy to acknowledge",
            type=openapi.TYPE_INTEGER,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Policy acknowledgment updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policy acknowledgment updated successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "employee": 1,
                        "employee_name": "John Doe",
                        "policy": 1,
                        "policy_name": "Employee Handbook",
                        "policy_code": "EMP_HANDBOOK_2024",
                        "acknowledged": True,
                        "acknowledged_at": "2024-01-15T10:30:00Z",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        201: openapi.Response(
            description="Policy acknowledgment created successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "Policy acknowledgment created successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "employee": 1,
                        "employee_name": "John Doe",
                        "policy": 1,
                        "policy_name": "Employee Handbook",
                        "policy_code": "EMP_HANDBOOK_2024",
                        "acknowledged": True,
                        "acknowledged_at": "2024-01-15T10:30:00Z",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Policy not found")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def acknowledge_policy(request, policy_id):
    """Employee acknowledges a specific policy - creates or updates acknowledgment"""
    try:
        # Get the employee
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee:
            return ApiResponse.not_found("Employee not found")
        
        # Get the policy
        try:
            policy = Policy.objects.get(id=policy_id, is_active=True)
        except Policy.DoesNotExist:
            return ApiResponse.not_found("Policy not found or inactive")
        
        # Validate input
        serializer = PolicyAcknowledgmentUpdateSerializer(data=request.data)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        acknowledged = serializer.validated_data['acknowledged']
        
        # Check if acknowledgment already exists
        try:
            acknowledgment = PolicyAcknowledgment.objects.get(
                employee=employee,
                policy=policy
            )
            # Update existing acknowledgment
            acknowledgment.acknowledged = acknowledged
            acknowledgment.acknowledged_at = datetime.now() if acknowledged else None
            acknowledgment.save()
            
            serializer = PolicyAcknowledgmentSerializer(acknowledgment)
            return ApiResponse.success(
                data=serializer.data,
                message="Policy acknowledgment updated successfully"
            )
            
        except PolicyAcknowledgment.DoesNotExist:
            # Create new acknowledgment
            acknowledgment = PolicyAcknowledgment.objects.create(
                employee=employee,
                policy=policy,
                acknowledged=acknowledged,
                acknowledged_at=datetime.now() if acknowledged else None
            )
            
            serializer = PolicyAcknowledgmentSerializer(acknowledgment)
            return ApiResponse.created(
                data=serializer.data,
                message="Policy acknowledgment created successfully"
            )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get all policies with acknowledgment status for the authenticated employee",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'page',
            openapi.IN_QUERY,
            description="Page number",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'page_size',
            openapi.IN_QUERY,
            description="Items per page (default: 20)",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'search',
            openapi.IN_QUERY,
            description="Search by policy name or code",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'is_active',
            openapi.IN_QUERY,
            description="Filter by active status",
            type=openapi.TYPE_BOOLEAN,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Policies with acknowledgment status retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Policies with acknowledgment status retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 3,
                        "page": 1,
                        "page_size": 20,
                        "total_pages": 1,
                        "has_next": False,
                        "has_previous": False,
                        "results": [
                            {
                                "id": 1,
                                "policy_name": "Employee Handbook",
                                "policy_code": "EMP_HANDBOOK_2024",
                                "uploaded_by_name": "John Doe",
                                "uploaded_by_email": "john.doe@company.com",
                                "policy_url": "https://s3.amazonaws.com/bucket/policies/...",
                                "policy_version": 2,
                                "is_active": True,
                                "created_at": "2024-01-15T10:30:00Z",
                                "updated_at": "2024-01-20T14:45:00Z",
                                "acknowledgment_status": {
                                    "acknowledged": True,
                                    "acknowledged_at": "2024-01-15T10:30:00Z",
                                    "acknowledgment_id": 1
                                }
                            },
                            {
                                "id": 2,
                                "policy_name": "Code of Conduct",
                                "policy_code": "CODE_CONDUCT_2024",
                                "uploaded_by_name": "Jane Smith",
                                "uploaded_by_email": "jane.smith@company.com",
                                "policy_url": "https://s3.amazonaws.com/bucket/policies/...",
                                "policy_version": 1,
                                "is_active": True,
                                "created_at": "2024-01-10T09:00:00Z",
                                "updated_at": "2024-01-10T09:00:00Z",
                                "acknowledgment_status": {
                                    "acknowledged": False,
                                    "acknowledged_at": None,
                                    "acknowledgment_id": None
                                }
                            }
                        ]
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_policies_with_acknowledgment_status(request):
    """Get all policies with acknowledgment status for the authenticated employee"""
    try:
        # Get the employee
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee:
            return ApiResponse.not_found("Employee not found")
        
        # Get query parameters
        page = request.GET.get('page', 1)
        page_size = request.GET.get('page_size', 20)
        search = request.GET.get('search', '')
        is_active = request.GET.get('is_active', '')
        
        # Build query
        policies_query = Policy.objects.select_related('uploaded_by')
        
        # Apply filters
        if search:
            policies_query = policies_query.filter(
                Q(policy_name__icontains=search) | Q(policy_code__icontains=search)
            )
        
        if is_active != '':
            is_active_bool = is_active.lower() == 'true'
            policies_query = policies_query.filter(is_active=is_active_bool)
        
        # Order by created_at
        policies_query = policies_query.order_by('-created_at')
        
        # Paginate
        paginator = Paginator(policies_query, page_size)
        try:
            policies_page = paginator.page(page)
        except (ValueError, TypeError):
            policies_page = paginator.page(1)
        
        # Get acknowledgment status for each policy
        results = []
        for policy in policies_page:
            # Check if acknowledgment exists for this employee and policy
            try:
                acknowledgment = PolicyAcknowledgment.objects.get(
                    employee=employee,
                    policy=policy
                )
                acknowledgment_status = {
                    "acknowledged": acknowledgment.acknowledged,
                    "acknowledged_at": acknowledgment.acknowledged_at,
                    "acknowledgment_id": acknowledgment.id
                }
            except PolicyAcknowledgment.DoesNotExist:
                acknowledgment_status = {
                    "acknowledged": False,
                    "acknowledged_at": None,
                    "acknowledgment_id": None
                }
            
            # Create policy data with acknowledgment status
            policy_data = {
                "id": policy.id,
                "policy_name": policy.policy_name,
                "policy_code": policy.policy_code,
                "uploaded_by_name": policy.uploaded_by.full_name,
                "uploaded_by_email": policy.uploaded_by.email,
                "policy_url": policy.policy_url,
                "policy_version": policy.policy_version,
                "is_active": policy.is_active,
                "created_at": policy.created_at,
                "updated_at": policy.updated_at,
                "acknowledgment_status": acknowledgment_status
            }
            results.append(policy_data)
        
        # Prepare response data
        response_data = {
            "count": paginator.count,
            "page": policies_page.number,
            "page_size": int(page_size),
            "total_pages": paginator.num_pages,
            "has_next": policies_page.has_next(),
            "has_previous": policies_page.has_previous(),
            "results": results
        }
        
        return ApiResponse.success(
            data=response_data,
            message="Policies with acknowledgment status retrieved successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new office location (HR Manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['location_name', 'full_address'],
        properties={
            'location_name': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Name of the office location"
            ),
            'full_address': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Complete address of the office location"
            ),
            'is_active': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Whether this location is currently active",
                default=True
            ),
            'lat_long': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Latitude and longitude coordinates (e.g., '40.7128,-74.0060')"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Office location created successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "Office location created successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "location_name": "Main Office",
                        "full_address": "123 Main Street, New York, NY 10001",
                        "is_active": True,
                        "lat_long": "40.7128,-74.0060",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can create office locations")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_office_location(request):
    """Create a new office location - HR Manager only"""
    try:
        # Check if user is HR manager
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can create office locations",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Validate input data
        serializer = OfficeLocationsCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        # Create office location
        office_location = OfficeLocations.objects.create(**serializer.validated_data)
        
        response_serializer = OfficeLocationsSerializer(office_location)
        return ApiResponse.created(
            data=response_serializer.data,
            message="Office location created successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get list of all office locations with pagination and search",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'page',
            openapi.IN_QUERY,
            description="Page number",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'page_size',
            openapi.IN_QUERY,
            description="Items per page (default: 20)",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'search',
            openapi.IN_QUERY,
            description="Search by location name or address",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'is_active',
            openapi.IN_QUERY,
            description="Filter by active status",
            type=openapi.TYPE_BOOLEAN,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Office locations retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Office locations retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 2,
                        "page": 1,
                        "page_size": 20,
                        "total_pages": 1,
                        "has_next": False,
                        "has_previous": False,
                        "results": [
                            {
                                "id": 1,
                                "location_name": "Main Office",
                                "full_address": "123 Main Street, New York, NY 10001",
                                "is_active": True,
                                "lat_long": "40.7128,-74.0060",
                                "created_at": "2024-01-15T10:30:00Z",
                                "updated_at": "2024-01-15T10:30:00Z"
                            }
                        ]
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_office_locations(request):
    """Get list of all office locations with pagination and search"""
    try:
        # Get query parameters
        page = request.GET.get('page', 1)
        page_size = request.GET.get('page_size', 20)
        search = request.GET.get('search', '')
        is_active = request.GET.get('is_active', '')
        
        # Build query
        locations_query = OfficeLocations.objects.all()
        
        # Apply filters
        if search:
            locations_query = locations_query.filter(
                Q(location_name__icontains=search) | Q(full_address__icontains=search)
            )
        
        if is_active != '':
            is_active_bool = is_active.lower() == 'true'
            locations_query = locations_query.filter(is_active=is_active_bool)
        
        # Order by created_at
        locations_query = locations_query.order_by('-created_at')
        
        # Paginate
        paginator = Paginator(locations_query, page_size)
        try:
            locations_page = paginator.page(page)
        except (ValueError, TypeError):
            locations_page = paginator.page(1)
        
        # Serialize results
        serializer = OfficeLocationsSerializer(locations_page, many=True)
        
        # Prepare response data
        response_data = {
            "count": paginator.count,
            "page": locations_page.number,
            "page_size": int(page_size),
            "total_pages": paginator.num_pages,
            "has_next": locations_page.has_next(),
            "has_previous": locations_page.has_previous(),
            "results": serializer.data
        }
        
        return ApiResponse.success(
            data=response_data,
            message="Office locations retrieved successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get detailed information about a specific office location",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Office location details retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Office location details retrieved successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "location_name": "Main Office",
                        "full_address": "123 Main Street, New York, NY 10001",
                        "is_active": True,
                        "lat_long": "40.7128,-74.0060",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        404: openapi.Response(description="Office location not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_office_location_detail(request, location_id):
    """Get detailed information about a specific office location"""
    try:
        office_location = OfficeLocations.objects.get(id=location_id)
        serializer = OfficeLocationsSerializer(office_location)
        
        return ApiResponse.success(
            data=serializer.data,
            message="Office location details retrieved successfully"
        )
        
    except OfficeLocations.DoesNotExist:
        return ApiResponse.not_found("Office location not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='put',
    operation_description="Update office location details (HR Manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'location_name': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Name of the office location"
            ),
            'full_address': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Complete address of the office location"
            ),
            'is_active': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Whether this location is currently active"
            ),
            'lat_long': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Latitude and longitude coordinates (e.g., '40.7128,-74.0060')"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Office location updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Office location updated successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "location_name": "Updated Main Office",
                        "full_address": "456 Updated Street, New York, NY 10001",
                        "is_active": True,
                        "lat_long": "40.7128,-74.0060",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-20T14:45:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update office locations"),
        404: openapi.Response(description="Office location not found")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_office_location(request, location_id):
    """Update office location details - HR Manager only"""
    try:
        # Check if user is HR manager
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can update office locations",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Get office location
        try:
            office_location = OfficeLocations.objects.get(id=location_id)
        except OfficeLocations.DoesNotExist:
            return ApiResponse.not_found("Office location not found")
        
        # Validate input data
        serializer = OfficeLocationsUpdateSerializer(office_location, data=request.data, partial=True)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        # Update office location
        serializer.save()
        
        response_serializer = OfficeLocationsSerializer(office_location)
        return ApiResponse.success(
            data=response_serializer.data,
            message="Office location updated successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='delete',
    operation_description="Delete an office location (HR Manager only)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Office location deleted successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Office location deleted successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "location_name": "Main Office"
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can delete office locations"),
        404: openapi.Response(description="Office location not found")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_office_location(request, location_id):
    """Delete an office location - HR Manager only"""
    try:
        # Check if user is HR manager
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can delete office locations",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Get office location
        try:
            office_location = OfficeLocations.objects.get(id=location_id)
        except OfficeLocations.DoesNotExist:
            return ApiResponse.not_found("Office location not found")
        
        # Store data for response
        location_data = {
            "id": office_location.id,
            "location_name": office_location.location_name
        }
        
        # Delete office location
        office_location.delete()
        
        return ApiResponse.success(
            data=location_data,
            message="Office location deleted successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# ==================== PUBLIC HOLIDAYS CRUD ====================

@swagger_auto_schema(
    method='post',
    operation_description="Create a new public holiday (HR Manager only). Day will be automatically calculated from the date.",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['date', 'holiday_name'],
        properties={
            'date': openapi.Schema(
                type=openapi.TYPE_STRING,
                format='date',
                description="Date of the public holiday (YYYY-MM-DD). Day will be auto-calculated."
            ),
            'holiday_name': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Name of the public holiday"
            ),
            'is_active': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Whether this holiday is currently active",
                default=True
            ),
            'description': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Optional description of the holiday"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Public holiday created successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "Public holiday created successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "date": "2024-01-26",
                        "day": "Friday",
                        "holiday_name": "Republic Day",
                        "year": 2024,
                        "is_active": True,
                        "description": "National holiday celebrating the adoption of the Constitution",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can create public holidays")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_public_holiday(request):
    """Create a new public holiday - HR Manager only"""
    try:
        # Check if user is HR manager
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can create public holidays",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Validate input data
        serializer = PublicHolidayCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        # Create public holiday
        public_holiday = PublicHoliday.objects.create(**serializer.validated_data)
        
        response_serializer = PublicHolidaySerializer(public_holiday)
        return ApiResponse.created(
            data=response_serializer.data,
            message="Public holiday created successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of public holidays with pagination and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'page',
            openapi.IN_QUERY,
            description="Page number",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'page_size',
            openapi.IN_QUERY,
            description="Items per page (default: 20)",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'year',
            openapi.IN_QUERY,
            description="Filter by year",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'is_active',
            openapi.IN_QUERY,
            description="Filter by active status",
            type=openapi.TYPE_BOOLEAN,
            required=False
        ),
        openapi.Parameter(
            'search',
            openapi.IN_QUERY,
            description="Search by holiday name",
            type=openapi.TYPE_STRING,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Public holidays retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Public holidays retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 2,
                        "page": 1,
                        "page_size": 20,
                        "total_pages": 1,
                        "has_next": False,
                        "has_previous": False,
                        "results": [
                            {
                                "id": 1,
                                "date": "2024-01-26",
                                "day": "Friday",
                                "holiday_name": "Republic Day",
                                "year": 2024,
                                "is_active": True,
                                "description": "National holiday celebrating the adoption of the Constitution",
                                "created_at": "2024-01-15T10:30:00Z"
                            }
                        ]
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_public_holidays(request):
    """Get list of public holidays with pagination and filtering"""
    try:
        # Get query parameters
        page = request.GET.get('page', 1)
        page_size = request.GET.get('page_size', 30)
        year = request.GET.get('year', '')
        is_active = request.GET.get('is_active', '')
        search = request.GET.get('search', '')
        
        # Build query
        holidays_query = PublicHoliday.objects.all()
        
        # Apply filters
        if year:
            holidays_query = holidays_query.filter(year=int(year))
        
        if is_active != '':
            is_active_bool = is_active.lower() == 'true'
            holidays_query = holidays_query.filter(is_active=is_active_bool)
        
        if search:
            holidays_query = holidays_query.filter(holiday_name__icontains=search)
        
        # Order by year and date
        holidays_query = holidays_query.order_by('year', 'date')
        
        # Paginate
        paginator = Paginator(holidays_query, page_size)
        try:
            holidays_page = paginator.page(page)
        except (ValueError, TypeError):
            holidays_page = paginator.page(1)
        
        # Serialize results
        serializer = PublicHolidayListSerializer(holidays_page, many=True)
        
        # Prepare response data
        response_data = {
            "count": paginator.count,
            "page": holidays_page.number,
            "page_size": int(page_size),
            "total_pages": paginator.num_pages,
            "has_next": holidays_page.has_next(),
            "has_previous": holidays_page.has_previous(),
            "results": serializer.data
        }
        
        return ApiResponse.success(
            data=response_data,
            message="Public holidays retrieved successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get detailed information about a specific public holiday",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Public holiday details retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Public holiday details retrieved successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "date": "2024-01-26",
                        "day": "Friday",
                        "holiday_name": "Republic Day",
                        "year": 2024,
                        "is_active": True,
                        "description": "National holiday celebrating the adoption of the Constitution",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        404: openapi.Response(description="Public holiday not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_public_holiday_detail(request, holiday_id):
    """Get detailed information about a specific public holiday"""
    try:
        public_holiday = PublicHoliday.objects.get(id=holiday_id)
        serializer = PublicHolidaySerializer(public_holiday)
        
        return ApiResponse.success(
            data=serializer.data,
            message="Public holiday details retrieved successfully"
        )
        
    except PublicHoliday.DoesNotExist:
        return ApiResponse.not_found("Public holiday not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='put',
    operation_description="Update public holiday details (HR Manager only). Day will be automatically calculated from the date if date is updated.",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'date': openapi.Schema(
                type=openapi.TYPE_STRING,
                format='date',
                description="Date of the public holiday (YYYY-MM-DD). Day will be auto-calculated if provided."
            ),
            'holiday_name': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Name of the public holiday"
            ),
            'is_active': openapi.Schema(
                type=openapi.TYPE_BOOLEAN,
                description="Whether this holiday is currently active"
            ),
            'description': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Optional description of the holiday"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Public holiday updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Public holiday updated successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "date": "2024-01-26",
                        "day": "Friday",
                        "holiday_name": "Updated Republic Day",
                        "year": 2024,
                        "is_active": True,
                        "description": "Updated description",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-20T14:45:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update public holidays"),
        404: openapi.Response(description="Public holiday not found")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_public_holiday(request, holiday_id):
    """Update public holiday details - HR Manager only"""
    try:
        # Check if user is HR manager
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can update public holidays",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Get public holiday
        try:
            public_holiday = PublicHoliday.objects.get(id=holiday_id)
        except PublicHoliday.DoesNotExist:
            return ApiResponse.not_found("Public holiday not found")
        
        # Validate input data
        serializer = PublicHolidayUpdateSerializer(public_holiday, data=request.data, partial=True)
        if not serializer.is_valid():
            return ApiResponse.validation_error(serializer.errors)
        
        # Update public holiday
        serializer.save()
        
        response_serializer = PublicHolidaySerializer(public_holiday)
        return ApiResponse.success(
            data=response_serializer.data,
            message="Public holiday updated successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='delete',
    operation_description="Delete a public holiday (HR Manager only)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Public holiday deleted successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Public holiday deleted successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "holiday_name": "Republic Day"
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can delete public holidays"),
        404: openapi.Response(description="Public holiday not found")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_public_holiday(request, holiday_id):
    """Delete a public holiday - HR Manager only"""
    try:
        # Check if user is HR manager
        email = request.user.email_id
        employee = Employee.objects.get(email=email)
        if not employee.is_hr_manager:
            return ApiResponse.error(
                message="Only HR managers can delete public holidays",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        # Get public holiday
        try:
            public_holiday = PublicHoliday.objects.get(id=holiday_id)
        except PublicHoliday.DoesNotExist:
            return ApiResponse.not_found("Public holiday not found")
        
        # Store data for response
        holiday_data = {
            "id": public_holiday.id,
            "holiday_name": public_holiday.holiday_name
        }
        
        # Delete public holiday
        public_holiday.delete()
        
        return ApiResponse.success(
            data=holiday_data,
            message="Public holiday deleted successfully"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )