from django.contrib import admin
from .models import DailyAttendance, DailyTask

# Register your models here.
admin.site.register(DailyAttendance)
admin.site.register(DailyTask)
