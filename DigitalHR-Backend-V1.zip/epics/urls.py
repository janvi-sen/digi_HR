from django.urls import path
from . import views

app_name = 'epics'

urlpatterns = [
    path('', views.list_epics, name='list_epics'),
    path('create/', views.create_epic, name='create_epic'),
    path('<int:epic_id>/', views.get_epic_detail, name='get_epic_detail'),
    path('<int:epic_id>/update/', views.update_epic, name='update_epic'),
    path('<int:epic_id>/delete/', views.delete_epic, name='delete_epic'),
] 