from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
import logging

from .models import Announcement
from .serializers import AnnouncementSerializer, AnnouncementListSerializer
from employees.models import Employee
from utils.general_utils import ApiResponse
from utils.notification_utils import NotificationService

logger = logging.getLogger(__name__)

@swagger_auto_schema(
    method='post',
    operation_description="Create a new announcement",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['title', 'content', 'start_date'],
        properties={
            'title': openapi.Schema(type=openapi.TYPE_STRING, description="Announcement title"),
            'content': openapi.Schema(type=openapi.TYPE_STRING, description="Announcement content"),
            'priority': openapi.Schema(type=openapi.TYPE_STRING, description="Announcement priority", enum=['Low', 'Medium', 'High', 'Critical']),
            'start_date': openapi.Schema(type=openapi.TYPE_STRING, format='date-time', description="Announcement start date"),
            'end_date': openapi.Schema(type=openapi.TYPE_STRING, format='date-time', description="Announcement end date"),
            'is_active': openapi.Schema(type=openapi.TYPE_BOOLEAN, description="Whether the announcement is active", default=True),
            'scheduled_time': openapi.Schema(type=openapi.TYPE_STRING, format='date-time', description="Announcement scheduled time")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Announcement created successfully",
            schema=AnnouncementSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_announcement(request):
    """Create a new announcement"""
    serializer = AnnouncementSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        announcement = serializer.save()
        
        # Send notification to all users
        try:
            notification_service = NotificationService()
            
            # Prepare notification data
            notification_title = f"New Announcement: {announcement.title}"
            notification_body = announcement.content[:100] + "..." if len(announcement.content) > 100 else announcement.content
            
            # Additional data for the notification
            notification_data = {
                'type': 'announcement',
                'announcement_id': str(announcement.id),
                'title': announcement.title,
                'created_by': announcement.created_by.email,
                'scheduled_time': announcement.scheduled_time.isoformat() if announcement.scheduled_time else '',
            }
            
            # Send notification to all users
            success, message = notification_service.send_notification_to_all_users(
                title=notification_title,
                body=notification_body,
                data=notification_data
            )
            
            if success:
                logger.info(f"Notification sent successfully for announcement {announcement.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for announcement {announcement.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for announcement {announcement.id}: {str(e)}")
        
        return ApiResponse.created(
            data=serializer.data,
            message="Announcement created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='get',
    operation_description="Get list of announcements with pagination and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('priority', openapi.IN_QUERY, description="Filter by priority", type=openapi.TYPE_STRING),
        openapi.Parameter('is_active', openapi.IN_QUERY, description="Filter by active status", type=openapi.TYPE_BOOLEAN),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search by title or content", type=openapi.TYPE_STRING),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter announcements for specific employee", type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response(
            description="Announcements retrieved successfully",
            schema=AnnouncementListSerializer(many=True)
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_announcements(request):
    """Get paginated list of announcements with filtering options"""
    # Get query parameters
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    priority_filter = request.GET.get('priority', '')
    is_active = request.GET.get('is_active')
    search = request.GET.get('search', '')
    email_id = request.GET.get('email_id')
    
    # Build query
    queryset = Announcement.objects.all()
    
    # Filter by employee if email_id is provided
    if email_id:
        try:
            employee = Employee.objects.get(email=email_id)
            queryset = queryset.filter(
                Q(target_audience=employee) | Q(target_audience__isnull=True)
            ).distinct()
        except Employee.DoesNotExist:
            return ApiResponse.not_found(f"Employee with email {email_id} not found")
    
    # Apply filters
    if priority_filter:
        queryset = queryset.filter(priority=priority_filter)
    
    if is_active is not None:
        is_active = is_active.lower() == 'true'
        queryset = queryset.filter(is_active=is_active)
    
    if search:
        queryset = queryset.filter(
            Q(title__icontains=search) |
            Q(content__icontains=search)
        )
    
    # Order by created date
    queryset = queryset.order_by('-created_at')
    queryset = queryset.filter(
        Q(start_date__lte=timezone.now()) &
        Q(end_date__gte=timezone.now())
    )
    
    # Paginate
    paginator = Paginator(queryset, page_size)
    
    try:
        announcements_page = paginator.page(page)
    except:
        return ApiResponse.error(
            message="Invalid page number",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Serialize data
    serializer = AnnouncementListSerializer(announcements_page.object_list, many=True)
    
    # Build pagination response
    pagination_data = {
        'count': paginator.count,
        'page': page,
        'page_size': page_size,
        'total_pages': paginator.num_pages,
        'has_next': announcements_page.has_next(),
        'has_previous': announcements_page.has_previous(),
        'results': serializer.data
    }
    
    return ApiResponse.success(
        data=pagination_data,
        message="Announcements retrieved successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get announcement details by ID",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Announcement details retrieved successfully",
            schema=AnnouncementSerializer
        ),
        404: openapi.Response(description="Announcement not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_announcement_detail(request, announcement_id):
    """Get detailed information about a specific announcement"""
    try:
        announcement = Announcement.objects.get(id=announcement_id)
    except Announcement.DoesNotExist:
        return ApiResponse.not_found("Announcement not found")
    
    serializer = AnnouncementSerializer(announcement)
    
    return ApiResponse.success(
        data=serializer.data,
        message="Announcement details retrieved successfully"
    )

@swagger_auto_schema(
    method='put',
    operation_description="Update announcement information",
    request_body=AnnouncementSerializer,
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Announcement updated successfully",
            schema=AnnouncementSerializer
        ),
        404: openapi.Response(description="Announcement not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_announcement(request, announcement_id):
    """Update announcement information"""
    try:
        announcement = Announcement.objects.get(id=announcement_id)
    except Announcement.DoesNotExist:
        return ApiResponse.not_found("Announcement not found")
    
    serializer = AnnouncementSerializer(announcement, data=request.data, partial=True, context={'request': request})
    
    if serializer.is_valid():
        updated_announcement = serializer.save()
        return ApiResponse.success(
            data=serializer.data,
            message="Announcement updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='delete',
    operation_description="Delete an announcement",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(description="Announcement deleted successfully"),
        404: openapi.Response(description="Announcement not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_announcement(request, announcement_id):
    """Delete an announcement"""
    try:
        announcement = Announcement.objects.get(id=announcement_id)
    except Announcement.DoesNotExist:
        return ApiResponse.not_found("Announcement not found")
    
    announcement.delete()
    
    return ApiResponse.success(
        message="Announcement deleted successfully"
    )
