from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager


class BaseModel(models.Model):
    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True, editable=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

class UserManager(BaseUserManager):
    def create_user(self, email_id, password=None, **extra_fields):
        if not email_id:
            raise ValueError('The Email field must be set')
        email_id = self.normalize_email(email_id)
        user = self.model(email_id=email_id, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email_id, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(email_id, password, **extra_fields)

class User(AbstractBaseUser, PermissionsMixin, BaseModel):
    email_id = models.EmailField(primary_key=True, unique=True)
    active = models.BooleanField(default=False)
    is_onboarded = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_registered = models.BooleanField(default=False)
    device_token = models.CharField(max_length=255, null=True, blank=True)
    USERNAME_FIELD = 'email_id'
    REQUIRED_FIELDS = []

    objects = UserManager()

    def __str__(self):
        return self.email_id

class OTP(BaseModel):
    OTP_TYPE_CHOICES = [
        ('login', 'Login'),
        ('password_reset', 'Password Reset'),
    ]
    
    email_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name='otps')
    otp = models.CharField(max_length=6)
    otp_type = models.CharField(max_length=20, choices=OTP_TYPE_CHOICES, default='login')
    is_used = models.BooleanField(default=False)

    def __str__(self):
        return f"OTP for {self.email_id}: {self.otp} ({self.otp_type})"
