from django.db import models
from django.conf import settings
from utils.general_utils import EmailDomainValidator
from django.core.exceptions import ValidationError
import os
from authentication.models import User
from django.utils import timezone

# Create your models here.

def employee_profile_upload_path(instance, filename):
    """Generate upload path for employee profile photos"""
    # Get file extension
    ext = os.path.splitext(filename)[1]
    # Create new filename with employee_id
    new_filename = f"profile_{instance.employee_id or 'temp'}{ext}"
    return f'employee_profiles/{instance.employee_id or "temp"}/{new_filename}'

class BaseModel(models.Model):
    """
    Abstract base model with common fields
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

class Employee(BaseModel):
    """
    Employee model with comprehensive employee information
    """
    
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
        ('Prefer not to say', 'Prefer not to say'),
    ]
    
    EMPLOYMENT_STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
        ('Terminated', 'Terminated'),
        ('On Leave', 'On Leave'),
        ('WFH', 'WFH'),
        ('Suspended', 'Suspended'),
    ]
    
    DEPARTMENT_CHOICES = [
        ('HR', 'Human Resources'),
        ('Tech', 'Tech Team'),
        ('Finance', 'Finance'),
        ('Marketing', 'Marketing'),
        ('Sales', 'Sales'),
        ('Operations', 'Operations'),
        ('Legal', 'Legal'),
        ('Admin', 'Administration'),
        ('R&D', 'Research & Development'),
        ('QA', 'Quality Assurance'),
        ('DevOps', 'DevOps'),
        ('Engineering', 'Engineering Team'),
        ('Design', 'Design Team'),
        ('CustomerSupport', 'Customer Support'),
        ('Other', 'Other'),
    ]
    
    DESIGNATION_CHOICES = [
        ('Intern', 'Intern'),
        ('Junior Developer', 'Junior Developer'),
        ('Senior Developer', 'Senior Developer'),
        ('Team Lead', 'Team Lead'),
        ('Manager', 'Manager'),
        ('Senior Manager', 'Senior Manager'),
        ('Director', 'Director'),
        ('VP', 'Vice President'),
        ('CEO', 'Chief Executive Officer'),
        ('CTO', 'Chief Technology Officer'),
        ('HR Executive', 'HR Executive'),
        ('HR Manager', 'HR Manager'),
        ('Other', 'Other'),
    ]
    
    SHIFT_TYPE_CHOICES = [
        ('EVERY_SATURDAY', 'Every Saturday'),
        ('EVERY_ALTERNATE_SATURDAY', 'Every Alternate Saturday'),
    ]
    
    EMPLOYMENT_TYPE_CHOICES = [
        ('Full-Time', 'Full-Time Employment'),
        ('Part-Time', 'Part-Time Employment'),
        ('Full-Time-Probation', 'Full-Time Employment (Probation)'),
        ('Full-Time-Remote', 'Full-Time Remote Employment'),
        ('Part-Time-Remote', 'Part-Time Remote Employment'),
        ('Intern', 'Internship'),
        ('Freelance', 'Freelance'),
        ('Contract', 'Contract Employment'),
        ('Temporary', 'Temporary Employment'),
        ('Seasonal', 'Seasonal Employment'),
        ('Volunteer', 'Volunteer'),
        ('Other', 'Other'),
    ]
    
    # Basic Information
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='employee_profile'
    )
    employee_id = models.CharField(
        max_length=20,
        unique=True,
        blank=True,
        help_text="Unique employee identifier"
    )
    full_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    personal_email = models.EmailField(unique=True, null=True, blank=True)
    mobile_number = models.CharField(max_length=15, unique=True)
    
    # Personal Information
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(
        max_length=20,
        choices=GENDER_CHOICES,
        default='Prefer not to say'
    )
    
    # Profile Photo
    profile_photo = models.ImageField(
        upload_to=employee_profile_upload_path,
        null=True,
        blank=True,
        help_text="Employee profile photo (direct upload)"
    )
    profile_photo_url = models.URLField(
        max_length=500,
        null=True,
        blank=True,
        default='',
        help_text="External URL for profile photo (e.g., S3 bucket, CDN)"
    )
    
    # Employment Information
    date_of_joining = models.DateField(null=True, blank=True, default=timezone.now)
    department = models.CharField(
        max_length=50,
        choices=DEPARTMENT_CHOICES,
        default='Other'
    )
    designation = models.CharField(
        max_length=100,
        default='Other'
    )
    employment_status = models.CharField(
        max_length=20,
        choices=EMPLOYMENT_STATUS_CHOICES,
        default='Active'
    )
    
    # Verification and Onboarding
    verified_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='verified_employees'
    )
    verification_date = models.DateTimeField(null=True, blank=True)
    onboarding_date = models.DateTimeField(null=True, blank=True)
    
    # Manager and Reporting
    reporting_manager = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='team_members'
    )
    
    # Additional Information
    emergency_contact_name = models.CharField(max_length=255, blank=True, null=True)
    emergency_contact_number = models.CharField(max_length=15, blank=True, null=True)
    emergency_contact_relation = models.CharField(max_length=50, blank=True, null=True)
    current_address = models.CharField(max_length=255, blank=True, null=True)
    permanent_address = models.CharField(max_length=255, blank=True, null=True)
    blood_group = models.CharField(max_length=10, blank=True, null=True)
    last_login = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True, null=True, help_text="Internal notes about employee")
    uan_number = models.CharField(max_length=20, blank=True, null=True)
    current_ctc = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    shift = models.CharField(max_length=20, blank=True, null=True)
    appraisal_date = models.DateField(null=True, blank=True)
    is_hr_manager = models.BooleanField(default=False)
    is_core = models.BooleanField(default=False)
    total_experience = models.IntegerField(default=0)
    shift_type = models.CharField(max_length=50, default='EVERY_ALTERNATE_SATURDAY', choices=SHIFT_TYPE_CHOICES)
    employment_type = models.CharField(max_length=20, default='Full-Time', choices=EMPLOYMENT_TYPE_CHOICES)
    reporting_location = models.ForeignKey(
        'policies.OfficeLocations',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='employees_reporting_location'
    )
    leaves_allotted = models.JSONField(default={
        "SL": 0,
        "CL": 0,
        "PL": 0,
        "WFH": 0,
    })
    leaves_taken = models.JSONField(default={
        "SL": 0,
        "CL": 0,
        "PL": 0,
        "WFH": 0,
    })
    
    class Meta:
        db_table = 'employees'
        verbose_name = 'Employee'
        verbose_name_plural = 'Employees'
        ordering = ['-created_at']
        
    def __str__(self):
        return f"{self.full_name} ({self.employee_id})"
    
    def clean(self):
        """Custom validation"""
        super().clean()
        
        # Validate email domain
        if self.email:
            is_valid, error_message = EmailDomainValidator.validate_email_domain(self.email)
            if not is_valid:
                raise ValidationError({'email': error_message})
    
    def save(self, *args, **kwargs):
        # Auto-generate employee ID if not provided
        if not self.employee_id:
            self.employee_id = self.generate_employee_id()
        
        # Ensure email matches user email
        if self.user_id and not self.email:
            self.email = self.user.email_id
        
        super().save(*args, **kwargs)
    
    @classmethod
    def generate_employee_id(cls):
        """Generate a unique employee ID"""
        # Get current year
        current_year = timezone.now().year
        
        # Get the last employee ID for this year
        last_employee = cls.objects.filter(
            employee_id__startswith=f'SCI{current_year}'
        ).order_by('-employee_id').first()
        
        if last_employee:
            # Extract the number part and increment
            last_number = int(last_employee.employee_id[-4:])
            new_number = last_number + 1
        else:
            # Start with 1 for new year
            new_number = 1
        
        # Format: SCI{year}{4-digit-number}
        return f'SCI{current_year}{new_number:04d}'
    
    @property
    def age(self):
        """Calculate age from date of birth"""
        if self.date_of_birth:
            today = timezone.now().date()
            return today.year - self.date_of_birth.year - (
                (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
            )
        return None
    
    @property
    def years_of_experience(self):
        """Calculate experience duration in years, months and days"""
        if self.date_of_joining:
            today = timezone.now().date()
            # Calculate years, months and days
            years = today.year - self.date_of_joining.year
            months = today.month - self.date_of_joining.month
            days = today.day - self.date_of_joining.day

            # Adjust for negative months/days
            if days < 0:
                months -= 1
                days += 30  # Approximate days in a month
            if months < 0:
                years -= 1
                months += 12

            # Format the experience string
            if years > 0:
                if months > 0:
                    return f"{years} year{'s' if years > 1 else ''}, {months} month{'s' if months > 1 else ''}"
                return f"{years} year{'s' if years > 1 else ''}"
            elif months > 0:
                if days > 0:
                    return f"{months} month{'s' if months > 1 else ''}, {days} day{'s' if days > 1 else ''}"
                return f"{months} month{'s' if months > 1 else ''}"
            else:
                return f"{days} day{'s' if days > 1 else ''}"
        return None
    
    @property
    def team_size(self):
        """Get number of team members reporting to this employee"""
        return self.team_members.filter(employment_status='Active').count()
    
    @property
    def profile_photo_display_url(self):
        """Get the profile photo URL for display (prioritizes external URL over uploaded file)"""
        if self.profile_photo_url:
            return self.profile_photo_url
        elif self.profile_photo:
            return self.profile_photo.url
        return None
    
    def get_profile_photo_thumbnail_url(self, size='150x150'):
        """Get thumbnail URL for profile photo (for future implementation with image processing)"""
        # This can be expanded later to generate thumbnails
        return self.profile_photo_display_url


def employee_document_upload_path(instance, filename):
    """Generate upload path for employee documents"""
    return f'employee_documents/{instance.employee.employee_id}/{filename}'


class EmployeeDocument(BaseModel):
    """
    Model to store employee documents and files
    """
    
    DOCUMENT_TYPE_CHOICES = [
        ('PAN_Card', 'PAN Card'),
        ('Aadhar_Card', 'Aadhar Card'),
        ('10th_Certificate', '10th Certificate'),
        ('12th_Certificate', '12th Certificate'),
        ('Graduation_Certificate', 'Graduation Certificate'),
        ('Latest_Experience_Letter', 'Latest Experience Letter'),
        ('Past_Company_Salary_Slip', 'Past Company Salary Slip'),
        ('Resume', 'Resume/CV'),
        ('ID_Proof', 'ID Proof'),
        ('Address_Proof', 'Address Proof'),
        ('Education_Certificate', 'Education Certificate'),
        ('Experience_Letter', 'Experience Letter'),
        ('Offer_Letter', 'Offer Letter'),
        ('Contract', 'Employment Contract'),
        ('Passport', 'Passport'),
        ('Other', 'Other'),
    ]
    email_id = models.EmailField(
        max_length=255,
        null=True,
        blank=True
    )
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='documents',
        null=True,
    )
    document_type = models.CharField(
        max_length=50,
        choices=DOCUMENT_TYPE_CHOICES
    )
    document_file_url = models.URLField(
        max_length=500,
        null=True,
        blank=True
    )
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='uploaded_documents'
    )
    is_verified = models.BooleanField(default=False)
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='verified_documents'
    )
    verified_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True, null=True)
    
    class Meta:
        db_table = 'employee_documents'
        verbose_name = 'Employee Document'
        verbose_name_plural = 'Employee Documents'
        ordering = ['-created_at']
        unique_together = ['employee', 'document_type']  # One document per type per employee
    
    def __str__(self):
        return f"{self.employee.full_name} - {self.document_type}"
    
    def delete(self, *args, **kwargs):
        """Delete file when model instance is deleted"""
        if self.document_file:
            if os.path.isfile(self.document_file.path):
                os.remove(self.document_file.path)
        super().delete(*args, **kwargs)



class EmployeeLocation(BaseModel):
    """
    Model to store employee location
    """
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='employee_locations')
    lat_long = models.CharField(max_length=255, null=True, blank=True)
    location_address = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = 'employee_locations'
        verbose_name = 'Employee Location'
        verbose_name_plural = 'Employee Locations'
        ordering = ['-created_at']
        
    def __str__(self):
        return f"{self.employee.full_name} - {self.location_address}"