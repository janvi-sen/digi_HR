from datetime import timezone
from django.db import models

from employees.models import Employee

# Create your models here.
class BaseModel(models.Model):
    """
    Abstract base model with common fields
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True
        
class Policy(BaseModel):
    """
    Policy model
    """
    policy_name = models.CharField(max_length=255, unique=True)
    policy_code = models.CharField(max_length=255, unique=True)
    uploaded_by = models.ForeignKey(
        Employee,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='policies_uploaded'
    )
    policy_url = models.URLField()
    policy_version = models.BigIntegerField(default=1)
    is_active = models.BooleanField(default=True)


class GenericPolicy(BaseModel):
    """
    Model for storing generic policies like Privacy Policy and Terms & Conditions
    """
    POLICY_TYPES = [
        ('privacy', 'Privacy Policy'),
        ('terms', 'Terms & Conditions'),
    ]
    
    CONTENT_TYPES = [
        ('html', 'HTML'),
        ('markdown', 'Markdown'),
        ('text', 'Plain Text'),
    ]
    
    policy_type = models.CharField(
        max_length=20,
        choices=POLICY_TYPES,
        help_text="Type of policy (Privacy Policy or Terms & Conditions)"
    )
    version = models.CharField(
        max_length=10,
        help_text="Version number (e.g., 1.0.0)"
    )
    content_type = models.CharField(
        max_length=10,
        choices=CONTENT_TYPES,
        default='markdown',
        help_text="Format of the content"
    )
    content = models.TextField(
        help_text="Policy content in the specified format"
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Whether this version is currently active"
    )
    updated_by = models.ForeignKey(
        Employee,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='generic_policies_updated',
        help_text="Employee who last updated this policy"
    )
    effective_date = models.DateTimeField(
        help_text="When this version becomes effective",
        auto_now=True
    )
    notes = models.TextField(
        blank=True,
        null=True,
        help_text="Optional notes about changes in this version"
    )

    class Meta:
        verbose_name = "Generic Policy"
        verbose_name_plural = "Generic Policies"
        ordering = ['-effective_date', '-version']
        unique_together = ['policy_type', 'version']
        
    def __str__(self):
        return f"{self.get_policy_type_display()} v{self.version}"
    
    def save(self, *args, **kwargs):
        # If this is a new version, deactivate all other versions of the same policy type
        if self.is_active and not self.pk:
            GenericPolicy.objects.filter(
                policy_type=self.policy_type,
                is_active=True
            ).update(is_active=False)
        super().save(*args, **kwargs)

class PolicyAcknowledgment(BaseModel):
    """
    Model to track policy acknowledgments by employees
    """
    
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='policy_acknowledgments'
    )
    policy = models.ForeignKey(
        Policy,
        on_delete=models.CASCADE,
        related_name='policy_acknowledgments'
    )
    acknowledged = models.BooleanField(default=False)
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        db_table = 'policy_acknowledgments'
        verbose_name = 'Policy Acknowledgment'
        verbose_name_plural = 'Policy Acknowledgments'
        unique_together = ['employee', 'policy']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.employee.full_name} - {self.policy.policy_name}"

class OfficeLocations(BaseModel):
    """
    Model to store office locations
    """
    location_name = models.CharField(
        max_length=255,
        help_text="Name of the office location"
    )
    full_address = models.TextField(
        help_text="Complete address of the office location"
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Whether this location is currently active"
    )
    lat_long = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        help_text="Latitude and longitude coordinates (e.g., '40.7128,-74.0060')"
    )
    
    class Meta:
        db_table = 'office_locations'
        verbose_name = 'Office Location'
        verbose_name_plural = 'Office Locations'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.location_name}"

class PublicHoliday(BaseModel):
    """
    Model to store public holidays
    """
    date = models.DateField(
        help_text="Date of the public holiday"
    )
    day = models.CharField(
        max_length=20,
        help_text="Day of the week (e.g., Monday, Tuesday)"
    )
    holiday_name = models.CharField(
        max_length=255,
        help_text="Name of the public holiday"
    )
    year = models.IntegerField(
        help_text="Year of the holiday (auto-calculated from date)"
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Whether this holiday is currently active"
    )
    description = models.TextField(
        blank=True,
        null=True,
        help_text="Optional description of the holiday"
    )
    
    class Meta:
        db_table = 'public_holidays'
        verbose_name = 'Public Holiday'
        verbose_name_plural = 'Public Holidays'
        ordering = ['year', 'date']
        unique_together = ['date', 'holiday_name']  # Prevent duplicate holidays on same date
    
    def __str__(self):
        return f"{self.holiday_name} - {self.date}"
    
    def save(self, *args, **kwargs):
        """Auto-calculate year from date"""
        if self.date:
            self.year = self.date.year
        super().save(*args, **kwargs)