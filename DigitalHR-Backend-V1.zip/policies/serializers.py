from rest_framework import serializers
from .models import Policy, PolicyAcknowledgment, OfficeLocations
from employees.serializers import EmployeeSerializer
from .models import PublicHoliday
from django.utils import timezone


class PolicySerializer(serializers.ModelSerializer):
    """Serializer for Policy model"""
    # uploaded_by = EmployeeSerializer(read_only=True)
    uploaded_by_name = serializers.CharField(source='uploaded_by.full_name', read_only=True)
    
    class Meta:
        model = Policy
        fields = [
            'id', 'policy_name', 'policy_code', 'uploaded_by_name',
            'policy_url', 'policy_version', 'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'uploaded_by', 'uploaded_by_name', 'created_at', 'updated_at']


class PolicyCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating Policy"""
    
    class Meta:
        model = Policy
        fields = ['policy_name', 'policy_code']
        
    def validate_policy_name(self, value):
        """Validate policy name is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Policy name cannot be empty")
        return value.strip()
    
    def validate_policy_code(self, value):
        """Validate policy code is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Policy code cannot be empty")
        return value.strip()


class PolicyListSerializer(serializers.ModelSerializer):
    """Serializer for listing policies"""
    uploaded_by_name = serializers.CharField(source='uploaded_by.full_name', read_only=True)
    uploaded_by_email = serializers.CharField(source='uploaded_by.email', read_only=True)
    
    class Meta:
        model = Policy
        fields = [
            'id', 'policy_name', 'policy_code', 'uploaded_by_name', 'uploaded_by_email',
            'policy_url', 'policy_version', 'is_active', 'created_at', 'updated_at'
        ]


class PolicyAcknowledgmentSerializer(serializers.ModelSerializer):
    """Serializer for PolicyAcknowledgment model"""
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    policy_name = serializers.CharField(source='policy.policy_name', read_only=True)
    policy_code = serializers.CharField(source='policy.policy_code', read_only=True)
    
    class Meta:
        model = PolicyAcknowledgment
        fields = [
            'id', 'employee', 'employee_name', 'policy', 'policy_name', 'policy_code',
            'acknowledged', 'acknowledged_at', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'employee', 'employee_name', 'policy_name', 'policy_code', 'created_at', 'updated_at']


class PolicyAcknowledgmentUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating policy acknowledgment"""
    
    class Meta:
        model = PolicyAcknowledgment
        fields = ['acknowledged']
        
    def validate_acknowledged(self, value):
        """Validate that acknowledged is True when updating"""
        if not value:
            raise serializers.ValidationError("Policy acknowledgment must be set to True")
        return value 


class OfficeLocationsSerializer(serializers.ModelSerializer):
    """Serializer for OfficeLocations model"""
    
    class Meta:
        model = OfficeLocations
        fields = [
            'id', 'location_name', 'full_address', 'is_active', 
            'lat_long', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class OfficeLocationsCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating OfficeLocations"""
    
    class Meta:
        model = OfficeLocations
        fields = ['location_name', 'full_address', 'is_active', 'lat_long']
        
    def validate_location_name(self, value):
        """Validate location name is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Location name cannot be empty")
        return value.strip()
    
    def validate_full_address(self, value):
        """Validate full address is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Full address cannot be empty")
        return value.strip()
    
    def validate_lat_long(self, value):
        """Validate lat_long format if provided"""
        if value:
            # Basic validation for lat,long format
            parts = value.split(',')
            if len(parts) != 2:
                raise serializers.ValidationError("Latitude and longitude must be in format 'lat,long'")
            
            try:
                lat = float(parts[0].strip())
                long = float(parts[1].strip())
                
                # Validate latitude range (-90 to 90)
                if lat < -90 or lat > 90:
                    raise serializers.ValidationError("Latitude must be between -90 and 90")
                
                # Validate longitude range (-180 to 180)
                if long < -180 or long > 180:
                    raise serializers.ValidationError("Longitude must be between -180 and 180")
                    
            except ValueError:
                raise serializers.ValidationError("Latitude and longitude must be valid numbers")
        
        return value


class OfficeLocationsUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating OfficeLocations"""
    
    class Meta:
        model = OfficeLocations
        fields = ['location_name', 'full_address', 'is_active', 'lat_long']
        
    def validate_location_name(self, value):
        """Validate location name is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Location name cannot be empty")
        return value.strip()
    
    def validate_full_address(self, value):
        """Validate full address is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Full address cannot be empty")
        return value.strip()
    
    def validate_lat_long(self, value):
        """Validate lat_long format if provided"""
        if value:
            # Basic validation for lat,long format
            parts = value.split(',')
            if len(parts) != 2:
                raise serializers.ValidationError("Latitude and longitude must be in format 'lat,long'")
            
            try:
                lat = float(parts[0].strip())
                long = float(parts[1].strip())
                
                # Validate latitude range (-90 to 90)
                if lat < -90 or lat > 90:
                    raise serializers.ValidationError("Latitude must be between -90 and 90")
                
                # Validate longitude range (-180 to 180)
                if long < -180 or long > 180:
                    raise serializers.ValidationError("Longitude must be between -180 and 180")
                    
            except ValueError:
                raise serializers.ValidationError("Latitude and longitude must be valid numbers")
        
        return value 

class PublicHolidaySerializer(serializers.ModelSerializer):
    """Serializer for PublicHoliday model"""
    
    class Meta:
        model = PublicHoliday
        fields = [
            'id', 'date', 'day', 'holiday_name', 'year', 
            'is_active', 'description', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'year', 'created_at', 'updated_at']

class PublicHolidayCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating PublicHoliday"""
    
    class Meta:
        model = PublicHoliday
        fields = ['date', 'holiday_name', 'is_active', 'description']
        
    # def validate_date(self, value):
    #     """Validate date is not in the past"""
    #     if value < timezone.now().date():
    #         raise serializers.ValidationError("Holiday date cannot be in the past")
    #     return value
    
    def validate_holiday_name(self, value):
        """Validate holiday name is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Holiday name cannot be empty")
        return value.strip()
    
    # def validate_day(self, value):
    #     """Validate day format"""
    #     valid_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    #     if value not in valid_days:
    #         raise serializers.ValidationError(f"Day must be one of: {', '.join(valid_days)}")
    #     return value
    
    def validate(self, attrs):
        """Validate and auto-calculate day from date"""
        date = attrs.get('date')
        
        if date:
            # Auto-calculate day from date
            attrs['day'] = date.strftime('%A')
        
        return attrs

class PublicHolidayUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating PublicHoliday"""
    
    class Meta:
        model = PublicHoliday
        fields = ['date', 'holiday_name', 'is_active', 'description']
        
    def validate_date(self, value):
        """Validate date is not in the past"""
        if value < timezone.now().date():
            raise serializers.ValidationError("Holiday date cannot be in the past")
        return value
    
    def validate_holiday_name(self, value):
        """Validate holiday name is not empty"""
        if not value or not value.strip():
            raise serializers.ValidationError("Holiday name cannot be empty")
        return value.strip()
    
    def validate_day(self, value):
        """Validate day format"""
        valid_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        if value not in valid_days:
            raise serializers.ValidationError(f"Day must be one of: {', '.join(valid_days)}")
        return value
    
    def validate(self, attrs):
        """Validate and auto-calculate day from date"""
        date = attrs.get('date')
        
        if date:
            # Auto-calculate day from date
            attrs['day'] = date.strftime('%A')
        
        return attrs

class PublicHolidayListSerializer(serializers.ModelSerializer):
    """Serializer for listing PublicHoliday with additional fields"""
    
    class Meta:
        model = PublicHoliday
        fields = [
            'id', 'date', 'day', 'holiday_name', 'year', 
            'is_active', 'description', 'created_at'
        ]
        read_only_fields = ['id', 'year', 'created_at'] 