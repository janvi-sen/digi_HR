import firebase_admin
from firebase_admin import credentials, firestore
import pandas as pd
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
# from dotenv import load_dotenv

# Load environment variables
# load_dotenv()

# Email configuration
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', 587))
SMTP_USERNAME = 'services@sciverse.co.in'
SMTP_PASSWORD = "uska tovg ooec bvlq"
# ADMIN_EMAIL = os.getenv('ADMIN_EMAIL')
FROM_EMAIL = 'Digital HR'

# Step 1: Initialize Firebase
cred = credentials.Certificate("digital-hr-production-firebase-adminsdk-fbsvc-d43b5b534c.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Step 2: Define your collection
employees_ref = db.collection("employees")
employee_docs = employees_ref.stream()

# Step 3: Prepare a list for rows
rows = []

def export_clockin_data():
    for emp in employee_docs:
        email = emp.id
        print(f'doing for {email}')
        data = emp.to_dict()

        tasks_by_date = data.get("tasks", {})
        print(tasks_by_date.keys())
        for date_str, data_info in tasks_by_date.items():
            print(data_info.keys())
            clock_in_time = data_info.get("clockInTime", "")
            print(clock_in_time)
            if clock_in_time:
                # Check if already datetime object
                if isinstance(clock_in_time, datetime):
                    clock_in_time = clock_in_time + timedelta(hours=5, minutes=30)
                else:
                    clock_in_time = datetime.fromtimestamp(clock_in_time/1000) + timedelta(hours=5, minutes=30)
            
            clock_out_time = data_info.get("clockOutTime", "")
            if clock_out_time:
                # Check if already datetime object
                if isinstance(clock_out_time, datetime):
                    clock_out_time = clock_out_time + timedelta(hours=5, minutes=30)
                else:
                    clock_out_time = datetime.fromtimestamp(clock_out_time/1000) + timedelta(hours=5, minutes=30)
            clock_in_location = data_info.get("clockInLocation", "")
            clock_out_location = data_info.get("clockOutLocation", "")
            early_clockout_reason = data_info.get("earlyClockoutReason", "")
            
            # for task_id, task_data in tasks.items():
            #     print(task_data.keys())
            #     start_ts = task_data.get("startTime")
            #     duration_sec = task_data.get("seconds", 0)

            #     if not start_ts:
            #         continue  # Skip if no start time

            #     clock_in = datetime.fromtimestamp(start_ts / 1000)
            #     clock_out = clock_in + timedelta(seconds=duration_sec)

            rows.append({
                "Employee Email": email,
                "Date": date_str,
                # "Task ID": task_id,
                # "Project": task_data.get("project", ""),
                # "Epic": task_data.get("epic", ""),
                # "Task Summary": task_data.get("summaryOfTasks", ""),
                "Clock In Time": clock_in_time,
                "Clock Out Time": clock_out_time,
                "Clock In Location": clock_in_location,
                "Clock Out Location": clock_out_location,
                "Early Clockout Reason": early_clockout_reason,
            })
    # Convert to DataFrame and export to Excel
    df = pd.DataFrame(rows)
    # df.sort_values(by=["Employee Email", "Date", "Clock In Time"], inplace=True)
    df.to_csv("employee_clockin_clockout.csv", index=False)

    print("Excel file generated: employee_clockin_clockout.xlsx")

def send_email(subject, html_content, recipient_list, excel_file=None):
    """Send email with HTML content and optional Excel attachment"""
    try:
        # Create message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = FROM_EMAIL
        msg['To'] = ', '.join(recipient_list)

        # Create plain text version
        text_content = "Please view this email in an HTML-compatible email client."

        # Attach both versions
        msg.attach(MIMEText(text_content, 'plain'))
        msg.attach(MIMEText(html_content, 'html'))

        # Attach Excel file if provided
        if excel_file:
            with open(excel_file, 'rb') as f:
                excel_attachment = MIMEText(f.read(), 'base64', 'utf-8')
                excel_attachment.add_header(
                    'Content-Disposition',
                    'attachment',
                    filename=os.path.basename(excel_file)
                )
                msg.attach(excel_attachment)

        # Send email
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)

        return True, "Email sent successfully"
    except Exception as e:
        return False, f"Error sending email: {str(e)}"

def export_tasks_data(date_to_export=None, employee_ids=[]):
    
    rows = []
    for emp in employee_docs:
        email = emp.id
        if employee_ids and email not in employee_ids:
            continue
        data = emp.to_dict()
        tasks_by_date = data.get("tasks", {})
        for date_str, data_info in tasks_by_date.items():
            if date_to_export and date_str != date_to_export:
                continue
            
            
            project_ids = [key for key in data_info.keys() if isinstance(data_info[key], dict)]
            
            tasks_completed = []
            for project_id in project_ids:
                project_data = data_info[project_id]
                epic = project_data.get("epic", "")
                project_name = project_data.get("project", "")
                key_update = project_data.get('keyUpdate', "")
                seconds_worked = project_data.get('seconds', 0)
                hours_worked = round((seconds_worked / 3600), 2)
                tasks_completed.append({
                    "Project": project_name,
                    "Epic": epic,
                    "Key Update": key_update,
                    "Hours Worked": hours_worked,
                })
            clock_in_time = data_info.get("clockInTime", "")
            print(clock_in_time)
            if clock_in_time:
                # Check if already datetime object
                if isinstance(clock_in_time, datetime):
                    clock_in_time = clock_in_time + timedelta(hours=5, minutes=30)
                else:
                    clock_in_time = datetime.fromtimestamp(clock_in_time/1000) + timedelta(hours=5, minutes=30)
            
            clock_out_time = data_info.get("clockOutTime", "")
            if clock_out_time:
                # Check if already datetime object
                if isinstance(clock_out_time, datetime):
                    clock_out_time = clock_out_time + timedelta(hours=5, minutes=30)
                else:
                    clock_out_time = datetime.fromtimestamp(clock_out_time/1000) + timedelta(hours=5, minutes=30)
            clock_in_location = data_info.get("clockInLocation", "")
            clock_out_location = data_info.get("clockOutLocation", "")
            early_clockout_reason = data_info.get("earlyClockoutReason", "")
            
            rows.append({
                "Employee Email": email,
                "Date": date_str,
                "Clock In Time": clock_in_time,
                "Clock Out Time": clock_out_time,
                # "Clock In Location": clock_in_location,
                # "Clock Out Location": clock_out_location,
                "Tasks Completed": tasks_completed
            })
    
    df = pd.DataFrame(rows)
    # Convert Date column to datetime for proper sorting
    df['Date'] = pd.to_datetime(df['Date'], format='%d %B %Y')
    
    # Sort by Date
    df = df.sort_values('Date')
    
    # Convert back to original format
    df['Date'] = df['Date'].dt.strftime('%d %B %Y')
    df.to_csv("employee_tasks.csv", index=False)
# export_clockin_data()
employee_ids = ['jatin.jagani@sciverse.co.in']
todays_date = datetime.now().strftime('%d %B %Y')
# print(todays_date)
# export_tasks_data(employee_ids=employee_ids)


def generate_excel_report(all_rows, sorted_dates):
    """Generate Excel report with detailed attendance and task data"""
    try:
        # Create a Pandas Excel writer using XlsxWriter as the engine
        excel_file = f"attendance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        writer = pd.ExcelWriter(excel_file, engine='xlsxwriter')

        # Create Summary sheet
        summary_data = {
            'Metric': [
                'Total Employees',
                'Date Range',
                'Total Days',
                'Total Clock-ins',
                'Total Clock-outs',
                'Average Hours per Employee'
            ],
            'Value': [
                len(set(row['Employee Email'] for row in all_rows)),
                f"{sorted_dates[0]} to {sorted_dates[-1]}",
                len(sorted_dates),
                sum(1 for row in all_rows if row['Clock In'] != 'Not Clocked In'),
                sum(1 for row in all_rows if row['Clock Out'] != 'Not Clocked Out'),
                f"{sum(float(row['Total Hours']) for row in all_rows) / len(set(row['Employee Email'] for row in all_rows)):.2f}"
            ]
        }
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='Summary', index=False)

        # Create Attendance sheet
        attendance_data = []
        for row in all_rows:
            attendance_data.append({
                'Date': row['Date'],
                'Employee Email': row['Employee Email'],
                'Clock In': row['Clock In'],
                'Clock Out': row['Clock Out'],
                'Total Hours': row['Total Hours']
            })
        attendance_df = pd.DataFrame(attendance_data)
        attendance_df.to_excel(writer, sheet_name='Attendance', index=False)

        # Create Tasks sheet
        tasks_data = []
        for row in all_rows:
            for task in row['Tasks']:
                tasks_data.append({
                    'Date': row['Date'],
                    'Employee Email': row['Employee Email'],
                    'Project': task['Project'],
                    'Epic': task['Epic'],
                    'Key Update': task['Key Update'],
                    'Hours Worked': task['Hours Worked']
                })
        tasks_df = pd.DataFrame(tasks_data)
        tasks_df.to_excel(writer, sheet_name='Tasks', index=False)

        # Get workbook and worksheet objects
        workbook = writer.book

        # Format for date columns
        date_format = workbook.add_format({'num_format': 'dd mmmm yyyy'})
        time_format = workbook.add_format({'num_format': 'hh:mm AM/PM'})
        number_format = workbook.add_format({'num_format': '0.00'})

        # Format Summary sheet
        summary_sheet = writer.sheets['Summary']
        summary_sheet.set_column('A:A', 30)
        summary_sheet.set_column('B:B', 40)

        # Format Attendance sheet
        attendance_sheet = writer.sheets['Attendance']
        attendance_sheet.set_column('A:A', 20, date_format)
        attendance_sheet.set_column('B:B', 30)
        attendance_sheet.set_column('C:D', 15, time_format)
        attendance_sheet.set_column('E:E', 15, number_format)

        # Format Tasks sheet
        tasks_sheet = writer.sheets['Tasks']
        tasks_sheet.set_column('A:A', 20, date_format)
        tasks_sheet.set_column('B:B', 30)
        tasks_sheet.set_column('C:D', 30)
        tasks_sheet.set_column('E:E', 50)
        tasks_sheet.set_column('F:F', 15, number_format)

        # Add filters to all sheets
        for sheet in [attendance_sheet, tasks_sheet]:
            sheet.autofilter(0, 0, len(sheet.table), len(sheet.table[0]) - 1)

        # Save the Excel file
        writer.close()
        return excel_file

    except Exception as e:
        print(f"Error generating Excel report: {str(e)}")
        return None

def generate_attendance_report(employee_emails=None, dates=None):
    """
    Generate attendance report for specified employees and dates
    
    Args:
        employee_emails (list): List of employee email IDs to filter. If None, includes all employees
        dates (list): List of dates in format 'DD MMMM YYYY'. If None, includes all available dates
    
    Returns:
        bool: True if report was sent successfully, False otherwise
    """
    try:
        # Get all employees
        employees_ref = db.collection("employees")
        employee_docs = employees_ref.stream()
        
        # Prepare data for email
        all_rows = []
        all_dates = set()
        
        for emp in employee_docs:
            email = emp.id
            # Skip if email filtering is enabled and this email is not in the list
            if employee_emails and email not in employee_emails:
                continue
                
            print(f'Doing for {email}')
            data = emp.to_dict()
            tasks_by_date = data.get("tasks", {})
            
            # Process each date
            for date_str, date_data in tasks_by_date.items():
                # Skip if date filtering is enabled and this date is not in the list
                if dates and date_str not in dates:
                    continue
                    
                all_dates.add(date_str)
                
                # Process clock in/out times
                clock_in_time = date_data.get("clockInTime", "")
                if clock_in_time:
                    if isinstance(clock_in_time, datetime):
                        clock_in_time = clock_in_time + timedelta(hours=5, minutes=30)
                    else:
                        clock_in_time = datetime.fromtimestamp(clock_in_time/1000) + timedelta(hours=5, minutes=30)
                    clock_in_time = clock_in_time.strftime('%I:%M %p')
                
                clock_out_time = date_data.get("clockOutTime", "")
                if clock_out_time:
                    if isinstance(clock_out_time, datetime):
                        clock_out_time = clock_out_time + timedelta(hours=5, minutes=30)
                    else:
                        clock_out_time = datetime.fromtimestamp(clock_out_time/1000) + timedelta(hours=5, minutes=30)
                    clock_out_time = clock_out_time.strftime('%I:%M %p')
                
                # Process tasks
                tasks_completed = []
                
                # Get all keys that are not standard fields
                standard_fields = {'clockInTime', 'clockOutTime', 'clockInLocation', 'clockOutLocation', 'earlyClockoutReason'}
                project_keys = [key for key in date_data.keys() if key not in standard_fields]
                
                print(f"Project keys for {email} on {date_str}: {project_keys}")
                
                for project_key in project_keys:
                    project_data = date_data[project_key]
                    if isinstance(project_data, dict):
                        # Handle task data
                        task_data = {
                            "Project": project_data.get("project", ""),
                            "Epic": project_data.get("epic", ""),
                            "Key Update": project_data.get("keyUpdate", ""),
                            "Hours Worked": round(project_data.get("seconds", 0) / 3600, 2)
                        }
                        tasks_completed.append(task_data)
                
                # Calculate total hours worked
                total_hours = sum(task['Hours Worked'] for task in tasks_completed)
                
                all_rows.append({
                    "Date": date_str,
                    "Employee Email": email,
                    "Clock In": clock_in_time or "Not Clocked In",
                    "Clock Out": clock_out_time or "Not Clocked Out",
                    "Total Hours": f"{total_hours:.2f}",
                    "Tasks": tasks_completed
                })
                print(f'Done for {email}')
        
        if not all_rows:
            print("No data found for the specified filters")
            return False
            
        # Sort dates chronologically
        sorted_dates = sorted(all_dates, key=lambda x: datetime.strptime(x, '%d %B %Y'))
        
        # Create HTML content
        html_content = f"""
        <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                }}
                h2 {{
                    color: #2A5CAA;
                    text-align: center;
                    margin-bottom: 30px;
                }}
                .date-section {{
                    margin-bottom: 40px;
                    page-break-inside: avoid;
                }}
                .date-header {{
                    background-color: #2A5CAA;
                    color: white;
                    padding: 10px;
                    margin-bottom: 20px;
                    border-radius: 5px;
                }}
                table {{
                    border-collapse: collapse;
                    width: 100%;
                    margin-bottom: 20px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                }}
                th, td {{
                    border: 1px solid #ddd;
                    padding: 12px;
                    text-align: left;
                }}
                th {{
                    background-color: #2A5CAA;
                    color: white;
                }}
                tr:nth-child(even) {{
                    background-color: #f9f9f9;
                }}
                .task-table {{
                    margin-top: 10px;
                    font-size: 0.9em;
                    background-color: white;
                }}
                .task-table th {{
                    background-color: #1E4A96;
                }}
                .task-table th, .task-table td {{
                    padding: 8px;
                }}
                .summary {{
                    background-color: #f8f9fa;
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                }}
            </style>
        </head>
        <body>
            <h2>Attendance Report</h2>
            
            <div class="summary">
                <h3>Summary</h3>
                <p>Total Employees: {len(set(row['Employee Email'] for row in all_rows))}</p>
                <p>Date Range: {sorted_dates[0]} to {sorted_dates[-1]}</p>
                <p>Total Days: {len(sorted_dates)}</p>
            </div>
        """
        
        # Group rows by date
        for date in sorted_dates:
            date_rows = [row for row in all_rows if row['Date'] == date]
            
            # Calculate date-specific summary
            clocked_in = sum(1 for row in date_rows if row['Clock In'] != 'Not Clocked In')
            clocked_out = sum(1 for row in date_rows if row['Clock Out'] != 'Not Clocked Out')
            
            html_content += f"""
            <div class="date-section">
                <div class="date-header">
                    <h3>{date}</h3>
                    <p>Employees Clocked In: {clocked_in} | Employees Clocked Out: {clocked_out}</p>
                </div>
                
                <table>
                    <tr>
                        <th>Employee</th>
                        <th>Clock In</th>
                        <th>Clock Out</th>
                        <th>Total Hours</th>
                        <th>Tasks</th>
                    </tr>
            """
            
            for row in date_rows:
                tasks_html = ""
                if row['Tasks']:
                    tasks_html = "<table class='task-table'>"
                    tasks_html += "<tr><th>Project</th><th>Epic</th><th>Update</th><th>Hours</th></tr>"
                    for task in row['Tasks']:
                        tasks_html += f"""
                        <tr>
                            <td>{task['Project']}</td>
                            <td>{task['Epic']}</td>
                            <td>{task['Key Update']}</td>
                            <td>{task['Hours Worked']:.2f}</td>
                        </tr>
                        """
                    tasks_html += "</table>"
                
                html_content += f"""
                <tr>
                    <td>{row['Employee Email']}</td>
                    <td>{row['Clock In']}</td>
                    <td>{row['Clock Out']}</td>
                    <td>{row['Total Hours']}</td>
                    <td>{tasks_html}</td>
                </tr>
                """
            
            html_content += """
                </table>
            </div>
            """
        
        html_content += """
            <div style="text-align: center; margin-top: 30px; color: #666;">
                <p>This is an automated report generated by Digital HR System</p>
            </div>
        </body>
        </html>
        """
        
        # Generate Excel report
        excel_file = generate_excel_report(all_rows, sorted_dates)
        
        # Send email with both HTML and Excel attachment
        date_range = f"{sorted_dates[0]} to {sorted_dates[-1]}" if len(sorted_dates) > 1 else sorted_dates[0]
        subject = f"Attendance Report - {date_range}"
        recipient_list = ["jatin.jagani@sciverse.co.in", "rahul.singh@sciverse.co.in", "mrinmayee.kulkarni@sciverse.co.in"]  # Add more recipients as needed
        
        success, message = send_email(subject, html_content, recipient_list, excel_file)
        if success:
            print(f"Report sent successfully for {len(sorted_dates)} days")
            # Clean up the Excel file after sending
            if excel_file and os.path.exists(excel_file):
                os.remove(excel_file)
        else:
            print(f"Error sending report: {message}")
        
        return success
        
    except Exception as e:
        print(f"Error generating report: {str(e)}")
        return False

if __name__ == "__main__":
    # Example usage:
    
    # 1. Generate report for all employees and all dates
    # generate_attendance_report()
    
    # 2. Generate report for specific employees
    # generate_attendance_report(employee_emails=['employee1@example.com', 'employee2@example.com'])
    
    # 3. Generate report for specific dates
    # generate_attendance_report(dates=['01 January 2024', '02 January 2024'])
    
    # 4. Generate report for specific employees and dates
    # generate_attendance_report(
    #     employee_emails=['employee1@example.com', 'employee2@example.com'],
    #     dates=['01 January 2024', '02 January 2024']
    # )
    
    # Default: Generate today's report for all employees
    # today = datetime.now().strftime('%d %B %Y')
    today = '10 June 2025'
    generate_attendance_report(dates=[today])