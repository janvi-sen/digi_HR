from django.db import models
from django.utils import timezone
from employees.models import Employee
from projects.models import Project
from epics.models import Epic
import os

class BaseModel(models.Model):
    """
    Abstract base model with common fields
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

def get_attendance_selfie_path(instance, filename):
    """
    Generate path for attendance selfie uploads
    Format: daily_attendance/{date}/{type}_{timestamp}.{ext}
    """
    # Get file extension
    ext = filename.split('.')[-1]
    
    # Get current timestamp
    timestamp = timezone.now().strftime('%Y%m%d_%H%M%S')
    
    # Determine if it's clock in or clock out
    selfie_type = 'clockin' if instance.clock_in_selfie else 'clockout'
    
    # Create path
    path = f'daily_attendance/{instance.date}/{selfie_type}_{timestamp}.{ext}'
    
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(f'media/{path}'), exist_ok=True)
    
    return path

class DailyAttendance(BaseModel):
    """
    Model to track employee daily attendance
    """
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='daily_attendance'
    )
    date = models.DateField()
    clock_in_time = models.DateTimeField()
    clock_out_time = models.DateTimeField(null=True, blank=True)
    clock_in_location = models.CharField(max_length=255, null=True, blank=True)
    clock_out_location = models.CharField(max_length=255, null=True, blank=True)
    lat_long = models.CharField(max_length=255, null=True, blank=True)
    clock_in_selfie = models.URLField(
        max_length=500,
        null=True,
        blank=True
    )
    clock_out_selfie = models.URLField(
        max_length=500,
        null=True,
        blank=True
    )
    total_working_hours = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Total working hours for the day"
    )
    is_clocked_out = models.BooleanField(default=False)
    notes = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'daily_attendance'
        ordering = ['-date', '-clock_in_time']
        unique_together = ['employee', 'date']

    def __str__(self):
        return f"{self.employee.email} - {self.date}"

    def save(self, *args, **kwargs):
        """Calculate total working hours when clocking out"""
        if self.clock_out_time and not self.total_working_hours:
            duration = self.clock_out_time - self.clock_in_time
            self.total_working_hours = round(duration.total_seconds() / 3600, 2)
        super().save(*args, **kwargs)

class DailyTask(BaseModel):
    """
    Model to track employee daily tasks
    """
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='daily_tasks'
    )
    attendance = models.ForeignKey(
        DailyAttendance,
        on_delete=models.CASCADE,
        related_name='tasks',
        help_text="Reference to the attendance record for this task",
        null=True,
        blank=True
    )
    date = models.DateField()
    project = models.ForeignKey(
        'projects.Project',  # Use string reference to avoid circular imports
        on_delete=models.CASCADE,
        related_name='daily_tasks'
    )
    epic = models.ForeignKey(
        'epics.Epic',  # Use string reference to avoid circular imports
        on_delete=models.CASCADE,
        related_name='daily_tasks'
    )
    tasks_completed = models.JSONField(
        help_text="List of tasks completed for this project and epic",
        null=True,
        blank=True
    )
    start_time = models.DateTimeField()
    end_time = models.DateTimeField(null=True, blank=True)
    total_time_spent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Total time spent in hours"
    )
    notes = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'daily_tasks'
        ordering = ['-date', '-start_time']

    def __str__(self):
        return f"{self.employee.email} - {self.project.name} - {self.date}"

    def save(self, *args, **kwargs):
        """Calculate total time spent when ending task"""
        if self.end_time and not self.total_time_spent:
            duration = self.end_time - self.start_time
            self.total_time_spent = round(duration.total_seconds() / 3600, 2)
        super().save(*args, **kwargs) 