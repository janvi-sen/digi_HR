from rest_framework import serializers
from .models import Project
from django.contrib.auth import get_user_model

User = get_user_model()

class ProjectSerializer(serializers.ModelSerializer):
    """
    Serializer for Project model with CRUD operations
    """
    # project_manager_name = serializers.CharField(source='project_manager.email_id', read_only=True)
    team_members_count = serializers.SerializerMethodField()
    # is_active = serializers.BooleanField(read_only=True)
    duration = serializers.IntegerField(read_only=True)

    class Meta:
        model = Project
        fields = [
            'id', 'name', 'description', 'status', 'priority',
            'start_date', 'end_date',
            'team_members', 'team_members_count', 'budget', 'progress',
            'notes', 'is_active', 'duration', 'created_at', 'updated_at', 'created_by'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def get_team_members_count(self, obj):
        """Get count of team members"""
        return obj.team_members.count()

    def validate(self, data):
        """Validate project dates"""
        start_date = data.get('start_date')
        end_date = data.get('end_date')

        if start_date and end_date and start_date > end_date:
            raise serializers.ValidationError("End date must be after start date")

        return data

    def create(self, validated_data):
        """Create a new project"""
        # Extract team_members from validated_data
        team_members = validated_data.pop('team_members', [])
        
        # Create project
        project = Project.objects.create(**validated_data)
        
        # Add team members if provided
        if team_members:
            project.team_members.set(team_members)
        
        return project

class ProjectDetailedSerializer(serializers.ModelSerializer):
    """
    Serializer for Project model with detailed information
    """
    project_manager_name = serializers.CharField(source='project_manager.full_name', read_only=True)
    team_members_count = serializers.SerializerMethodField()
    # is_active = serializers.BooleanField(read_only=True)
    team_members_names = serializers.SerializerMethodField()
    epics = serializers.SerializerMethodField()
    epics_count = serializers.SerializerMethodField()
    duration = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = Project
        fields = [
            'id', 'name', 'description', 'status', 'priority',
            'start_date', 'end_date', 'project_manager', 'project_manager_name',
            'team_members_names', 'team_members_count', 'budget', 'progress',
            'notes', 'duration', 'created_at', 'updated_at', 'epics_count', 'epics'
        ]
    
    
    def get_team_members_names(self, obj):
        return [(member.full_name, member.email) for member in obj.team_members.all()]
    
    def get_team_members_count(self, obj):
        return obj.team_members.count()
        
    def get_epics(self, obj):
        return obj.epics.values('id', 'name', 'status', 'tasks', 'description')
    
    def get_epics_count(self, obj):
        return obj.epics.count()

    def validate(self, data):
        """Validate project dates"""
        start_date = data.get('start_date')
        end_date = data.get('end_date')

        if start_date and end_date and start_date > end_date:
            raise serializers.ValidationError("End date must be after start date")

        return data

class ProjectListSerializer(serializers.ModelSerializer):
    """
    Lightweight serializer for project lists
    """
    # project_manager_name = serializers.CharField(source='project_manager.email_id', read_only=True)
    team_members_count = serializers.SerializerMethodField()
    # is_active = serializers.BooleanField(read_only=True)
    team_members_names = serializers.SerializerMethodField()
    epics = serializers.SerializerMethodField()
    epics_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = [
            'id', 'name', 'status', 'priority', 'description',
            'team_members_count', 'progress', 'start_date',
            'end_date', 'epics_count', 'epics', 'team_members_names'
        ]

    def get_team_members_count(self, obj):
        return obj.team_members.count()
        
    def get_team_members_names(self, obj):
        return [(member.full_name, member.email) for member in obj.team_members.all()]
        
    def get_epics(self, obj):
        return obj.epics.values('id', 'name', 'status', 'tasks', 'description')
        
    def get_epics_count(self, obj):
        return obj.epics.count()