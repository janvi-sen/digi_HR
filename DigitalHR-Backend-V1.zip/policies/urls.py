from django.urls import path
from . import views

urlpatterns = [
    # Policy CRUD operations
    path('', views.create_or_update_policy, name='create_or_update_policy'),  # POST - Create or update policy
    path('list/', views.list_policies, name='list_policies'),  # GET - List all policies
    path('acknowledgment-status/', views.get_policies_with_acknowledgment_status, name='get_policies_with_acknowledgment_status'),  # GET - Get policies with acknowledgment status
    path('<int:policy_id>/', views.get_policy_detail, name='get_policy_detail'),  # GET - Get policy details
    path('<int:policy_id>/status/', views.update_policy_status, name='update_policy_status'),  # PUT - Update policy status
    path('<int:policy_id>/acknowledge/', views.acknowledge_policy, name='acknowledge_policy'),  # PUT - Employee acknowledges policy
    
    # Office Locations CRUD operations
    path('locations/', views.create_office_location, name='create_office_location'),  # POST - Create office location
    path('locations/list/', views.list_office_locations, name='list_office_locations'),  # GET - List all office locations
    path('locations/<int:location_id>/', views.get_office_location_detail, name='get_office_location_detail'),  # GET - Get office location details
    path('locations/<int:location_id>/update/', views.update_office_location, name='update_office_location'),  # PUT - Update office location
    path('locations/<int:location_id>/delete/', views.delete_office_location, name='delete_office_location'),  # DELETE - Delete office location
    
    # Public Holidays CRUD operations
    path('holidays/', views.create_public_holiday, name='create_public_holiday'),  # POST - Create public holiday
    path('holidays/list/', views.list_public_holidays, name='list_public_holidays'),  # GET - List all public holidays
    path('holidays/<int:holiday_id>/', views.get_public_holiday_detail, name='get_public_holiday_detail'),  # GET - Get public holiday details
    path('holidays/<int:holiday_id>/update/', views.update_public_holiday, name='update_public_holiday'),  # PUT - Update public holiday
    path('holidays/<int:holiday_id>/delete/', views.delete_public_holiday, name='delete_public_holiday'),  # DELETE - Delete public holiday
    
    # Generic policies
    path('terms-and-conditions/', views.get_terms_and_conditions, name='get_terms_and_conditions'),  # GET - Get terms and conditions
    path('privacy-policy', views.get_privacy_policy, name='get_privacy_policy')
] 