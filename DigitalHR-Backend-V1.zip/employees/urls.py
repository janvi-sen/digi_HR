from django.urls import path
from . import views

app_name = 'employees'

urlpatterns = [
    # Employee details and information
    path('details/', views.get_employee_details, name='employee-details'),
        
    # Employee onboarding and CRUD operations
    path('onboard/', views.onboard_employee, name='onboard_employee'),
    path('pending-onboarding/', views.list_pending_onboarding, name='list_pending_onboarding'),    
    path('list/', views.list_employees, name='list_employees'),
    # path('detail/', views.get_employee_detail, name='employee_detail'),
    path('update/', views.update_employee, name='update_employee'),
    path('admin-update/', views.admin_update_employee, name='admin_update_employee'),
    path('profile-photo/', views.upload_profile_photo, name='upload_profile_photo'),
    path('delete/', views.admin_delete_employee_complete, name='delete_employee'),
    path('verify/', views.verify_employee, name='verify_employee'),
    path('birthday/', views.get_birthday_employees, name='get_birthday_employees'),
    
    # Employee statistics and analytics
    path('statistics/', views.employee_statistics, name='employee_statistics'),
    
    # Document management
    path('documents/upload/', views.upload_employee_document_form, name='upload_document'),
    path('documents/list/', views.get_employee_documents, name='employee_documents'),
    path('documents/download/<int:document_id>/', views.download_employee_document, name='download_document'),
    
    # Employee location management
    path('locations/', views.list_employee_locations, name='list_employee_locations'),
    path('locations/create/', views.create_employee_location, name='create_employee_location'),
    path('locations/<int:location_id>/', views.get_employee_location, name='get_employee_location'),
    path('locations/<int:location_id>/delete/', views.delete_employee_location, name='delete_employee_location'),
    
    # Test notification endpoint
    path('test-notification/', views.test_push_notification, name='test_push_notification'),
    path('test-force-clockout/', views.test_force_clockout, name='test_force_clockout'),
  ] 