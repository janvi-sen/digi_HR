from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('send-otp/', views.send_otp, name='send_otp'),
    path('verify-otp/', views.verify_otp, name='verify_otp'),
    path('reset-password/', views.reset_password, name='reset_password'),
    path('check-user-exists/', views.check_user_exists, name='check_user_exists'),
    path('delete-user/', views.admin_delete_user_complete, name='admin_delete_user_complete'),
    # path('refresh-token/', views.refresh_token, name='refresh_token'),
] 