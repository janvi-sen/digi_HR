from rest_framework import serializers
from .models import DailyAttendance, DailyTask
from employees.models import Employee
from projects.models import Project
from epics.models import Epic

class DailyAttendanceSerializer(serializers.ModelSerializer):
    """
    Serializer for DailyAttendance model
    """
    employee_name = serializers.CharField(source='employee.email_id', read_only=True)
    # clock_in_selfie_url = serializers.SerializerMethodField()
    # clock_out_selfie_url = serializers.SerializerMethodField()

    class Meta:
        model = DailyAttendance
        fields = [
            'id', 'employee', 'employee_name', 'date', 'clock_in_time',
            'clock_out_time', 'clock_in_location', 'clock_out_location',
            'clock_in_selfie', 'clock_out_selfie', 'total_working_hours', 'is_clocked_out',
            'notes', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'employee']

    # def get_clock_in_selfie_url(self, obj):
    #     """Get URL for clock in selfie"""
    #     if obj.clock_in_selfie:
    #         return self.context['request'].build_absolute_uri(obj.clock_in_selfie.url)
    #     return None

    # def get_clock_out_selfie_url(self, obj):
    #     """Get URL for clock out selfie"""
    #     if obj.clock_out_selfie:
    #         return self.context['request'].build_absolute_uri(obj.clock_out_selfie.url)
    #     return None

    def validate(self, data):
        """Validate attendance data"""
        if data.get('clock_out_time') and data.get('clock_in_time') > data.get('clock_out_time'):
            raise serializers.ValidationError("Clock out time must be after clock in time")
        return data

class DailyTaskSerializer(serializers.ModelSerializer):
    """
    Serializer for DailyTask model
    """
    employee_name = serializers.CharField(source='employee.email_id', read_only=True)
    project_name = serializers.CharField(source='project.name', read_only=True)
    epic_name = serializers.CharField(source='epic.name', read_only=True)

    class Meta:
        model = DailyTask
        fields = [
            'id', 'employee', 'employee_name', 'date', 'project',
            'project_name', 'epic', 'epic_name', 'tasks_completed',
            'start_time', 'end_time', 'total_time_spent', 'notes',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'employee']

    def validate(self, data):
        """Validate task data"""
        if data.get('end_time') and data.get('start_time') > data.get('end_time'):
            raise serializers.ValidationError("End time must be after start time")
        return data

class DailyAttendanceListSerializer(serializers.ModelSerializer):
    """
    Lightweight serializer for daily attendance lists
    """
    employee_name = serializers.CharField(source='employee.email_id', read_only=True)

    class Meta:
        model = DailyAttendance
        fields = [
            'id', 'employee_name', 'date', 'clock_in_time',
            'clock_out_time', 'total_working_hours', 'is_clocked_out'
        ]

class DailyTaskListSerializer(serializers.ModelSerializer):
    """
    Lightweight serializer for daily task lists
    """
    employee_name = serializers.CharField(source='employee.email_id', read_only=True)
    project_name = serializers.CharField(source='project.name', read_only=True)
    epic_name = serializers.CharField(source='epic.name', read_only=True)

    class Meta:
        model = DailyTask
        fields = [
            'id', 'employee_name', 'date', 'project_name',
            'epic_name', 'start_time', 'end_time', 'total_time_spent'
        ] 