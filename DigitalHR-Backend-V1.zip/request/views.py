import threading
import uuid
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.utils import timezone
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.core.paginator import Paginator
from django.db.models import Q
from datetime import datetime
import calendar
from django.http import Http404

from utils.boto_utils import S3DocumentUploader
from utils.email_utils import EmailService
from utils.notification_utils import NotificationService
from .models import Leave, WFH, Reimbursement, TravelRequest, EmergencyFundRequest, CompOffCreditRequest, Complaint, ComplaintAttachment, Separation, DevicesPeripherals, IPPatentSupportRequest, IPPatentSupportAttachment
from .serializers import (
    LeaveSerializer, WFHSerializer, ReimbursementSerializer,
    TravelRequestSerializer, EmergencyFundRequestSerializer,
    CompOffCreditRequestSerializer, ComplaintCreateSerializer, ComplaintAttachmentSerializer, ComplaintListSerializer, SeparationCreateSerializer,
    DevicesPeripheralsCreateSerializer, DevicesPeripheralsListSerializer, SeparationListSerializer,
    IPPatentSupportRequestSerializer, IPPatentSupportRequestCreateSerializer, IPPatentSupportRequestUpdateSerializer, IPPatentSupportRequestListSerializer
)
from employees.models import Employee
from utils.general_utils import ApiResponse
from datetime import datetime
from rest_framework.parsers import MultiPartParser, FormParser
from utils.notification_utils import notification_service
import logging

logger = logging.getLogger(__name__)

def apply_search_and_filters(queryset, request, model_name):
    """
    Apply search and filtering to queryset based on request parameters
    
    Args:
        queryset: The base queryset to filter
        request: The HTTP request object
        model_name: Name of the model for specific filtering logic
        
    Returns:
        Filtered queryset
    """
    # Get search parameter
    search = request.GET.get('search', '').strip()
    
    # Get year and month filters
    year = request.GET.get('year', '').strip()
    month = request.GET.get('month', '').strip()
    
    # Apply search if provided
    if search:
        if model_name == 'Leave':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(description__icontains=search) |
                Q(status__icontains=search) |
                Q(leave_type__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'WFH':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(description__icontains=search) |
                Q(status__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'Reimbursement':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(description__icontains=search) |
                Q(status__icontains=search) |
                Q(category__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'TravelRequest':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(subject__icontains=search) |
                Q(travel_location__icontains=search) |
                Q(mode_of_transport__icontains=search) |
                Q(status__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'EmergencyFundRequest':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(reason__icontains=search) |
                Q(repayment_plan__icontains=search) |
                Q(status__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'CompOffCreditRequest':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(reason__icontains=search) |
                Q(status__icontains=search) |
                Q(request_type__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'Complaint':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(title__icontains=search) |
                Q(description__icontains=search) |
                Q(status__icontains=search) |
                Q(priority__icontains=search)
            )
        elif model_name == 'Separation':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(reason__icontains=search) |
                Q(status__icontains=search) |
                Q(comments__icontains=search) |
                Q(approved_by__full_name__icontains=search)
            )
        elif model_name == 'DevicesPeripherals':
            queryset = queryset.filter(
                Q(employee__full_name__icontains=search) |
                Q(requested_item__icontains=search) |
                Q(purpose__icontains=search) |
                Q(status__icontains=search) |
                Q(urgency__icontains=search) |
                Q(comments__icontains=search)
            )
        elif model_name == 'IPPatentSupportRequest':
            queryset = queryset.filter(
                Q(created_by__full_name__icontains=search) |
                Q(project_name__icontains=search) |
                Q(description__icontains=search) |
                Q(protection_type__icontains=search) |
                Q(status__icontains=search) |
                Q(approved_by__full_name__icontains=search) |
                Q(comments__icontains=search)
            )
    
    # Apply year filter
    if year and year.isdigit():
        year = int(year)
        if model_name in ['Leave', 'WFH', 'TravelRequest']:
            # For models with from_date field
            queryset = queryset.filter(from_date__year=year)
        elif model_name in ['Reimbursement', 'CompOffCreditRequest']:
            # For models with date field
            queryset = queryset.filter(date__year=year)
        elif model_name == 'EmergencyFundRequest':
            # For models with fund_needed_date field
            queryset = queryset.filter(fund_needed_date__year=year)
        elif model_name in ['Complaint', 'Separation', 'DevicesPeripherals', 'IPPatentSupportRequest']:
            # For models with created_at field
            queryset = queryset.filter(created_at__year=year)
    
    # Apply month filter
    if month and month.isdigit():
        month = int(month)
        if 1 <= month <= 12:
            if model_name in ['Leave', 'WFH', 'TravelRequest']:
                # For models with from_date field
                queryset = queryset.filter(from_date__month=month)
            elif model_name in ['Reimbursement', 'CompOffCreditRequest']:
                # For models with date field
                queryset = queryset.filter(date__month=month)
            elif model_name == 'EmergencyFundRequest':
                # For models with fund_needed_date field
                queryset = queryset.filter(fund_needed_date__month=month)
            elif model_name in ['Complaint', 'Separation', 'DevicesPeripherals', 'IPPatentSupportRequest']:
                # For models with created_at field
                queryset = queryset.filter(created_at__month=month)
    
    return queryset

@swagger_auto_schema(
    method='get',
    operation_description="Get list of leave requests with pagination, search, and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="email_id to filter requests", type=openapi.TYPE_STRING),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('leave_type', openapi.IN_QUERY, description="Filter by leave type", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, description, status, leave type, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Leave requests retrieved successfully",
            schema=LeaveSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_leave_requests(request):
    """Get paginated list of leave requests with filtering options"""
    email_id = request.user.email_id
    employee = Employee.objects.filter(email=email_id).first()
    filter_email_id = request.GET.get('email_id')
    print(filter_email_id)
    # if not email_id:
    #     return ApiResponse.error(
    #         message="email_id is required",
    #         status_code=status.HTTP_400_BAD_REQUEST
    #     )
        
    # employee = get_object_or_404(Employee, email=email_id)
    
    # If user is HR manager, return all requests
    if request.user.employee_profile.is_hr_manager:
        queryset = Leave.objects.all().order_by('-created_at')
    else:
        # Otherwise, only return requests for the logged-in employee
        if request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only view your own requests",
                status_code=status.HTTP_403_FORBIDDEN
            )
        queryset = Leave.objects.filter(employee=employee).order_by('-created_at')
    
    if filter_email_id:
        print(filter_email_id)
        filtered_employee = Employee.objects.filter(email=filter_email_id).first()
        if filtered_employee:
            print(filtered_employee)
            queryset = queryset.filter(employee=filtered_employee)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'Leave')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
        
    leave_type = request.GET.get('leave_type')
    if leave_type:
        queryset = queryset.filter(leave_type=leave_type)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    requests_page = paginator.get_page(page)
    
    if requests_page:
        serializer = LeaveSerializer(requests_page, many=True)
        return ApiResponse.success(
            data=serializer.data,
            message="Leave requests retrieved successfully"
        )
    else:
        # If no leave requests found, return employee's basic leave info
        employee_data = {
            'employee': employee.id,  # Should reference ID rather than full object
            'employee_name': employee.full_name,
            'designation': employee.designation,
            'employee_profile_photo': employee.profile_photo_url,
            'available_leaves': {
                'PL': employee.leaves_allotted['PL'] - employee.leaves_taken['PL'],
                'SL': employee.leaves_allotted['SL'] - employee.leaves_taken['SL'],
                'CL': employee.leaves_allotted['CL'] - employee.leaves_taken['CL'],
                'WFH': employee.leaves_allotted['WFH'] - employee.leaves_taken['WFH']
            }
        }
        return ApiResponse.success(
            data=[employee_data], 
            message="No leave requests found for employee"  # More accurate message
        )
        # serializer = LeaveSerializer([employee_data], many=True)


@swagger_auto_schema(
    method='post',
    operation_description="Create a new leave request",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'leave_type',
            openapi.IN_FORM,
            description="Type of leave",
            type=openapi.TYPE_STRING,
            required=True,
            enum=['CL', 'SL', 'PL', 'HD']
        ),
        openapi.Parameter(
            'leave_title',
            openapi.IN_FORM,
            description="Title of leave required for HD leave",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'from_date',
            openapi.IN_FORM,
            description="Start date of leave",
            type=openapi.TYPE_STRING,
            required=True,
            format='date'
        ),
        openapi.Parameter(
            'to_date',
            openapi.IN_FORM,
            description="End date of leave",
            type=openapi.TYPE_STRING,
            required=True,
            format='date'
        ),
        openapi.Parameter(
            'description',
            openapi.IN_FORM,
            description="Reason for leave",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'supporting_documents',
            openapi.IN_FORM,
            description="Supporting documents",
            type=openapi.TYPE_FILE,
            required=False
        ),
    ],
    responses={
        201: openapi.Response(
            description="Leave request created successfully",
            schema=LeaveSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_leave_request(request):
    """Create a new leave request"""
    email = request.user.email_id
    employee = Employee.objects.filter(email=email).first()
    if not employee:
        return ApiResponse.error(
            message="Employee not found",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    # employee = get_object_or_404(Employee, employee_id=employee_id)
    leave_type = request.data.get('leave_type')
    if leave_type not in ['CL', 'SL', 'PL', 'HD']:
        return ApiResponse.error(
            message="Invalid leave type",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Check if user is creating request for themselves
    if not request.user.employee_profile.is_hr_manager and request.user.employee_profile != employee:
        return ApiResponse.error(
            message="You can only create requests for yourself",
            status_code=status.HTTP_403_FORBIDDEN
        )

    leave_type = request.data.get('leave_type')
    from_date = request.data.get('from_date')
    to_date = request.data.get('to_date')
    if isinstance(from_date, str):
        from_date = datetime.strptime(from_date, '%Y-%m-%d').date()
    if isinstance(to_date, str):
        to_date = datetime.strptime(to_date, '%Y-%m-%d').date()
    days_requested = (to_date - from_date).days + 1
    
    if leave_type == 'HD':
        leave_title = request.data.get('leave_title')
        if not leave_title:
            return ApiResponse.error(
                message="Leave title is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        days_requested = 0.5
        
    print(f'days requested: {days_requested}')
    if leave_type == 'CL':
        if employee.leaves_allotted['CL'] - employee.leaves_taken['CL'] < days_requested:
            return ApiResponse.error(
                message="Not enough CL leaves available",
                status_code=status.HTTP_400_BAD_REQUEST
            )
    # elif leave_type == 'SL':
    #     if employee.leaves_allotted['SL'] - employee.leaves_taken['SL'] < days_requested:
    #         return ApiResponse.error(
    #             message="Not enough SL leaves available",
    #             status_code=status.HTTP_400_BAD_REQUEST
    #         )
    # elif leave_type == 'PL':
    #     if employee.leaves_allotted['PL'] - employee.leaves_taken['PL'] < days_requested:
    #         return ApiResponse.error(
    #             message="Not enough PL leaves available",
    #             status_code=status.HTTP_400_BAD_REQUEST
    #         )
    # elif leave_type == 'HD':
    #     if (employee.leaves_allotted['CL'] + employee.leaves_allotted['PL'] - employee.leaves_taken['CL'] - employee.leaves_taken['PL']) < days_requested:
    #         return ApiResponse.error(
    #             message="Not enough CL or PL leaves available",
    #             status_code=status.HTTP_400_BAD_REQUEST
    #         )
    
    existing_leaves = Leave.objects.filter(
        employee=employee,
        status__in=['pending', 'approved']
    )
    
    # Check for overlapping dates
    for leave in existing_leaves:
        # Check if the new leave request overlaps with any existing leave
        if (from_date <= leave.to_date and to_date >= leave.from_date):
            return ApiResponse.error(
                message=f"You already have a leave request from {leave.from_date} to {leave.to_date}. "
                "Please choose different dates.",
                status_code=status.HTTP_400_BAD_REQUEST
            )
    
    document_file = request.FILES.get('supporting_documents', '')
    if leave_type == "SL":
        if not document_file:
            return ApiResponse.error(
                message="Supporting documents are required for SL leave",
                status_code=status.HTTP_400_BAD_REQUEST
            )

    
    serializer = LeaveSerializer(data=request.data)
    if serializer.is_valid():
        leave_request = serializer.save(employee=employee)
        
        if document_file:
            uploader = S3DocumentUploader()
            success, result = uploader.upload_document(
                email_id=email,
                document_type="SL",
                file=document_file,
                document_collection="leave_supporting_documents",
                other_prefix=str(leave_request.id),
            )
            if not success:
                return ApiResponse.error(
                    message=f"File upload failed: {result}",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            leave_request.documents = result
            leave_request.save()
        
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        recipients = [request.user.email_id] + [hr_manager.email for hr_manager in hr_managers]
        threading.Thread(target=EmailService.send_leave_request_email, args=(leave_request, recipients)).start()
        try:
            
            # Prepare notification data
            notification_title = f"Leave Request: {employee.full_name}"
            notification_body = f"{leave_request.leave_type} - From: {leave_request.from_date} To: {leave_request.to_date}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'leave_request',
                'leave_request_id': str(leave_request.id),
                'title': leave_request.leave_type,
                'created_by': leave_request.employee.email,
                'scheduled_time': leave_request.from_date.isoformat() if leave_request.from_date else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for leave request {leave_request.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for leave request {leave_request.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for leave request {leave_request.id}: {str(e)}")
      
        return ApiResponse.created(
            data=serializer.data,
            message="Leave request created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='patch',
    operation_description="Update leave request status (HR manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Leave request status updated successfully",
            schema=LeaveSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Leave request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_leave_status(request, request_id):
    """Update leave request status (HR manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
        
    try:
        leave_request = Leave.objects.get(id=request_id)
    except Leave.DoesNotExist:
        return ApiResponse.not_found("Leave request not found")
        
    new_status = request.data.get('status')
    if new_status not in dict(Leave.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if leave_request.status == new_status:
        return ApiResponse.error(
            message=f"Leave request is already in {new_status} state",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if new_status == 'approved':
        employee = leave_request.employee
        leave_type = leave_request.leave_type
        days_requested = (leave_request.to_date - leave_request.from_date).days + 1
        if leave_type == 'HD':
            days_requested = 0.5
        if leave_type == 'CL':
            employee.leaves_taken['CL'] += days_requested
        elif leave_type == 'SL':
            employee.leaves_taken['SL'] += days_requested
        elif leave_type == 'PL':
            employee.leaves_taken['PL'] += days_requested
        elif leave_type == 'HD':
            if employee.leaves_allotted["CL"] > employee.leaves_taken['CL']:
                employee.leaves_taken['CL'] += days_requested
            elif employee.leaves_allotted["PL"] > employee.leaves_taken['PL']:
                employee.leaves_taken['PL'] += days_requested
            else:
                return ApiResponse.error(
                    message="Not enough CL or PL leaves available",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
        employee.save()
    
    leave_request.status = new_status
    leave_request.approved_at = timezone.now()
    leave_request.approved_by = request.user.employee_profile
    leave_request.comments = request.data.get('comments', '')
    leave_request.save()
    
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [leave_request.employee.email] + [hr_manager.email for hr_manager in hr_managers]
    threading.Thread(target=EmailService.send_leave_status_update_email, args=(leave_request, new_status, recipients, leave_request.comments)).start()
    # success, error = EmailService.send_leave_status_update_email(
    #     leave_request=leave_request,
    #     status=new_status,
    #     recipients=recipients,
    #     comments=leave_request.comments
    # )
    # if not success:
    #     print(f"Failed to send leave status update email: {error}")
    serializer = LeaveSerializer(leave_request)
    
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Leave Request Status: {new_status.capitalize()}"
        notification_body = f"Your leave request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'leave_request',
            'leave_request_id': str(leave_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=leave_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for leave request {leave_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for leave request {leave_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for leave request {leave_request.id}: {str(e)}")
    return ApiResponse.success(
        data=serializer.data,
        message="Leave request status updated successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of WFH requests with pagination, search, and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="email_id to filter requests", type=openapi.TYPE_STRING),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, description, status, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="WFH requests retrieved successfully",
            schema=WFHSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_wfh_requests(request):
    """Get paginated list of WFH requests with filtering options"""
    # employee_id = request.query_params.get('employee_id')
    # if not employee_id:
    #     return ApiResponse.error(
    #         message="employee_id is required",
    #         status_code=status.HTTP_400_BAD_REQUEST
    #     )
        
    email = request.user.email_id
    employee = get_object_or_404(Employee, email=email)
    filter_email_id = request.GET.get('email_id')
    
    
    # If user is HR manager, return all requests
    if request.user.employee_profile.is_hr_manager:
        queryset = WFH.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    else:
        # Otherwise, only return requests for the logged-in employee
        if request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only view your own requests",
                status_code=status.HTTP_403_FORBIDDEN
            )
        queryset = WFH.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'WFH')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    requests_page = paginator.get_page(page)
    
    serializer = WFHSerializer(requests_page, many=True)
    return ApiResponse.success(
        data=serializer.data,
        message="WFH requests retrieved successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new WFH request",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['from_date', 'to_date'],
        properties={
            'from_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Start date of WFH"),
            'to_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="End date of WFH"),
            'description': openapi.Schema(type=openapi.TYPE_STRING, description="Reason for WFH"),
            
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="WFH request created successfully",
            schema=WFHSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_wfh_request(request):
    """Create a new WFH request"""
    email = request.user.email_id
    # if not employee_id:
    #     return ApiResponse.error(
    #         message="employee_id is required",
    #         status_code=status.HTTP_400_BAD_REQUEST
    #     )
        
    employee = get_object_or_404(Employee, email=email)
    
    # Check if user is creating request for themselves
    # if not request.user.employee_profile.is_hr_manager and request.user.employee_profile != employee:
    #     return ApiResponse.error(
    #         message="You can only create requests for yourself",
    #         status_code=status.HTTP_403_FORBIDDEN
    #     )
    
    serializer = WFHSerializer(data=request.data)
    if serializer.is_valid():
        wfh_request = serializer.save(employee=employee)
        
        # Send email notification
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        recipients = [request.user.email_id] + [hr_manager.email for hr_manager in hr_managers]
        threading.Thread(target=EmailService.send_wfh_request_email, args=(wfh_request, recipients)).start()
        # email_sent, email_error = EmailService.send_wfh_request_email(
        #     wfh_request=wfh_request,
        #     recipients=recipients
        #)
        
        # if not email_sent:
        #     print(f"Failed to send WFH request notification email: {email_error}")
        
        try:
        
            # Prepare notification data
            notification_title = f"WFH Request: {employee.full_name}"
            notification_body = f"{employee.full_name} has requested to work from home - {wfh_request.description}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'wfh_request',
                'wfh_request_id': str(wfh_request.id),
                'title': wfh_request.status,
                'created_by': wfh_request.employee.email,
                'scheduled_time': wfh_request.from_date.isoformat() if wfh_request.from_date else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for wfh request {wfh_request.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for wfh request {wfh_request.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for wfh request {wfh_request.id}: {str(e)}")
      
        
            
        return ApiResponse.created(
            data=serializer.data,
            message="WFH request created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='patch',
    operation_description="Update WFH request status (HR manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="WFH request status updated successfully",
            schema=WFHSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="WFH request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_wfh_status(request, request_id):
    """Update WFH request status (HR manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
        
    try:
        wfh_request = WFH.objects.get(id=request_id)
    except WFH.DoesNotExist:
        return ApiResponse.not_found("WFH request not found")
        
    new_status = request.data.get('status')
    if new_status not in dict(WFH.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if wfh_request.status == new_status:
        return ApiResponse.error(
            message=f"WFH request is already in {new_status} state",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    wfh_request.status = new_status
    wfh_request.approved_at = timezone.now()
    wfh_request.approved_by = request.user.employee_profile
    wfh_request.comments = request.data.get('comments', '')
    wfh_request.save()
    
    # Send email notification
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [wfh_request.employee.email] + [hr_manager.email for hr_manager in hr_managers]
    threading.Thread(target=EmailService.send_wfh_status_update_email, args=(wfh_request, new_status, recipients, wfh_request.comments)).start()
    # success, error = EmailService.send_wfh_status_update_email(
    #     wfh_request=wfh_request,
    #     status=new_status,
    #     recipients=recipients,
    #     comments=wfh_request.comments
    # )
    # if not success:
    #     print(f"Failed to send WFH status update email: {error}")
    
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"WFH Request Status: {new_status.capitalize()}"
        notification_body = f"Your WFH request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'wfh_request',
            'wfh_request_id': str(wfh_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=wfh_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for wfh request {wfh_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for wfh request {wfh_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for wfh request {wfh_request.id}: {str(e)}")
    
    
    serializer = WFHSerializer(wfh_request)
    return ApiResponse.success(
        data=serializer.data,
        message="WFH request status updated successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of reimbursement requests with pagination, search, and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="email_id to filter requests", type=openapi.TYPE_STRING),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('category', openapi.IN_QUERY, description="Filter by category", type=openapi.TYPE_STRING),
        openapi.Parameter('project', openapi.IN_QUERY, description="Filter by project ID", type=openapi.TYPE_INTEGER),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, description, status, category, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Reimbursement requests retrieved successfully",
            schema=ReimbursementSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_reimbursement_requests(request):
    """Get paginated list of reimbursement requests with filtering options"""
    email = request.user.email_id
    if not email:
        return ApiResponse.error(
            message="email is required",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    employee = get_object_or_404(Employee, email=email)
    filter_email_id = request.GET.get('email_id')
    # If user is HR manager, return all requests
    if request.user.employee_profile.is_hr_manager:
        queryset = Reimbursement.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    else:
        # Otherwise, only return requests for the logged-in employee
        if request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only view your own requests",
                status_code=status.HTTP_403_FORBIDDEN
            )
        queryset = Reimbursement.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'Reimbursement')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
        
    category = request.GET.get('category')
    if category:
        queryset = queryset.filter(category=category)
        
    project_id = request.GET.get('project')
    if project_id:
        queryset = queryset.filter(project_id=project_id)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    requests_page = paginator.get_page(page)
    
    serializer = ReimbursementSerializer(requests_page, many=True)
    return ApiResponse.success(
        data=serializer.data,
        message="Reimbursement requests retrieved successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new reimbursement request",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('category', openapi.IN_FORM, description="Category of expense", type=openapi.TYPE_STRING, required=True, enum=['travel', 'food', 'accommodation', 'supplies', 'stationery', 'medical', 'course', 'training', 'conference', 'seminar', 'workshop', 'other']),
        openapi.Parameter('project', openapi.IN_FORM, description="Project ID", type=openapi.TYPE_INTEGER, required=True),
        openapi.Parameter('date', openapi.IN_FORM, description="Date of expense", type=openapi.TYPE_STRING, format='date', required=True),
        openapi.Parameter('amount', openapi.IN_FORM, description="Amount to be reimbursed", type=openapi.TYPE_NUMBER, required=True),
        openapi.Parameter('description', openapi.IN_FORM, description="Description of expense", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('bill_receipt', openapi.IN_FORM, description="Bill/receipt", type=openapi.TYPE_FILE, required=True),
        openapi.Parameter('payment_receipt', openapi.IN_FORM, description="Payment receipt (if already paid)", type=openapi.TYPE_FILE, required=False),
    ],
    responses={
        201: openapi.Response(
            description="Reimbursement request created successfully",
            schema=ReimbursementSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_reimbursement_request(request):
    """Create a new reimbursement request"""
    email = request.user.email_id
    if not email:
        return ApiResponse.error(
            message="email is required",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    employee = get_object_or_404(Employee, email=email)
    
    # Check if user is creating request for themselves
    if not request.user.employee_profile.is_hr_manager and request.user.employee_profile != employee:
        return ApiResponse.error(
            message="You can only create requests for yourself",
            status_code=status.HTTP_403_FORBIDDEN
        )
    
    serializer = ReimbursementSerializer(data=request.data)
    print(request.data)
    
    # Validate that bill_receipt file is provided
    if 'bill_receipt' not in request.FILES:
        return ApiResponse.error(
            message="Bill receipt file is required",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if serializer.is_valid():
        # Save the reimbursement request first to get the ID
        reimbursement_request = serializer.save(employee=employee)
        reimbursement_request.reimbursement_id = f"RB-{employee.employee_id[-5:]}-{timezone.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        reimbursement_request.save()
        
        # Now upload the documents using the saved request
        uploader = S3DocumentUploader()
        
        # Upload bill receipt
        if 'bill_receipt' in request.FILES:
            success, bill_result = uploader.upload_document(
                email_id=email,
                document_type=reimbursement_request.reimbursement_id,
                file=request.FILES['bill_receipt'],
                document_collection="reimbursements",
                other_prefix=serializer.validated_data['category'],
            )
            if not success:
                reimbursement_request.delete()  # Clean up if upload fails
                return ApiResponse.error(
                    message=f"Bill receipt upload failed: {bill_result}",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            reimbursement_request.bill_receipt_url = bill_result
        
        # Upload payment receipt if provided
        if 'payment_receipt' in request.FILES:
            success, payment_result = uploader.upload_document(
                email_id=email,
                document_type=reimbursement_request.reimbursement_id,
                file=request.FILES['payment_receipt'],
                document_collection="reimbursements",
                other_prefix=serializer.validated_data['category'],
            )
            if not success:
                reimbursement_request.delete()  # Clean up if upload fails
                return ApiResponse.error(
                    message=f"Payment receipt upload failed: {payment_result}",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            reimbursement_request.payment_receipt_url = payment_result
        
        # Save the updated request with URLs
        reimbursement_request.save()

        # Send email notification
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        recipients = [request.user.email_id] + [hr_manager.email for hr_manager in hr_managers]
        logger.info(f"Attempting to send reimbursement request email to recipients: {recipients}")
        
        threading.Thread(target=EmailService.send_reimbursement_request_email, args=(reimbursement_request, recipients)).start()
        # email_sent, email_error = EmailService.send_reimbursement_request_email(
        #     reimbursement_request=reimbursement_request,
        #     recipients=recipients
        # )
        
        # if not email_sent:
        #     logger.error(f"Failed to send reimbursement request notification email: {email_error}")
        # else:
        #     logger.info("Reimbursement request notification email sent successfully")
        
        try:
            notification_service = NotificationService()
            # Prepare notification data
            notification_title = f"Reimbursement Request: {employee.full_name}"
            notification_body = f"{employee.full_name} has requested to be reimbursed for {reimbursement_request.amount} - {reimbursement_request.description}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'reimbursement_request',
                'reimbursement_request_id': str(reimbursement_request.id),
                'title': reimbursement_request.status,
                'created_by': reimbursement_request.employee.email,
                'scheduled_time': reimbursement_request.date.isoformat() if reimbursement_request.date else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for reimbursement request {reimbursement_request.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for reimbursement request {reimbursement_request.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for reimbursement request {reimbursement_request.id}: {str(e)}")
      
        
        
        return ApiResponse.created(
            data=serializer.data,
            message="Reimbursement request created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='patch',
    operation_description="Update reimbursement request status (HR manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Reimbursement request status updated successfully",
            schema=ReimbursementSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Reimbursement request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_reimbursement_status(request, request_id):
    """Update reimbursement request status (HR manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
        
    try:
        reimbursement_request = Reimbursement.objects.get(id=request_id)
    except Reimbursement.DoesNotExist:
        return ApiResponse.not_found("Reimbursement request not found")
        
    new_status = request.data.get('status')
    if new_status not in dict(Reimbursement.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if reimbursement_request.status == new_status:
        return ApiResponse.error(
            message=f"Reimbursement request is already in {new_status} state",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    reimbursement_request.status = new_status
    reimbursement_request.approved_at = timezone.now()
    reimbursement_request.approved_by = request.user.employee_profile
    reimbursement_request.comments = request.data.get('comments', '')
    reimbursement_request.save()
    
    # Send email notification
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [reimbursement_request.employee.email] + [hr_manager.email for hr_manager in hr_managers]
    logger.info(f"Attempting to send reimbursement status update email to recipients: {recipients}")
    
    threading.Thread(target=EmailService.send_reimbursement_status_update_email, args=(reimbursement_request, new_status, recipients, reimbursement_request.comments)).start()
    
    # if not email_sent:
    #     logger.error(f"Failed to send reimbursement status update email: {email_error}")
    # else:
    #     logger.info("Reimbursement status update email sent successfully")
    
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Reimbursement Request Status: {new_status.capitalize()}"
        notification_body = f"Your reimbursement request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'reimbursement_request',
            'reimbursement_request_id': str(reimbursement_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=reimbursement_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for reimbursement request {reimbursement_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for reimbursement request {reimbursement_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for reimbursement request {reimbursement_request.id}: {str(e)}")
    
    
    serializer = ReimbursementSerializer(reimbursement_request)
    return ApiResponse.success(
        data=serializer.data,
        message="Reimbursement request status updated successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of travel requests with pagination, search, and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('project', openapi.IN_QUERY, description="Filter by project ID", type=openapi.TYPE_INTEGER),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email ID", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, subject, travel location, mode of transport, status, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Travel requests retrieved successfully",
            schema=TravelRequestSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_travel_requests(request):
    """Get paginated list of travel requests with filtering options"""
    email_id = request.user.email_id
    employee = Employee.objects.filter(email=email_id).first()
    filter_email_id = request.GET.get('email_id')
    
    # If user is HR manager, return all requests
    if request.user.employee_profile.is_hr_manager:
        queryset = TravelRequest.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    else:
        # Otherwise, only return requests for the logged-in employee
        if request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only view your own requests",
                status_code=status.HTTP_403_FORBIDDEN
            )
        queryset = TravelRequest.objects.filter(employee=employee).order_by('-created_at')
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'TravelRequest')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
        
    project_id = request.GET.get('project')
    if project_id:
        queryset = queryset.filter(project_id=project_id)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    requests_page = paginator.get_page(page)
    
    serializer = TravelRequestSerializer(requests_page, many=True)
    return ApiResponse.success(
        data=serializer.data,
        message="Travel requests retrieved successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new travel request",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'subject': openapi.Schema(type=openapi.TYPE_STRING, description="Subject of travel"),
            'project': openapi.Schema(type=openapi.TYPE_INTEGER, description="Project ID"),
            'from_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Start date of travel"),
            'to_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="End date of travel"),
            'travel_location': openapi.Schema(type=openapi.TYPE_STRING, description="Travel location"),
            'mode_of_transport': openapi.Schema(type=openapi.TYPE_STRING, description="Mode of transport"),
            'estimated_expense': openapi.Schema(type=openapi.TYPE_NUMBER, description="Estimated expense"),
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Travel request created successfully",
            schema=TravelRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_travel_request(request):
    """Create a new travel request"""
    email = request.user.email_id
        
    employee = get_object_or_404(Employee, email=email)
    
    # Check if user is creating request for themselves
    # if not request.user.employee_profile.is_hr_manager and request.user.employee_profile != employee:
    #     return ApiResponse.error(
    #         message="You can only create requests for yourself",
    #         status_code=status.HTTP_403_FORBIDDEN
    #     )
    
    serializer = TravelRequestSerializer(data=request.data)
    if serializer.is_valid():
        travel_request = serializer.save(employee=employee)
        
        # Send email notification
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        recipients = [request.user.email_id] + [hr_manager.email for hr_manager in hr_managers]
        threading.Thread(target=EmailService.send_travel_request_email, args=(travel_request, recipients)).start()
        
        # success, error = EmailService.send_travel_request_email(travel_request, recipients)
        
        # if not success:
        #     logger.error(f"Failed to send travel request email: {error}")
        try:
            
            # Prepare notification data
            notification_title = f"Travel Request: {employee.full_name}"
            notification_body = f"{employee.full_name} has requested to travel to {travel_request.travel_location} for {travel_request.project.name}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'travel_request',
                'travel_request_id': str(travel_request.id),
                'title': travel_request.status,
                'created_by': travel_request.employee.email,
                'scheduled_time': travel_request.from_date.isoformat() if travel_request.from_date else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for travel request {travel_request.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for travel request {travel_request.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for travel request {travel_request.id}: {str(e)}")
      
        
        return ApiResponse.created(
            data=serializer.data,
            message="Travel request created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='patch',
    operation_description="Update travel request status (HR manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Travel request status updated successfully",
            schema=TravelRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Travel request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_travel_status(request, request_id):
    """Update travel request status (HR manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
    
    travel_request = get_object_or_404(TravelRequest, id=request_id)
    
    # Check if status is being changed
    new_status = request.data.get('status')
    if new_status not in dict(TravelRequest.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    if travel_request.status == new_status:
        return ApiResponse.error(
            message=f"Status is already set to {new_status} value",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    travel_request.status = new_status
    travel_request.approved_at = timezone.now()
    travel_request.approved_by = request.user.employee_profile
    travel_request.comments = request.data.get('comments', '')
    travel_request.save()
    
    # serializer = TravelRequestSerializer(travel_request, data=request.data, partial=True)
    # if serializer.is_valid():
        # travel_request = serializer.save(approved_by=request.user.employee_profile)
        
        # Send email notification
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [travel_request.employee.email] + [hr_manager.email for hr_manager in hr_managers]
    threading.Thread(target=EmailService.send_travel_status_update_email, args=(travel_request, new_status, recipients, request.data.get('comments'))).start()
        # success, error = EmailService.send_travel_status_update_email(
        #     travel_request,
        #     new_status,
        #     recipients,
        #     request.data.get('comments')
        # )
        
        # if not success:
        #     logger.error(f"Failed to send travel status update email: {error}")
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Travel Request Status: {new_status.capitalize()}"
        notification_body = f"Your travel request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'travel_request',
            'travel_request_id': str(travel_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=travel_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for travel request {travel_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for travel request {travel_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for travel request {travel_request.id}: {str(e)}")
    
    serializer = TravelRequestSerializer(travel_request)
    return ApiResponse.success(
        data=serializer.data,
        message=f"Travel request {new_status} successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of emergency fund requests with pagination, search, and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="email_id to filter requests", type=openapi.TYPE_STRING),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, reason, repayment plan, status, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Emergency fund requests retrieved successfully",
            schema=EmergencyFundRequestSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_emergency_fund_requests(request):
    """Get paginated list of emergency fund requests with filtering options"""
    email = request.user.email_id
    employee = get_object_or_404(Employee, email=email)
    filter_email_id = request.GET.get('email_id')
    # If user is HR manager, return all requests
    if request.user.employee_profile.is_hr_manager:
        queryset = EmergencyFundRequest.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    else:
        # Otherwise, only return requests for the logged-in employee
        if request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only view your own requests",
                status_code=status.HTTP_403_FORBIDDEN
            )
        queryset = EmergencyFundRequest.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'EmergencyFundRequest')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    requests_page = paginator.get_page(page)
    
    serializer = EmergencyFundRequestSerializer(requests_page, many=True)
    return ApiResponse.success(
        data=serializer.data,
        message="Emergency fund requests retrieved successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new emergency fund request",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['amount_requested', 'reason', 'repayment_plan', 'fund_repayment_date', 'fund_needed_date'],
        properties={
            'amount_requested': openapi.Schema(type=openapi.TYPE_NUMBER, description="Amount requested"),
            'reason': openapi.Schema(type=openapi.TYPE_STRING, description="Reason for emergency fund request"),
            'repayment_plan': openapi.Schema(type=openapi.TYPE_STRING, description="Plan for repaying the amount"),
            'fund_repayment_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Date of fund repayment"),
            'fund_needed_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Date of fund needed"),
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )],
    responses={
        201: openapi.Response(
            description="Emergency fund request created successfully",
            schema=EmergencyFundRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_emergency_fund_request(request):
    """Create a new emergency fund request"""
    email = request.user.email_id
    employee = get_object_or_404(Employee, email=email)
    
    # Check if user is creating request for themselves
    if not request.user.employee_profile.is_hr_manager and request.user.employee_profile != employee:
        return ApiResponse.error(
            message="You can only create requests for yourself",
            status_code=status.HTTP_403_FORBIDDEN
        )
    
    serializer = EmergencyFundRequestSerializer(data=request.data)
    if serializer.is_valid():
        emergency_fund_request = serializer.save(employee=employee)
        
        # Send email notification
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        recipients = [request.user.email_id] + [hr_manager.email for hr_manager in hr_managers]
        logger.info(f"Attempting to send emergency fund request email to recipients: {recipients}")
        
        threading.Thread(target=EmailService.send_emergency_fund_request_email, args=(emergency_fund_request, recipients)).start()
        # email_sent, email_error = EmailService.send_emergency_fund_request_email(
        #     emergency_fund_request=emergency_fund_request,
        #     recipients=recipients
        # )
        
        # if not email_sent:
        #     logger.error(f"Failed to send emergency fund request notification email: {email_error}")
        #     # Continue with the request creation even if email fails
        # else:
        #     logger.info("Emergency fund request notification email sent successfully")
        try:
            
            # Prepare notification data
            notification_title = f"Emergency Fund Request: {employee.full_name}"
            notification_body = f"{employee.full_name} has requested an emergency fund of {emergency_fund_request.amount_requested} - {emergency_fund_request.reason}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'emergency_fund_request',
                'emergency_fund_request_id': str(emergency_fund_request.id),
                'title': emergency_fund_request.status,
                'created_by': emergency_fund_request.employee.email,
                'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for emergency fund request {emergency_fund_request.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for emergency fund request {emergency_fund_request.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for emergency fund request {emergency_fund_request.id}: {str(e)}")
      
        
            
        return ApiResponse.created(
            data=serializer.data,
            message="Emergency fund request created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='patch',
    operation_description="Update emergency fund request status (HR manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Emergency fund request status updated successfully",
            schema=EmergencyFundRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Emergency fund request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_emergency_fund_status(request, request_id):
    """Update emergency fund request status (HR manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
        
    try:
        emergency_fund_request = EmergencyFundRequest.objects.get(id=request_id)
    except EmergencyFundRequest.DoesNotExist:
        return ApiResponse.not_found("Emergency fund request not found")
        
    new_status = request.data.get('status')
    if new_status not in dict(EmergencyFundRequest.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if emergency_fund_request.status == new_status:
        return ApiResponse.error(
            message=f"Emergency fund request is already in {new_status} state",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    emergency_fund_request.status = new_status
    emergency_fund_request.approved_at = timezone.now()
    emergency_fund_request.approved_by = request.user.employee_profile
    emergency_fund_request.comments = request.data.get('comments', '')
    emergency_fund_request.save()
    
    # Send email notification
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [emergency_fund_request.employee.email] + [hr_manager.email for hr_manager in hr_managers]
    threading.Thread(target=EmailService.send_emergency_fund_status_update_email, args=(emergency_fund_request, new_status, recipients, emergency_fund_request.comments)).start()
    # success, error = EmailService.send_emergency_fund_status_update_email(
    #     emergency_fund_request=emergency_fund_request,
    #     status=new_status,
    #     recipients=recipients,
    #     comments=emergency_fund_request.comments
    # )
    #
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Emergency Fund Request Status: {new_status.capitalize()}"
        notification_body = f"Your emergency fund request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'emergency_fund_request',
            'emergency_fund_request_id': str(emergency_fund_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=emergency_fund_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for emergency fund request {emergency_fund_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for emergency fund request {emergency_fund_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for emergency fund request {emergency_fund_request.id}: {str(e)}")
    
    
    serializer = EmergencyFundRequestSerializer(emergency_fund_request)
    return ApiResponse.success(
        data=serializer.data,
        message="Emergency fund request status updated successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of comp-off credit requests with pagination, search, and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="email_id to filter requests", type=openapi.TYPE_STRING),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('project', openapi.IN_QUERY, description="Filter by project ID", type=openapi.TYPE_INTEGER),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, reason, request type, status, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Comp-off credit requests retrieved successfully",
            schema=CompOffCreditRequestSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_compoff_requests(request):
    """Get paginated list of comp-off credit requests with filtering options"""

    email = request.user.email_id
    employee = get_object_or_404(Employee, email=email)
    filter_email_id = request.GET.get('email_id')
    # If user is HR manager, return all requests
    if request.user.employee_profile.is_hr_manager:
        queryset = CompOffCreditRequest.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    else:
        # Otherwise, only return requests for the logged-in employee
        if request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only view your own requests",
                status_code=status.HTTP_403_FORBIDDEN
            )
        queryset = CompOffCreditRequest.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'CompOffCreditRequest')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
        
    project_id = request.GET.get('project')
    if project_id:
        queryset = queryset.filter(project_id=project_id)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    requests_page = paginator.get_page(page)
    
    serializer = CompOffCreditRequestSerializer(requests_page, many=True)
    return ApiResponse.success(
        data=serializer.data,
        message="Comp-off credit requests retrieved successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new comp-off credit request",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['project', 'date', 'hours', 'reason'],
        properties={
            'project': openapi.Schema(type=openapi.TYPE_INTEGER, description="Project ID"),
            'request_type': openapi.Schema(type=openapi.TYPE_STRING, description="Type of comp-off", enum=['HD', 'FD']),
            'date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Date of work"),
            'reason': openapi.Schema(type=openapi.TYPE_STRING, description="Reason for comp-off credit"),
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Comp-off credit request created successfully",
            schema=CompOffCreditRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_compoff_request(request):
    """Create a new comp-off credit request"""
    email = request.user.email_id
    employee = get_object_or_404(Employee, email=email)
    
    serializer = CompOffCreditRequestSerializer(data=request.data)
    if serializer.is_valid():
        compoff_request = serializer.save(employee=employee)
        
        # Send email notification
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        recipients = [request.user.email_id] + [hr_manager.email for hr_manager in hr_managers]
        threading.Thread(target=EmailService.send_compoff_request_email, args=(compoff_request, recipients)).start()
        # email_sent, email_error = EmailService.send_compoff_request_email(
        #     compoff_request=compoff_request,
        #     recipients=recipients
        # )
        
        # if not email_sent:
        #     print(f"Failed to send comp-off request notification email: {email_error}")
        try:
            
            # Prepare notification data
            notification_title = f"Comp-off Credit Request: {employee.full_name}"
            notification_body = f"{employee.full_name} has requested a comp-off credit for {compoff_request.project.name}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'compoff_request',
                'compoff_request_id': str(compoff_request.id),
                'title': compoff_request.status,
                'created_by': compoff_request.employee.email,
                'scheduled_time': compoff_request.date.isoformat() if compoff_request.date else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for comp-off credit request {compoff_request.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for comp-off credit request {compoff_request.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for comp-off credit request {compoff_request.id}: {str(e)}")
      
        
        return ApiResponse.created(
            data=serializer.data,
            message="Comp-off credit request created successfully"
        )
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='patch',
    operation_description="Update comp-off credit request status (HR manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Comp-off credit request status updated successfully",
            schema=CompOffCreditRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Comp-off credit request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_compoff_status(request, request_id):
    """Update comp-off credit request status (HR manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
        
    try:
        compoff_request = CompOffCreditRequest.objects.get(id=request_id)
    except CompOffCreditRequest.DoesNotExist:
        return ApiResponse.not_found("Comp-off credit request not found")
        
    new_status = request.data.get('status')
    if new_status not in dict(CompOffCreditRequest.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if compoff_request.status == new_status:
        return ApiResponse.error(
            message=f"Comp-off credit request is already in {new_status} state",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
        
    compoff_request.status = new_status
    compoff_request.approved_at = timezone.now()
    compoff_request.approved_by = request.user.employee_profile
    compoff_request.comments = request.data.get('comments', '')
    compoff_request.save()
    
    if new_status == 'approved':
        leaves_alloted = compoff_request.employee.leaves_allotted
        leaves_alloted['CL'] = leaves_alloted['CL'] + 1
        employee = compoff_request.employee
        employee.leaves_allotted = leaves_alloted
        employee.save()
    
    # Send email notification
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [compoff_request.employee.email] + [hr_manager.email for hr_manager in hr_managers]
    threading.Thread(target=EmailService.send_compoff_status_update_email, args=(compoff_request, new_status, recipients, compoff_request.comments)).start()
    # success, error = EmailService.send_compoff_status_update_email(
    #     compoff_request=compoff_request,
    #     status=new_status,
    #     recipients=recipients,
    #     comments=compoff_request.comments
    # )
    # if not success:
    #     print(f"Failed to send comp-off status update email: {error}")
    
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Comp-off Credit Request Status: {new_status.capitalize()}"
        notification_body = f"Your comp-off credit request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'compoff_request',
            'compoff_request_id': str(compoff_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=compoff_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for comp-off credit request {compoff_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for comp-off credit request {compoff_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for comp-off credit request {compoff_request.id}: {str(e)}")
    
    
    serializer = CompOffCreditRequestSerializer(compoff_request)
    return ApiResponse.success(
        data=serializer.data,
        message="Comp-off credit request status updated successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new separation request with optional resignation letter upload.",
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('preferred_date', openapi.IN_FORM, description="Preferred separation date (YYYY-MM-DD)", type=openapi.TYPE_STRING, format='date', required=False),
        openapi.Parameter('reason', openapi.IN_FORM, description="Reason for separation", type=openapi.TYPE_STRING, required=True, enum=['personal_reasons', 'better_opportunities', 'family_reasons', 'health_issues', 'location_change', 'higher_studies', 'other']),
        openapi.Parameter('comments', openapi.IN_FORM, description="Additional comments", type=openapi.TYPE_STRING, required=False),
        openapi.Parameter('notice_period_compliance', openapi.IN_FORM, description="Notice period compliance", type=openapi.TYPE_BOOLEAN, required=False),
        openapi.Parameter('resignation_letter', openapi.IN_FORM, description="Resignation letter file", type=openapi.TYPE_FILE, required=False),
    ],
    responses={
        201: openapi.Response(description="Separation request created successfully", schema=SeparationCreateSerializer),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_separation_request(request):
    """Create a new separation request with optional resignation letter upload."""
    employee = request.user.employee_profile
    data = request.data.copy()
    data['employee'] = employee.id

    separation_exists = Separation.objects.filter(employee=employee, status="pending").exists()
    if separation_exists:
        return ApiResponse.error(message="Separation request already submitted", status_code=status.HTTP_400_BAD_REQUEST)
    
    # Handle resignation letter file upload
    resignation_letter = request.FILES.get('resignation_letter')
    if resignation_letter:
        # Here you would upload the file to S3 or your storage and get the URL
        # For now, let's assume a dummy URL
        uploader = S3DocumentUploader()
        success, file_url = uploader.upload_document(
            file=resignation_letter,
            email_id=employee.email,
            document_collection="separation_letters",
            document_type="resignation_letter",
        )
        if not success:
            return ApiResponse.error(message="Resignation letter upload failed", status_code=status.HTTP_400_BAD_REQUEST)
        data['resignation_letter_url'] = file_url

    serializer = SeparationCreateSerializer(data=data)
    if not serializer.is_valid():
        return ApiResponse.error(message=serializer.errors, status_code=status.HTTP_400_BAD_REQUEST)

    separation = serializer.save(employee=employee)

    # Send email notification to HR
    try:
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        for hr_manager in hr_managers:
            threading.Thread(target=EmailService.send_separation_notification, args=(hr_manager.email, employee.full_name, separation.reason, str(separation.preferred_date) if separation.preferred_date else 'Not specified', separation.comments, separation.resignation_letter_url)).start()
            # EmailService.send_separation_notification(
                # recipient_email=hr_manager.email,
                # employee_name=employee.full_name,
                # separation_reason=separation.reason,
                # preferred_date=str(separation.preferred_date) if separation.preferred_date else 'Not specified',
                # comments=separation.comments,
                # resignation_letter_url=separation.resignation_letter_url
            # )
        
        try:
            
            # Prepare notification data
            notification_title = f"Separation Request: {employee.full_name}"
            notification_body = f"{employee.full_name} has requested to be separated - {separation.reason}"
            
            # Additional data for the notification
            notification_data = {
                'type': 'separation_request',
                'separation_request_id': str(separation.id),
                'title': separation.status,
                'created_by': separation.employee.email,
                'scheduled_time': separation.preferred_date.isoformat() if separation.preferred_date else '',
            }
            
            # Send notification to all users
            recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=recipients
            )
            
            if success:
                logger.info(f"Notification sent successfully for separation request {separation.id}: {message}")
            else:
                logger.warning(f"Failed to send notification for separation request {separation.id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending notification for separation request {separation.id}: {str(e)}")
      
        
    except Exception as e:
        logger.error(f"Failed to send email notification for separation request: {e}")

    return ApiResponse.success(
        data=serializer.data, 
        message="Separation request created successfully", 
        status_code=status.HTTP_201_CREATED
    )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new complaint with optional multiple attachments.",
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('title', openapi.IN_FORM, description="Complaint title", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('date', openapi.IN_FORM, description="Complaint date (YYYY-MM-DD)", type=openapi.TYPE_STRING, format='date', required=False),
        openapi.Parameter('description', openapi.IN_FORM, description="Complaint description", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('attachments', openapi.IN_FORM, description="Attachment files (multiple allowed)", type=openapi.TYPE_FILE, required=False, multiple=True),
    ],
    responses={
        201: openapi.Response(description="Complaint created successfully", schema=ComplaintCreateSerializer),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_complaint(request):
    """Create a new complaint with optional multiple attachments."""
    employee = request.user.employee_profile
    data = request.data.copy()
    data['employee'] = employee.id

    serializer = ComplaintCreateSerializer(data=data)
    if not serializer.is_valid():
        return ApiResponse.error(message=serializer.errors, status_code=status.HTTP_400_BAD_REQUEST)

    complaint = serializer.save(employee=employee)

    # Handle attachments (optional, multiple)
    files = request.FILES.getlist('attachments')
    attachments = []
    uploader = S3DocumentUploader()
    
    for file in files:
        # Here you would upload the file to S3 or your storage and get the URL
        # For now, let's assume a dummy URL and save file info
        
        success, file_url = uploader.upload_document(
            email_id=employee.email,
            document_collection="complaints",
            other_prefix=f"{complaint.id}/{file.name}",
            document_type="",
            file=file
        )
        if not success:
            complaint.delete()  # Clean up if upload fails
            return ApiResponse.error(
                message=f"Attachment upload failed: {complaint.id}",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        attachment = ComplaintAttachment.objects.create(
            complaint=complaint,
            file_url=file_url,
            file_name=file.name,
            file_type=file.content_type,
            file_size=file.size
        )
        attachments.append(attachment)
        

    # Send email notification to employee and HR managers
    try:
        # Get all HR managers
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        
        # Create list of recipients: employee + all HR managers
        recipient_emails = [employee.email]  # Employee who created the complaint
        for hr_manager in hr_managers:
            recipient_emails.append(hr_manager.email)
        
        # Send single email to all recipients
        threading.Thread(target=EmailService.send_complaint_notification, args=(recipient_emails, employee.full_name, complaint.title, complaint.priority, complaint.description, len(attachments))).start()
        # EmailService.send_complaint_notification(
            # recipient_emails=recipient_emails,
            # employee_name=employee.full_name,
            # complaint_title=complaint.title,
            # priority=complaint.priority,
            # description=complaint.description,
            # attachment_count=len(attachments)
        # )
        
    except Exception as e:
        logger.error(f"Failed to send email notification for complaint: {e}")
    
    try:
            
        # Prepare notification data
        notification_title = f"Complaint: {employee.full_name}"
        notification_body = f"{employee.full_name} has raised a complaint - {complaint.title}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'complaint',
            'complaint_id': str(complaint.id),
            'title': complaint.title,
            'created_by': complaint.employee.email,
            'scheduled_time': complaint.date.isoformat() if complaint.date else '',
        }
        
        # Send notification to all users
        recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
        success, message = notification_service.send_notification_to_hr_managers(
            title=notification_title,
            body=notification_body,
            data=notification_data,
            recipients=recipients
        )
        
        if success:
            logger.info(f"Notification sent successfully for complaint {complaint.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for complaint {complaint.id}: {message}")
                
    except Exception as e:
        logger.error(f"Error sending notification for complaint {complaint.id}: {str(e)}")
      
        

    # Return the created complaint with attachments
    response_serializer = ComplaintCreateSerializer(complaint)
    return ApiResponse.success(data=response_serializer.data, message="Complaint created successfully", status_code=status.HTTP_201_CREATED)

@swagger_auto_schema(
    method='get',
    operation_description="Get list of complaints with pagination, search, and filtering. HR managers can view all complaints with optional email_id filtering.",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING, enum=['pending', 'in_progress', 'resolved', 'closed']),
        openapi.Parameter('priority', openapi.IN_QUERY, description="Filter by priority", type=openapi.TYPE_STRING, enum=['low', 'medium', 'high', 'urgent']),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email (HR managers only)", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, title, description, status, priority, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Complaints retrieved successfully",
            schema=ComplaintListSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied"),
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_complaints(request):
    """Get paginated list of complaints with filtering options"""
    email_id = request.user.email_id
    employee = Employee.objects.filter(email=email_id).first()
    filter_email_id = request.GET.get('email_id')
    
    
    if not employee:
        return ApiResponse.error(
            message="Employee not found",
            status_code=status.HTTP_404_NOT_FOUND
        )
    
    # If user is HR manager, return all complaints with optional email_id filtering
    if request.user.employee_profile.is_hr_manager:
        queryset = Complaint.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
        # Apply email_id filter if provided (HR managers only)
        filter_email = request.GET.get('email_id')
        if filter_email:
            queryset = queryset.filter(employee__email=filter_email)
    else:
        # Otherwise, only return complaints for the logged-in employee
        queryset = Complaint.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'Complaint')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    # Apply priority filter
    priority_filter = request.GET.get('priority')
    if priority_filter:
        queryset = queryset.filter(priority=priority_filter)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    
    try:
        complaints_page = paginator.page(page)
    except:
        return ApiResponse.error(
            message="Invalid page number",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    serializer = ComplaintListSerializer(complaints_page, many=True)
    return ApiResponse.success(
        data=serializer.data,
        message="Complaints retrieved successfully"
    )

@swagger_auto_schema(
    method='patch',
    operation_description="Update complaint status (HR managers only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'in_progress', 'resolved', 'closed']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
    ],
    responses={
        200: openapi.Response(description="Complaint status updated successfully", schema=ComplaintListSerializer),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update complaint status"),
        404: openapi.Response(description="Complaint not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_complaint_status(request, complaint_id):
    """Update complaint status (HR managers only)"""
    # Check if user is HR manager
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update complaint status",
            status_code=status.HTTP_403_FORBIDDEN
        )
    
    # Get the complaint
    try:
        complaint = Complaint.objects.get(id=complaint_id)
    except Complaint.DoesNotExist:
        return ApiResponse.error(
            message="Complaint not found",
            status_code=status.HTTP_404_NOT_FOUND
        )
    
    # Get new status and comments
    new_status = request.data.get('status')
    comments = request.data.get('comments')
    
    if not new_status:
        return ApiResponse.error(
            message="Status is required",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Validate status
    if new_status not in [status[0] for status in Complaint.STATUS_CHOICES]:
        return ApiResponse.error(
            message=f"Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Update the complaint
    old_status = complaint.status
    complaint.status = new_status
    complaint.save()
    
    # Send email notification to employee
    threading.Thread(target=EmailService.send_complaint_status_update, args=(complaint.employee.email, complaint.employee.full_name, complaint.title, new_status, comments)).start()

    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Complaint Status: {new_status.capitalize()}"
        notification_body = f"Your complaint has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'complaint',
            'complaint_id': str(complaint.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=complaint.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for complaint {complaint.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for complaint {complaint.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for complaint {complaint.id}: {str(e)}")
    
    
    # Return updated complaint
    serializer = ComplaintListSerializer(complaint)
    return ApiResponse.success(
        data=serializer.data,
        message=f"Complaint status updated from {old_status} to {new_status}"
    )

# ==================== DEVICES PERIPHERALS CRUD ====================

@swagger_auto_schema(
    method='get',
    operation_description="Get list of device/peripheral requests with pagination, search, and filtering. HR managers can view all requests with optional email_id filtering.",
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING, enum=['pending', 'approved', 'rejected']),
        openapi.Parameter('urgency', openapi.IN_QUERY, description="Filter by urgency", type=openapi.TYPE_STRING, enum=['low', 'medium', 'high']),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email (HR managers only)", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, requested item, purpose, urgency, status, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(description="Device requests retrieved successfully", schema=DevicesPeripheralsListSerializer(many=True)),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_devices_peripherals_requests(request):
    """Get paginated list of device/peripheral requests with filtering options"""
    email_id = request.user.email_id
    employee = Employee.objects.filter(email=email_id).first()
    filter_email_id = request.GET.get('email_id')
    
    if not employee:
        return ApiResponse.error(message="Employee not found", status_code=status.HTTP_404_NOT_FOUND)
    
    # If user is HR manager, return all requests with optional email_id filtering
    if request.user.employee_profile.is_hr_manager:
        queryset = DevicesPeripherals.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    else:
        # Otherwise, only return requests for the logged-in employee
        queryset = DevicesPeripherals.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'DevicesPeripherals')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    urgency_filter = request.GET.get('urgency')
    if urgency_filter:
        queryset = queryset.filter(urgency=urgency_filter)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    
    try:
        requests_page = paginator.page(page)
    except:
        return ApiResponse.error(message="Invalid page number", status_code=status.HTTP_400_BAD_REQUEST)
    
    serializer = DevicesPeripheralsListSerializer(requests_page, many=True)
    return ApiResponse.success(data=serializer.data, message="Device requests retrieved successfully")


@swagger_auto_schema(
    method='post',
    operation_description="Create a new device/peripheral request.",
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('requested_item', openapi.IN_FORM, description="Requested item", type=openapi.TYPE_STRING, required=True, enum=['laptop', 'desktop', 'monitor', 'keyboard', 'mouse', 'printer', 'docking_station', 'headset', 'webcam', 'microphone', 'speaker', 'pipettes', 'gloves', 'microscope', 'microscope_accessories', 'centrifuge', 'centrifuge_accessories', 'other']),
        openapi.Parameter('purpose', openapi.IN_FORM, description="Purpose of request", type=openapi.TYPE_STRING, required=False),
        openapi.Parameter('preferred_brand', openapi.IN_FORM, description="Preferred brand", type=openapi.TYPE_STRING, required=False),
        openapi.Parameter('preferred_quantity', openapi.IN_FORM, description="Preferred quantity", type=openapi.TYPE_INTEGER, required=False),
        openapi.Parameter('urgency', openapi.IN_FORM, description="Urgency level", type=openapi.TYPE_STRING, required=True, enum=['low', 'medium', 'high']),
        openapi.Parameter('comments', openapi.IN_FORM, description="Additional comments", type=openapi.TYPE_STRING, required=False),
        openapi.Parameter('delivery_location', openapi.IN_FORM, description="Delivery location ID", type=openapi.TYPE_INTEGER, required=False),
    ],
    responses={
        201: openapi.Response(description="Device request created successfully", schema=DevicesPeripheralsCreateSerializer),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_devices_peripherals_request(request):
    """Create a new device/peripheral request."""
    employee = request.user.employee_profile
    data = request.data.copy()
    data['employee'] = employee.id

    serializer = DevicesPeripheralsCreateSerializer(data=data)
    if not serializer.is_valid():
        return ApiResponse.error(message=serializer.errors, status_code=status.HTTP_400_BAD_REQUEST)

    device_request = serializer.save(employee=employee)

    # Send email notification to HR
    try:
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        hr_manager_emails = [hr_manager.email for hr_manager in hr_managers]
        hr_manager_emails.append(employee.email)
        threading.Thread(target=EmailService.send_device_request_notification, args=(hr_manager_emails, employee.full_name, device_request.requested_item, device_request.urgency, device_request.purpose, device_request.comments)).start()
        # EmailService.send_device_request_notification(
        #         recipient_emails=hr_manager_emails,
        #         employee_name=employee.full_name,
        #         requested_item=device_request.requested_item,
        #         urgency=device_request.urgency,
        #         purpose=device_request.purpose,
        #         comments=device_request.comments
        #     )
    except Exception as e:
        logger.error(f"Failed to send email notification for device request: {e}")
    
    try:
        
        # Prepare notification data
        notification_title = f"Device Request: {employee.full_name}"
        notification_body = f"{employee.full_name} has requested a {device_request.requested_item} - {device_request.purpose}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'device_request',
            'device_request_id': str(device_request.id),
            'title': device_request.requested_item,
            'created_by': device_request.employee.email,
            'scheduled_time': device_request.created_at.isoformat() if device_request.created_at else '',
        }
        
        # Send notification to all users
        recipients = [recipient for recipient in recipients if recipient != request.user.email_id]
        success, message = notification_service.send_notification_to_hr_managers(
            title=notification_title,
            body=notification_body,
            data=notification_data,
            recipients=recipients
        )
        
        if success:
            logger.info(f"Notification sent successfully for device request {device_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for device request {device_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for device request {device_request.id}: {str(e)}")
      
        

    return ApiResponse.success(
        data=serializer.data, 
        message="Device request created successfully", 
        status_code=status.HTTP_201_CREATED
    )


@swagger_auto_schema(
    method='patch',
    operation_description="Update device/peripheral request status (HR managers only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
    ],
    responses={
        200: openapi.Response(description="Device request status updated successfully", schema=DevicesPeripheralsListSerializer),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Device request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_devices_peripherals_status(request, request_id):
    """Update device/peripheral request status (HR managers only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )

    try:
        device_request = DevicesPeripherals.objects.get(id=request_id)
    except DevicesPeripherals.DoesNotExist:
        return ApiResponse.error(
            message="Device request not found",
            status_code=status.HTTP_404_NOT_FOUND
        )

    new_status = request.data.get('status')
    comments = request.data.get('comments', '')

    if new_status not in ['pending', 'approved', 'rejected']:
        return ApiResponse.error(
            message="Invalid status. Must be one of: pending, approved, rejected",
            status_code=status.HTTP_400_BAD_REQUEST
        )

    device_request.status = new_status
    device_request.comments = comments
    device_request.approved_at = timezone.now()
    device_request.approved_by = request.user.employee_profile
    device_request.save()

    # Send email notification to employee
    threading.Thread(target=EmailService.send_device_request_status_update, args=(device_request.employee.email, device_request.employee.full_name, device_request.requested_item, new_status, comments)).start()

    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Device Request Status: {new_status.capitalize()}"
        notification_body = f"Your device request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'device_request',
            'device_request_id': str(device_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=device_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for device request {device_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for device request {device_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for device request {device_request.id}: {str(e)}")
    
    serializer = DevicesPeripheralsListSerializer(device_request)
    return ApiResponse.success(
        data=serializer.data,
        message="Device request status updated successfully"
    )


# ==================== SEPARATION CRUD ====================

@swagger_auto_schema(
    method='get',
    operation_description="Get list of separation requests with pagination, search, and filtering. HR managers can view all requests with optional email_id filtering.",
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING, enum=['pending', 'approved', 'rejected']),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email (HR managers only)", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in employee name, reason, comments, status, approved by, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(description="Separation requests retrieved successfully", schema=SeparationListSerializer(many=True)),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_separation_requests(request):
    """Get paginated list of separation requests with filtering options"""
    email_id = request.user.email_id
    employee = Employee.objects.filter(email=email_id).first()
    filter_email_id = request.GET.get('email_id')
    
    if not employee:
        return ApiResponse.error(message="Employee not found", status_code=status.HTTP_404_NOT_FOUND)
    
    # If user is HR manager, return all requests with optional email_id filtering
    if request.user.employee_profile.is_hr_manager:
        queryset = Separation.objects.all().order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
        # Apply email_id filter if provided (HR managers only)
    else:
        # Otherwise, only return requests for the logged-in employee
        queryset = Separation.objects.filter(employee=employee).order_by('-created_at')
        if filter_email_id:
            queryset = queryset.filter(employee__email=filter_email_id)
    
    # Apply search and filters
    queryset = apply_search_and_filters(queryset, request, 'Separation')
    
    # Apply additional filters
    status_filter = request.GET.get('status')
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    # Pagination
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    paginator = Paginator(queryset, page_size)
    
    try:
        requests_page = paginator.page(page)
    except:
        return ApiResponse.error(message="Invalid page number", status_code=status.HTTP_400_BAD_REQUEST)
    
    serializer = SeparationListSerializer(requests_page, many=True)
    return ApiResponse.success(data=serializer.data, message="Separation requests retrieved successfully")


@swagger_auto_schema(
    method='patch',
    operation_description="Update separation request status (HR managers only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="New status", enum=['pending', 'approved', 'rejected']),
            'comments': openapi.Schema(type=openapi.TYPE_STRING, description="Comments for the status update")
        }
    ),
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token", type=openapi.TYPE_STRING, required=True),
    ],
    responses={
        200: openapi.Response(description="Separation request status updated successfully", schema=SeparationListSerializer),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update request status"),
        404: openapi.Response(description="Separation request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_separation_status(request, request_id):
    """Update separation request status (HR managers only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )

    try:
        separation_request = Separation.objects.get(id=request_id)
    except Separation.DoesNotExist:
        return ApiResponse.error(
            message="Separation request not found",
            status_code=status.HTTP_404_NOT_FOUND
        )

    new_status = request.data.get('status')
    comments = request.data.get('comments', '')

    if new_status not in ['pending', 'approved', 'rejected']:
        return ApiResponse.error(
            message="Invalid status. Must be one of: pending, approved, rejected",
            status_code=status.HTTP_400_BAD_REQUEST
        )

    separation_request.status = new_status
    separation_request.comments = comments
    separation_request.approved_at = timezone.now()
    separation_request.approved_by = request.user.employee_profile
    separation_request.save()

    # Send email notification to employee
    
    threading.Thread(target=EmailService.send_separation_status_update, args=(separation_request.employee.email, separation_request.employee.full_name, separation_request.reason, new_status, comments, separation_request.resignation_letter_url)).start()

    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"Separation Request Status: {new_status.capitalize()}"
        notification_body = f"Your separation request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'separation_request',
            'separation_request_id': str(separation_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to all users
        success, message = notification_service.send_notification_to_user(
            user_email=separation_request.employee.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for separation request {separation_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for separation request {separation_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for separation request {separation_request.id}: {str(e)}")
    
    serializer = SeparationListSerializer(separation_request)
    return ApiResponse.success(
        data=serializer.data,
        message="Separation request status updated successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Send reminder to HR managers for a pending request",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['request_type', 'request_id'],
        properties={
            'request_type': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Type of request",
                enum=['leave', 'wfh', 'reimbursement', 'travel', 'emergency_fund', 'compoff', 'separation', 'devices_peripherals', 'complaint', 'ip_patent']
            ),
            'request_id': openapi.Schema(
                type=openapi.TYPE_INTEGER,
                description="ID of the request"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Reminder sent successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Reminder sent successfully to HR managers",
                    "success": True,
                    "data": {
                        "request_type": "leave",
                        "request_id": 123,
                        "employee_name": "John Doe",
                        "status": "pending",
                        "reminder_sent_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Invalid request type or ID"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can send reminders"),
        404: openapi.Response(description="Request not found or not pending")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def send_request_reminder(request):
    """
    Send reminder to HR managers for a pending request
    """
    # Check if user is HR manager
    # if not request.user.employee_profile.is_hr_manager:
    #     return ApiResponse.error(
    #         message="Only HR managers can send reminders",
    #         status_code=status.HTTP_403_FORBIDDEN
    #     )
    
    request_type = request.data.get('request_type')
    request_id = request.data.get('request_id')
    
    if not request_type or not request_id:
        return ApiResponse.error(
            message="Both request_type and request_id are required",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Validate request type
    valid_request_types = {
        'leave': Leave,
        'wfh': WFH,
        'reimbursement': Reimbursement,
        'travel': TravelRequest,
        'emergency_fund': EmergencyFundRequest,
        'compoff': CompOffCreditRequest,
        'separation': Separation,
        'devices_peripherals': DevicesPeripherals,
        'complaint': Complaint,
        'ip_patent': IPPatentSupportRequest
    }
    
    if request_type not in valid_request_types:
        return ApiResponse.error(
            message=f"Invalid request type. Must be one of: {', '.join(valid_request_types.keys())}",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Get the request model
    RequestModel = valid_request_types[request_type]
    
    try:
        # Get the request object
        request_obj = RequestModel.objects.get(id=request_id)
        
        # Check if request is pending
        if request_obj.status != 'pending':
            return ApiResponse.error(
                message=f"Request is not pending. Current status: {request_obj.status}",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Get HR managers
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        hr_emails = [hr_manager.email for hr_manager in hr_managers]
        
        if not hr_emails:
            return ApiResponse.error(
                message="No HR managers found",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Send email reminder
        try:
            if request_type == 'leave':
                threading.Thread(target=EmailService.send_leave_request_email, args=(request_obj, hr_emails)).start()
            elif request_type == 'wfh':
                threading.Thread(target=EmailService.send_wfh_request_email, args=(request_obj, hr_emails)).start()
            elif request_type == 'reimbursement':
                threading.Thread(target=EmailService.send_reimbursement_request_email, args=(request_obj, hr_emails)).start()
            elif request_type == 'travel':
                threading.Thread(target=EmailService.send_travel_request_email, args=(request_obj, hr_emails)).start()
            elif request_type == 'emergency_fund':
                threading.Thread(target=EmailService.send_emergency_fund_request_email, args=(request_obj, hr_emails)).start()
            elif request_type == 'compoff':
                threading.Thread(target=EmailService.send_compoff_request_email, args=(request_obj, hr_emails)).start()
            elif request_type == 'separation':
                for hr_email in hr_emails:
                    threading.Thread(target=EmailService.send_separation_notification, args=(
                        hr_email, 
                        request_obj.employee.full_name, 
                        request_obj.reason, 
                        str(request_obj.preferred_date) if request_obj.preferred_date else 'Not specified',
                        request_obj.comments,
                        request_obj.resignation_letter_url
                    )).start()
            elif request_type == 'devices_peripherals':
                threading.Thread(target=EmailService.send_device_request_notification, args=(
                    hr_emails,
                    request_obj.employee.full_name,
                    request_obj.requested_item,
                    request_obj.urgency,
                    request_obj.purpose,
                    request_obj.comments
                )).start()
            elif request_type == 'complaint':
                threading.Thread(target=EmailService.send_complaint_notification, args=(
                    hr_emails,
                    request_obj.employee.full_name,
                    request_obj.title,
                    request_obj.priority,
                    request_obj.description,
                    request_obj.attachments.count() if hasattr(request_obj, 'attachments') else 0
                )).start()
            elif request_type == 'ip_patent':
                threading.Thread(target=EmailService.send_ip_patent_request_notification, args=(
                    hr_emails,
                    request_obj.created_by.full_name,
                    request_obj.project_name,
                    request_obj.get_protection_type_display(),
                    request_obj.description,
                    request_obj.priority_date
                )).start()
            
            logger.info(f"Reminder email sent for {request_type} request {request_id}")
            
        except Exception as e:
            logger.error(f"Failed to send reminder email for {request_type} request {request_id}: {str(e)}")
            return ApiResponse.error(
                message=f"Failed to send reminder email: {str(e)}",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Send push notification
        try:
            notification_service = NotificationService()
            
            # Prepare notification data
            notification_title = f"Reminder: Pending {request_type.replace('_', ' ').title()} Request"
            
            # Handle different field names for different request types
            if request_type == 'ip_patent':
                employee_name = request_obj.created_by.full_name
                employee_email = request_obj.created_by.email
            else:
                employee_name = request_obj.employee.full_name
                employee_email = request_obj.employee.email
            
            notification_body = f"Reminder: {employee_name} has a pending {request_type.replace('_', ' ')} request that needs attention"
            
            # Additional data for the notification
            notification_data = {
                'type': f'{request_type}_reminder',
                'request_id': str(request_obj.id),
                'request_type': request_type,
                'employee_email': employee_email,
                'employee_name': employee_name,
                'reminder_sent_at': timezone.now().isoformat(),
            }
            
            # Send notification to HR managers
            success, message = notification_service.send_notification_to_hr_managers(
                title=notification_title,
                body=notification_body,
                data=notification_data,
                recipients=hr_emails
            )
            
            if success:
                logger.info(f"Reminder notification sent successfully for {request_type} request {request_id}: {message}")
            else:
                logger.warning(f"Failed to send reminder notification for {request_type} request {request_id}: {message}")
                
        except Exception as e:
            logger.error(f"Error sending reminder notification for {request_type} request {request_id}: {str(e)}")
        
        # Return success response
        return ApiResponse.success(
            message="Reminder sent successfully to HR managers",
            data={
                "request_type": request_type,
                "request_id": request_id,
                "employee_name": employee_name,
                "status": request_obj.status,
                "reminder_sent_at": timezone.now().isoformat()
            }
        )
        
    except RequestModel.DoesNotExist:
        return ApiResponse.error(
            message=f"{request_type.replace('_', ' ').title()} request with ID {request_id} not found",
            status_code=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        logger.error(f"Error sending reminder for {request_type} request {request_id}: {str(e)}")
        return ApiResponse.error(
            message=f"Failed to send reminder: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='post',
    operation_description="Create a new IP & Patent Support Request",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'project_name',
            openapi.IN_FORM,
            description="Name of the project",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'description',
            openapi.IN_FORM,
            description="Detailed description of the IP/Patent support needed",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'protection_type',
            openapi.IN_FORM,
            description="Type of IP protection required",
            type=openapi.TYPE_STRING,
            required=True,
            enum=['patent', 'copyright', 'trademark', 'trade_secret', 'design', 'other']
        ),
        openapi.Parameter(
            'team_member_emails',
            openapi.IN_FORM,
            description="List of team member email addresses (comma-separated)",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'attachments',
            openapi.IN_FORM,
            description="Supporting documents/files (multiple files can be uploaded)",
            type=openapi.TYPE_FILE,
            required=False,
            multiple=True
        ),
        openapi.Parameter(
            'priority_date',
            openapi.IN_FORM,
            description="Priority date for the request (YYYY-MM-DD)",
            type=openapi.TYPE_STRING,
            format='date',
            required=False
        )
    ],
    responses={
        201: openapi.Response(
            description="IP & Patent Support Request created successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "IP & Patent Support Request created successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "project_name": "AI Patent Application",
                        "description": "Patent application for AI algorithm",
                        "protection_type": "patent",
                        "team_member_emails": ["john.doe@example.com", "jane.smith@example.com"],
                        "attachments": [
                            {
                                "id": 1,
                                "file_url": "https://example.com/file1.pdf",
                                "file_name": "document1.pdf",
                                "file_type": "application/pdf",
                                "file_size": 1024000,
                                "created_at": "2024-01-15T10:30:00Z"
                            }
                        ],
                        "priority_date": "2024-01-15",
                        "status": "pending"
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def create_ip_patent_request(request):
    """Create a new IP & Patent Support Request"""
    try:
        employee = get_object_or_404(Employee, email=request.user.email_id)

        if not request.user.employee_profile.is_hr_manager and request.user.employee_profile != employee:
            return ApiResponse.error(
                message="You can only create requests for yourself",
                status_code=status.HTTP_403_FORBIDDEN
            )

        # Keep the original comma-separated string for the serializer
        data = request.data.copy()
        team_member_emails = data.get('team_member_emails', '')
        
        print(f"Original team_member_emails: '{team_member_emails}'")
        
        # Debug: Check if employees exist (for debugging only)
        if team_member_emails:
            email_list = [email.strip() for email in team_member_emails.split(',') if email.strip()]
            for i, email in enumerate(email_list):
                try:
                    employee = Employee.objects.get(email=email)
                    print(f"Employee found: {email} -> {employee.full_name}")
                except Employee.DoesNotExist:
                    print(f"Employee NOT found: {email}")
                except Exception as e:
                    print(f"Error checking employee {email}: {e}")
        serializer = IPPatentSupportRequestCreateSerializer(data=data, context={'request': request})
        if serializer.is_valid():
            ip_patent_request = serializer.save()
            
            # Handle attachments (optional, multiple)
            files = request.FILES.getlist('attachments')
            attachments = []
            uploader = S3DocumentUploader()
            
            for file in files:
                # Upload the file to S3 and get the URL
                success, file_url = uploader.upload_document(
                    email_id=employee.email,
                    document_collection="ip_patent_support",
                    other_prefix=f"{ip_patent_request.id}/{file.name}",
                    document_type="",
                    file=file
                )
                if not success:
                    ip_patent_request.delete()  # Clean up if upload fails
                    return ApiResponse.error(
                        message=f"Attachment upload failed: {file.name}",
                        status_code=status.HTTP_400_BAD_REQUEST
                    )
                attachment = IPPatentSupportAttachment.objects.create(
                    ip_patent_request=ip_patent_request,
                    file_url=file_url,
                    file_name=file.name,
                    file_type=file.content_type,
                    file_size=file.size
                )
                attachments.append(attachment)
            
            # Send email notification to HR managers
            hr_managers = Employee.objects.filter(is_hr_manager=True)
            if hr_managers.exists():
                hr_emails = [hr_manager.email for hr_manager in hr_managers]
                
                # Send email notification
                threading.Thread(target=EmailService.send_ip_patent_request_notification, args=(
                    hr_emails,
                    employee.full_name,
                    ip_patent_request.project_name,
                    ip_patent_request.get_protection_type_display(),
                    ip_patent_request.description,
                    str(ip_patent_request.priority_date) if ip_patent_request.priority_date else None
                )).start()
                
                try:
                    # Prepare notification data
                    notification_title = f"IP & Patent Support Request: {employee.full_name}"
                    notification_body = f"{employee.full_name} has submitted an IP & Patent Support Request for {ip_patent_request.project_name}"
                    
                    # Additional data for the notification
                    notification_data = {
                        'type': 'ip_patent_request',
                        'ip_patent_request_id': str(ip_patent_request.id),
                        'title': ip_patent_request.status,
                        'created_by': ip_patent_request.created_by.email,
                        'scheduled_time': ip_patent_request.priority_date.isoformat() if ip_patent_request.priority_date else '',
                    }
                    
                    # Send notification to HR managers
                    success, message = notification_service.send_notification_to_hr_managers(
                        title=notification_title,
                        body=notification_body,
                        data=notification_data,
                        recipients=hr_emails
                    )
                    
                    if success:
                        logger.info(f"Notification sent successfully for IP patent request {ip_patent_request.id}: {message}")
                    else:
                        logger.warning(f"Failed to send notification for IP patent request {ip_patent_request.id}: {message}")
                        
                except Exception as e:
                    logger.error(f"Error sending notification for IP patent request {ip_patent_request.id}: {str(e)}")

            return ApiResponse.created(
                data=serializer.data,
                message="IP & Patent Support Request created successfully"
            )           
        else:
            print(f"Serializer errors: {serializer.errors}")
            return ApiResponse.error(
                message="Validation error",
                status_code=status.HTTP_400_BAD_REQUEST,
                errors=serializer.errors
            )
    except Exception as e:
        return ApiResponse.error(
            message=f"Error creating IP & Patent Support Request: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get list of IP & Patent Support Requests with pagination, search, and filtering. HR managers can view all requests with optional email_id filtering.",
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token for authentication", type=openapi.TYPE_STRING, required=True),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email (HR managers only)", type=openapi.TYPE_STRING),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number for pagination", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Number of items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search in project name, description, status, protection type, or comments", type=openapi.TYPE_STRING),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year (YYYY)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('protection_type', openapi.IN_QUERY, description="Filter by protection type", type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response(
            description="List of IP & Patent Support Requests with attachments",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "IP & Patent Support Requests retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 1,
                        "next": None,
                        "previous": None,
                        "results": [
                            {
                                "id": 1,
                                "project_name": "AI Patent Application",
                                "description": "Patent application for AI algorithm",
                                "protection_type": "patent",
                                "protection_type_display": "Patent",
                                "status": "pending",
                                "status_display": "Pending",
                                "priority_date": "2024-01-15",
                                "created_by_name": "John Doe",
                                "created_by_email": "john.doe@example.com",
                                "team_members_count": 2,
                                "attachment_count": 3,
                                "attachments": [
                                    {
                                        "id": 1,
                                        "file_url": "https://example.com/file1.pdf",
                                        "file_name": "document1.pdf",
                                        "file_type": "application/pdf",
                                        "file_size": 1024000,
                                        "created_at": "2024-01-15T10:30:00Z"
                                    }
                                ],
                                "created_at": "2024-01-15T10:30:00Z",
                                "updated_at": "2024-01-15T10:30:00Z"
                            }
                        ]
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_ip_patent_requests(request):
    """Get list of IP & Patent Support Requests"""
    try:
        employee = get_object_or_404(Employee, email=request.user.email_id)
        filter_email_id = request.GET.get('email_id')

        # If user is HR manager, return all requests with optional email_id filtering
        if request.user.employee_profile.is_hr_manager:
            queryset = IPPatentSupportRequest.objects.all().order_by('-created_at')
            if filter_email_id:
                queryset = queryset.filter(created_by__email=filter_email_id)
        else:
            # Otherwise, only return requests for the logged-in employee
            if request.user.employee_profile != employee:
                return ApiResponse.error(   
                    message="You can only view requests for yourself",
                    status_code=status.HTTP_403_FORBIDDEN
                )
            queryset = IPPatentSupportRequest.objects.filter(created_by=employee).order_by('-created_at')
            if filter_email_id:
                queryset = queryset.filter(created_by__email=filter_email_id)
        
        # Apply search and filters
        queryset = apply_search_and_filters(queryset, request, 'IPPatentSupportRequest')
        
        # Apply additional filters
        status_filter = request.GET.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        protection_type = request.GET.get('protection_type')
        if protection_type:
            queryset = queryset.filter(protection_type=protection_type)

        # Pagination
        page = request.GET.get('page', 1)
        page_size = request.GET.get('page_size', 10)
        paginator = Paginator(queryset, page_size)
        
        try:
            ip_patent_requests = paginator.page(page)
        except:
            ip_patent_requests = paginator.page(1)

        serializer = IPPatentSupportRequestListSerializer(ip_patent_requests, many=True)
        
        return ApiResponse.success(
            data={
                'count': paginator.count,
                'next': ip_patent_requests.has_next(),
                'previous': ip_patent_requests.has_previous(),
                'results': serializer.data
            }
        )
    except Exception as e:
        return ApiResponse.error(
            message=f"Error retrieving IP & Patent Support Requests: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get details of a specific IP & Patent Support Request with attachments and team member details. HR managers can view any request, regular users can only view their own.",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="IP & Patent Support Request details with attachments and team members",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "IP & Patent Support Request details retrieved successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "project_name": "AI Patent Application",
                        "description": "Patent application for AI algorithm",
                        "protection_type": "patent",
                        "protection_type_display": "Patent",
                        "team_members": ["john.doe@example.com", "jane.smith@example.com"],
                        "team_members_details": [
                            {
                                "id": 1,
                                "name": "John Doe",
                                "email": "john.doe@example.com",
                                "designation": "Software Engineer"
                            },
                            {
                                "id": 2,
                                "name": "Jane Smith",
                                "email": "jane.smith@example.com",
                                "designation": "Data Scientist"
                            }
                        ],
                        "attachments": [
                            {
                                "id": 1,
                                "file_url": "https://example.com/file1.pdf",
                                "file_name": "document1.pdf",
                                "file_type": "application/pdf",
                                "file_size": 1024000,
                                "created_at": "2024-01-15T10:30:00Z"
                            }
                        ],
                        "attachment_count": 1,
                        "priority_date": "2024-01-15",
                        "status": "pending",
                        "status_display": "Pending",
                        "created_by": 1,
                        "created_by_name": "John Doe",
                        "created_by_email": "john.doe@example.com",
                        "created_at": "2024-01-15T10:30:00Z",
                        "updated_at": "2024-01-15T10:30:00Z",
                        "approved_by": None,
                        "approved_by_name": None,
                        "approved_at": None,
                        "comments": None
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied - you can only view your own requests"),
        404: openapi.Response(description="IP & Patent Support Request not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_ip_patent_request_detail(request, request_id):
    """Get details of a specific IP & Patent Support Request"""
    try:
        employee = get_object_or_404(Employee, email=request.user.email)

        # HR managers can view any request, regular users can only view their own
        if request.user.employee_profile.is_hr_manager:
            ip_patent_request = get_object_or_404(IPPatentSupportRequest, id=request_id)
        else:
            if request.user.employee_profile != employee:
                return ApiResponse.error(
                    message="You can only view requests for yourself",
                    status_code=status.HTTP_403_FORBIDDEN
                )
            ip_patent_request = get_object_or_404(IPPatentSupportRequest, id=request_id, created_by=employee)
        
        serializer = IPPatentSupportRequestSerializer(ip_patent_request)
        
        return ApiResponse.success(
            data=serializer.data,
            message="IP & Patent Support Request details retrieved successfully"
        )

    except Exception as e:
        return ApiResponse.error(
            message=f"Error retrieving IP & Patent Support Request details: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='patch',
    operation_description="Update IP & Patent Support Request status (HR Manager only)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['status'],
        properties={
            'status': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Status of the request",
                enum=['pending', 'approved', 'rejected']
            ),
            'comments': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Comments from HR manager"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter('Authorization', openapi.IN_HEADER, description="Bearer token for authentication", type=openapi.TYPE_STRING, required=True),
    ],
    responses={
        200: openapi.Response(
            description="IP & Patent Support Request status updated successfully",
            schema=IPPatentSupportRequestSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can update IP & Patent Support Requests"),
        404: openapi.Response(description="IP & Patent Support Request not found")
    }
)
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_ip_patent_status(request, request_id):
    """Update IP & Patent Support Request status (HR Manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can update request status",
            status_code=status.HTTP_403_FORBIDDEN
        )
        
    try:
        ip_patent_request = IPPatentSupportRequest.objects.get(id=request_id)
    except IPPatentSupportRequest.DoesNotExist:
        return ApiResponse.not_found("IP & Patent Support Request not found")
        
    new_status = request.data.get('status')
    if new_status not in dict(IPPatentSupportRequest.STATUS_CHOICES):
        return ApiResponse.error(
            message="Invalid status",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if ip_patent_request.status == new_status:
        return ApiResponse.error(
            message=f"IP & Patent Support Request is already in {new_status} state",
            status_code=status.HTTP_400_BAD_REQUEST
        )
        
    ip_patent_request.status = new_status
    ip_patent_request.approved_at = timezone.now()
    ip_patent_request.approved_by = request.user.employee_profile
    ip_patent_request.comments = request.data.get('comments', '')
    ip_patent_request.save()
    
    # Send email notification
    hr_managers = Employee.objects.filter(is_hr_manager=True)
    recipients = [ip_patent_request.created_by.email] + [hr_manager.email for hr_manager in hr_managers]
    threading.Thread(target=EmailService.send_ip_patent_status_update_email, args=(ip_patent_request, new_status, recipients, ip_patent_request.comments)).start()
    
    try:
        notification_service = NotificationService()
        
        # Prepare notification data
        notification_title = f"IP & Patent Support Request Status: {new_status.capitalize()}"
        notification_body = f"Your IP & Patent Support Request has been {new_status}"
        
        # Additional data for the notification
        notification_data = {
            'type': 'ip_patent_request',
            'ip_patent_request_id': str(ip_patent_request.id),
            'title': new_status,
            'created_by': request.user.email_id,
            'scheduled_time': timezone.now().isoformat() if timezone.now() else '',
        }
        
        # Send notification to the request creator
        success, message = notification_service.send_notification_to_user(
            user_email=ip_patent_request.created_by.email,
            title=notification_title,
            body=notification_body,
            data=notification_data
        )
        
        if success:
            logger.info(f"Notification sent successfully for IP patent request {ip_patent_request.id}: {message}")
        else:
            logger.warning(f"Failed to send notification for IP patent request {ip_patent_request.id}: {message}")
            
    except Exception as e:
        logger.error(f"Error sending notification for IP patent request {ip_patent_request.id}: {str(e)}")
    
    serializer = IPPatentSupportRequestSerializer(ip_patent_request)
    return ApiResponse.success(
        data=serializer.data,
        message="IP & Patent Support Request status updated successfully"
    )


@swagger_auto_schema(
    method='delete',
    operation_description="Delete IP & Patent Support Request (HR Manager only)",
    responses={
        200: openapi.Response(
            description="IP & Patent Support Request deleted successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "IP & Patent Support Request deleted successfully",
                    "success": True
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can delete IP & Patent Support Requests"),
        404: openapi.Response(description="IP & Patent Support Request not found")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_ip_patent_request(request, request_id):
    """Delete IP & Patent Support Request (HR Manager only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can delete IP & Patent Support Requests",
            status_code=status.HTTP_403_FORBIDDEN
        )

    try:
        ip_patent_request = IPPatentSupportRequest.objects.get(id=request_id)
        ip_patent_request.delete()
        
        return ApiResponse.success(
            message="IP & Patent Support Request deleted successfully"
        )
    except IPPatentSupportRequest.DoesNotExist:
        return ApiResponse.not_found("IP & Patent Support Request not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"Error deleting IP & Patent Support Request: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get count of pending requests for all request types (HR Managers only)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Pending request counts retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Pending request counts retrieved successfully",
                    "success": True,
                    "data": {
                        "leave_requests": 5,
                        "wfh_requests": 3,
                        "reimbursement_requests": 8,
                        "travel_requests": 2,
                        "emergency_fund_requests": 1,
                        "compoff_credit_requests": 4,
                        "separation_requests": 0,
                        "devices_peripherals_requests": 6,
                        "complaints": 2,
                        "ip_patent_requests": 3,
                        "total_pending": 34
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Only HR managers can access this endpoint")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_pending_requests_count(request):
    """Get count of pending requests for all request types (HR Managers only)"""
    if not request.user.employee_profile.is_hr_manager:
        return ApiResponse.error(
            message="Only HR managers can access this endpoint",
            status_code=status.HTTP_403_FORBIDDEN
        )
    
    try:
        # Get counts for each request type
        leave_requests = Leave.objects.filter(status='pending').count()
        wfh_requests = WFH.objects.filter(status='pending').count()
        reimbursement_requests = Reimbursement.objects.filter(status='pending').count()
        travel_requests = TravelRequest.objects.filter(status='pending').count()
        emergency_fund_requests = EmergencyFundRequest.objects.filter(status='pending').count()
        compoff_credit_requests = CompOffCreditRequest.objects.filter(status='pending').count()
        separation_requests = Separation.objects.filter(status='pending').count()
        devices_peripherals_requests = DevicesPeripherals.objects.filter(status='pending').count()
        complaints = Complaint.objects.filter(status='pending').count()
        ip_patent_requests = IPPatentSupportRequest.objects.filter(status='pending').count()
        
        # Calculate total
        total_pending = (
            leave_requests + wfh_requests + reimbursement_requests + 
            travel_requests + emergency_fund_requests + compoff_credit_requests + 
            separation_requests + devices_peripherals_requests + 
            complaints + ip_patent_requests
        )
        
        data = {
            "leave_requests": leave_requests,
            "wfh_requests": wfh_requests,
            "reimbursement_requests": reimbursement_requests,
            "travel_requests": travel_requests,
            "emergency_fund_requests": emergency_fund_requests,
            "compoff_credit_requests": compoff_credit_requests,
            "separation_requests": separation_requests,
            "devices_peripherals_requests": devices_peripherals_requests,
            "complaints": complaints,
            "ip_patent_requests": ip_patent_requests,
            "total_pending": total_pending
        }
        
        return ApiResponse.success(
            data=data,
            message="Pending request counts retrieved successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"Error retrieving pending request counts: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get available leaves count for the authenticated employee or, if HR manager, for a specified employee via email_id.",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email to get leave count for (HR managers only)",
            type=openapi.TYPE_STRING,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Available leaves count retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Available leaves count retrieved successfully",
                    "success": True,
                    "data": {
                        "employee_name": "John Doe",
                        "employee_email": "john.doe@example.com",
                        "available_leaves": {
                            "PL": 15,
                            "SL": 10,
                            "CL": 7,
                            "WFH": 5
                        },
                        "leaves_allotted": {
                            "PL": 20,
                            "SL": 12,
                            "CL": 10,
                            "WFH": 8
                        },
                        "leaves_taken": {
                            "PL": 5,
                            "SL": 2,
                            "CL": 3,
                            "WFH": 3
                        }
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found"),
        403: openapi.Response(description="Permission denied")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_available_leaves_count(request):
    """Get available leaves count for the authenticated employee or, if HR manager, for a specified employee via email_id."""
    try:
        email_id = request.GET.get('email_id')
        # If HR manager and email_id is provided, get for that employee
        if email_id:
            if not request.user.employee_profile.is_hr_manager:
                return ApiResponse.error(
                    message="Only HR managers can query other employees' leave counts.",
                    status_code=403
                )
            employee = Employee.objects.filter(email=email_id).first()
            if not employee:
                return ApiResponse.error(
                    message="Employee not found.",
                    status_code=404
                )
        else:
            # Otherwise, get for the logged-in user
            employee = Employee.objects.filter(email=request.user.email_id).first()
            if not employee:
                return ApiResponse.error(
                    message="Employee not found.",
                    status_code=404
                )
        # Calculate available leaves
        available_leaves = {
            'PL': employee.leaves_allotted['PL'] - employee.leaves_taken['PL'],
            'SL': employee.leaves_allotted['SL'] - employee.leaves_taken['SL'],
            'CL': employee.leaves_allotted['CL'] - employee.leaves_taken['CL'],
            'WFH': employee.leaves_allotted['WFH'] - employee.leaves_taken['WFH']
        }
        data = {
            "employee_name": employee.full_name,
            "employee_email": employee.email,
            "available_leaves": available_leaves,
            "leaves_allotted": employee.leaves_allotted,
            "leaves_taken": employee.leaves_taken
        }
        return ApiResponse.success(
            data=data,
            message="Available leaves count retrieved successfully"
        )
    except Exception as e:
        return ApiResponse.error(
            message=f"Error retrieving available leaves count: {str(e)}",
            status_code=500
        )
