from rest_framework import serializers
from .models import Announcement
from employees.models import Employee

class AnnouncementSerializer(serializers.ModelSerializer):
    """
    Serializer for Announcement model with CRUD operations
    """
    created_by_name = serializers.CharField(source='created_by.email_id', read_only=True)
    # target_audience_count = serializers.SerializerMethodField()
    is_expired = serializers.BooleanField(read_only=True)
    # target_audience_emails = serializers.ListField(
    #     child=serializers.EmailField(),
    #     write_only=True,
    #     required=False
    # )

    class Meta:
        model = Announcement
        fields = [
            'id', 'title', 'content', 'start_date', 'end_date', 'scheduled_time',
            'is_active', 'created_by', 'created_by_name',
            'is_expired',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by']

    # def get_target_audience_count(self, obj):
    #     """Get count of target audience members"""
    #     return obj.target_audience.count()

    def validate(self, data):
        """Validate announcement dates"""
        start_date = data.get('start_date')
        end_date = data.get('end_date')

        if end_date and start_date > end_date:
            raise serializers.ValidationError("End date must be after start date")

        return data

    def create(self, validated_data):
        """Create announcement with target audience"""
        # target_audience_emails = validated_data.pop('target_audience_emails', [])
        
        # Create announcement
        announcement = Announcement.objects.create(
            **validated_data,
            created_by=Employee.objects.get(email=self.context['request'].user.email_id)
        )
        
        # Add target audience if provided
        # if target_audience_emails:
        #     target_audience = Employee.objects.filter(email__in=target_audience_emails)
        #     announcement.target_audience.set(target_audience)
        
        return announcement

    def update(self, instance, validated_data):
        """Update announcement with target audience"""
        # target_audience_emails = validated_data.pop('target_audience_emails', None)
        
        # Update announcement fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        # Update target audience if provided
        # if target_audience_emails is not None:
        #     target_audience = Employee.objects.filter(email__in=target_audience_emails)
        #     instance.target_audience.set(target_audience)
        
        return instance

class AnnouncementListSerializer(serializers.ModelSerializer):
    """
    Lightweight serializer for announcement lists
    """
    created_by_name = serializers.CharField(source='created_by.email_id', read_only=True)
    # target_audience_count = serializers.SerializerMethodField()
    is_expired = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = Announcement
        fields = [
            'id', 'title', 'start_date', 'end_date', 'scheduled_time', 'content',
            'is_active', 'created_by_name',
            'is_expired', 'created_at'
        ]

    # def get_target_audience_count(self, obj):
    #     return obj.target_audience.count() 