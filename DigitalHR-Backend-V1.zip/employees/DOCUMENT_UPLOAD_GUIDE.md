# Document Upload Guide

This guide explains how to use the document upload endpoints in the DigitalHR system.

## Available Endpoints

### 1. Form-Based Upload

**Endpoint:** `POST /api/employees/documents/upload/`

This endpoint is designed for HTML forms and provides a simpler interface for document uploads.

#### HTML Form Example

```html
<form action="/api/employees/documents/upload/" method="POST" enctype="multipart/form-data">
    {% csrf_token %}
    <div>
        <label for="email_id">Employee Email:</label>
        <input type="email" name="email_id" id="email_id" required>
    </div>
    <div>
        <label for="document_type">Document Type:</label>
        <select name="document_type" id="document_type" required>
            <option value="">Select Document Type</option>
            <option value="PAN_Card">PAN Card</option>
            <option value="Aadhar_Card">Aadhar Card</option>
            <option value="10th_Certificate">10th Certificate</option>
            <option value="12th_Certificate">12th Certificate</option>
            <option value="Graduation_Certificate">Graduation Certificate</option>
            <option value="Latest_Experience_Letter">Latest Experience Letter</option>
            <option value="Past_Company_Salary_Slip">Past Company Salary Slip</option>
            <option value="Resume">Resume</option>
            <option value="ID_Proof">ID Proof</option>
            <option value="Address_Proof">Address Proof</option>
            <option value="Education_Certificate">Education Certificate</option>
            <option value="Experience_Letter">Experience Letter</option>
            <option value="Offer_Letter">Offer Letter</option>
            <option value="Contract">Contract</option>
            <option value="Passport">Passport</option>
            <option value="Other">Other</option>
        </select>
    </div>
    <div>
        <label for="document_file">Document File:</label>
        <input type="file" name="document_file" id="document_file" accept=".pdf,.jpg,.jpeg" required>
    </div>
    <div>
        <label for="notes">Notes (Optional):</label>
        <textarea name="notes" id="notes"></textarea>
    </div>
    <button type="submit">Upload Document</button>
</form>
```

#### JavaScript Example

```javascript
const form = document.getElementById('uploadForm');
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(form);
    
    try {
        const response = await fetch('/api/employees/documents/upload/', {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer your-jwt-token'
            },
            body: formData
        });
        
        const result = await response.json();
        
        if (response.ok) {
            alert('Document uploaded successfully!');
            console.log('Upload result:', result);
        } else {
            alert('Upload failed: ' + result.message);
            console.error('Upload error:', result);
        }
    } catch (error) {
        alert('Error uploading document: ' + error.message);
        console.error('Upload error:', error);
    }
});
```

### 2. API Upload (Multipart/Form-Data)

**Endpoint:** `POST /api/employees/documents/upload/`

This endpoint accepts multipart/form-data and is suitable for API clients.

#### Example Request

```bash
curl -X POST \
  'http://localhost:8000/api/employees/documents/upload/' \
  -H 'Authorization: Bearer your-jwt-token' \
  -F 'email_id=john.doe@sciverse.co.in' \
  -F 'document_type=PAN_Card' \
  -F 'document_file=@/path/to/pan_card.pdf' \
  -F 'notes=Original PAN card'
```

## Validation Rules

1. **Required Fields:**
   - `email_id`: Employee's email address
   - `document_type`: Must be one of the predefined document types
   - `document_file`: The actual file to upload

2. **File Restrictions:**
   - File types: PDF (.pdf) and JPEG (.jpg, .jpeg) only
   - Maximum file size: 10MB
   - File must be a valid document file

3. **Document Type Validation:**
   - Must match one of the predefined document types
   - Case-sensitive matching

## Response Examples

### Success Response (HTTP 201)

```json
{
    "status": "success",
    "message": "Document uploaded successfully",
    "data": {
        "id": 1,
        "document_type": "PAN_Card",
        "document_name": "PAN Card",
        "document_file_url": "https://example-bucket.s3.amazonaws.com/sciverse/employees/john.doe@sciverse.co.in/documents/PAN_Card/550e8400-e29b-41d4-a716-446655440000/pan_card.pdf",
        "is_verified": False,
        "verified_by": None,
        "verified_by_name": None,
        "verified_at": None,
        "uploaded_by": "john.doe@sciverse.co.in",
        "uploaded_by_name": "john.doe@sciverse.co.in",
        "notes": "Original PAN card",
        "file_size": "Available on S3",
        "created_at": "2024-03-20T10:30:00Z",
        "updated_at": "2024-03-20T10:30:00Z"
    }
}
```

### Validation Error (HTTP 400)

```json
{
    "status": "error",
    "message": "Validation error",
    "errors": {
        "email_id": ["This field is required."],
        "document_type": ["This field is required."],
        "document_file": ["No file was submitted."]
    }
}
```

### Authentication Error (HTTP 401)

```json
{
    "status": "error",
    "message": "Authentication credentials were not provided."
}
```

### Not Found Error (HTTP 404)

```json
{
    "status": "error",
    "message": "Employee with email john.doe@sciverse.co.in not found"
}
```

## Best Practices

1. **CSRF Protection:**
   - Always include CSRF token in form submissions
   - For API clients, use JWT token in Authorization header

2. **File Input Handling:**
   - Use `accept` attribute to restrict file types in UI
   - Implement client-side file size validation
   - Show upload progress for large files

3. **Error Handling:**
   - Display validation errors to users
   - Handle network errors gracefully
   - Show appropriate error messages

4. **Security Considerations:**
   - Validate file types on both client and server
   - Implement file size limits
   - Use secure file storage (S3 with encryption)
   - Validate user permissions

5. **User Experience:**
   - Show upload progress
   - Provide clear error messages
   - Validate inputs before submission
   - Show success/error notifications

## Using Swagger UI

1. Access the Swagger documentation at `/swagger/`
2. Authenticate using the "Authorize" button with your JWT token
3. Find the document upload endpoint
4. Fill in the required parameters:
   - `email_id`: Employee's email (e.g., <john.doe@sciverse.co.in>)
   - `document_type`: Select from dropdown
   - `document_file`: Upload file
   - `notes`: Optional notes
5. Execute the request
6. Check the response for success/error

## Troubleshooting

1. **File Upload Fails:**
   - Check file size (max 10MB)
   - Verify file type (PDF or JPEG only)
   - Ensure all required fields are provided
   - Check authentication token

2. **Authentication Errors:**
   - Verify JWT token is valid
   - Check token expiration
   - Ensure proper Authorization header format

3. **Validation Errors:**
   - Check all required fields
   - Verify document type matches allowed values
   - Ensure file meets size and type requirements

4. **Server Errors:**
   - Check server logs
   - Verify S3 configuration
   - Ensure proper permissions
 