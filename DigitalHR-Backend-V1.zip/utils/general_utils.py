from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
from rest_framework_simplejwt.tokens import RefreshToken
from authentication.authentication import ActiveUserJWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError

class ApiResponse:
    """
    Standardized API response class for consistent responses across the application
    """
    
    @staticmethod
    def success(data=None, message="Success", status_code=status.HTTP_200_OK):
        """
        Create a successful API response
        """
        response_data = {
            "code": status_code,
            "message": message,
            "data": data,
            "success": True
        }
        return Response(response_data, status=status_code)
    
    @staticmethod
    def error(message="Error occurred", errors=None, status_code=status.HTTP_400_BAD_REQUEST):
        """
        Create an error API response with simplified error format
        """
        # Simplify DRF serializer errors for frontend consumption
        simplified_errors = ApiResponse._simplify_errors(errors) if errors else None
        
        response_data = {
            "code": status_code,
            "message": message,
            "errors": simplified_errors,
            "success": False
        }
        return Response(response_data, status=status_code)
    
    @staticmethod
    def validation_error(serializer_errors, message="Validation failed"):
        """
        Create a validation error response with simplified format
        """
        simplified_errors = ApiResponse._simplify_errors(serializer_errors)
        
        response_data = {
            "code": status.HTTP_400_BAD_REQUEST,
            "message": message,
            "errors": simplified_errors,
            "success": False
        }
        return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
    
    @staticmethod
    def _simplify_errors(errors):
        """
        Convert DRF serializer errors to a simple frontend-friendly format
        
        Options:
        1. Array of strings (simplest)
        2. Array of objects with field and message
        3. Single concatenated string
        """
        if not errors:
            return None
            
        simplified = []
        
        for field, messages in errors.items():
            if field == 'non_field_errors':
                # Handle general validation errors
                for message in messages:
                    simplified.append(str(message))
            else:
                # Handle field-specific errors
                for message in messages:
                    simplified.append(f"{field.replace('_', ' ').title()}: {message}")
        
        return simplified
    
    @staticmethod
    def _simplify_errors_as_objects(errors):
        """
        Alternative: Convert to array of objects (more structured)
        """
        if not errors:
            return None
            
        simplified = []
        
        for field, messages in errors.items():
            for message in messages:
                simplified.append({
                    "field": field if field != 'non_field_errors' else None,
                    "message": str(message)
                })
        
        return simplified
    
    @staticmethod
    def _simplify_errors_as_string(errors):
        """
        Alternative: Convert to single string (simplest for display)
        """
        if not errors:
            return None
            
        error_messages = []
        
        for field, messages in errors.items():
            for message in messages:
                if field == 'non_field_errors':
                    error_messages.append(str(message))
                else:
                    error_messages.append(f"{field.replace('_', ' ').title()}: {message}")
        
        return ". ".join(error_messages)
    
    @staticmethod
    def created(data=None, message="Created successfully", status_code=status.HTTP_201_CREATED):
        """
        Create a 201 Created API response
        """
        response_data = {
            "code": status_code,
            "message": message,
            "data": data,
            "success": True
        }
        return Response(response_data, status=status_code)
    
    @staticmethod
    def not_found(message="Resource not found"):
        """
        Create a 404 Not Found API response
        """
        response_data = {
            "code": status.HTTP_404_NOT_FOUND,
            "message": message,
            "data": None,
            "success": False
        }
        return Response(response_data, status=status.HTTP_404_NOT_FOUND)
    
    @staticmethod
    def unauthorized(message="Unauthorized access"):
        """
        Create a 401 Unauthorized API response
        """
        response_data = {
            "code": status.HTTP_401_UNAUTHORIZED,
            "message": message,
            "data": None,
            "success": False
        }
        return Response(response_data, status=status.HTTP_401_UNAUTHORIZED)


class EmailDomainValidator:
    """
    Utility class for email domain validation
    """
    
    @staticmethod
    def validate_email_domain(email):
        """
        Validate if email domain is allowed based on settings
        
        Args:
            email (str): Email address to validate
            
        Returns:
            tuple: (is_valid, error_message)
        """
        # Check if domain restriction is enabled
        if not getattr(settings, 'RESTRICT_EMAIL_DOMAIN', False):
            return True, None
            
        # Get allowed domains from settings
        allowed_domains = getattr(settings, 'ALLOWED_EMAIL_DOMAINS', [])
        
        if not allowed_domains:
            return True, None
            
        # Extract domain from email
        try:
            email_domain = email.split('@')[1].lower()
        except (IndexError, AttributeError):
            return False, "Invalid email format."
            
        # Check if domain is allowed
        if email_domain not in [domain.lower() for domain in allowed_domains]:
            allowed_domains_str = ', '.join(allowed_domains)
            return False, f"Email id not permitted"
            
        return True, None
    
    @staticmethod
    def get_allowed_domains():
        """
        Get list of allowed email domains from settings
        
        Returns:
            list: List of allowed domains
        """
        return getattr(settings, 'ALLOWED_EMAIL_DOMAINS', [])
    
    @staticmethod
    def is_domain_restriction_enabled():
        """
        Check if domain restriction is enabled
        
        Returns:
            bool: True if restriction is enabled
        """
        return getattr(settings, 'RESTRICT_EMAIL_DOMAIN', False)


class JWTUtils:
    """
    Utility class for JWT token operations
    """
    
    @staticmethod
    def get_tokens_for_user(user):
        """
        Generate JWT tokens for a user
        
        Args:
            user: User instance
            
        Returns:
            dict: Dictionary containing access and refresh tokens
        """
        refresh = RefreshToken.for_user(user)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }
    
    @staticmethod
    def refresh_access_token(refresh_token_str):
        """
        Refresh access token and validate user is active
        
        Args:
            refresh_token_str: Refresh token string
            
        Returns:
            tuple: (new_access_token, error_message)
        """
        try:
            refresh_token = RefreshToken(refresh_token_str)
            
            # Get user from token
            from django.contrib.auth import get_user_model
            User = get_user_model()
            
            try:
                user_id = refresh_token.get('user_id')
                user = User.objects.get(**{User.USERNAME_FIELD: user_id})
            except User.DoesNotExist:
                return None, "User not found"
            
            # Check if user is still active
            if not user.active:
                return None, "User account is deactivated"
            
            # Generate new access token
            new_access_token = str(refresh_token.access_token)
            return new_access_token, None
            
        except TokenError as e:
            return None, f"Token error: {str(e)}"
        except Exception as e:
            return None, f"Error refreshing token: {str(e)}" 