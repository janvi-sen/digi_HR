from django.db import models
from django.conf import settings
from django.utils import timezone

# Create your models here.
class BaseModel(models.Model):
    """
    Abstract base model with common fields
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

class Epic(BaseModel):
    """
    Epic model to manage large bodies of work within projects
    """
    name = models.CharField(max_length=255)
    description = models.TextField()
    tasks = models.JSONField(default={"tasks": []})
    status = models.CharField(max_length=255, default='Active')