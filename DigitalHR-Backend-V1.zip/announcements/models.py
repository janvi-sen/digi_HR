from django.db import models
from django.utils import timezone

# Create your models here.
from employees.models import Employee

class BaseModel(models.Model):
    """
    Abstract base model with common fields
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        abstract = True

class Announcement(BaseModel):
    """
    Announcement model to manage company announcements
    """
    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
        ('Critical', 'Critical')
    ]

    title = models.CharField(max_length=255)
    content = models.TextField()
    # priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='Medium')
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(null=True, blank=True)
    scheduled_time = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='created_announcements'
    )
    # target_audience = models.ManyToManyField(
    #     Employee,
    #     related_name='announcements',
    #     blank=True
    # )

    class Meta:
        db_table = 'announcements'
        ordering = ['-scheduled_time']
        
    def __str__(self):
        return self.title

    @property
    def is_expired(self):
        """Check if announcement has expired"""
        if self.end_date:
            return self.end_date < timezone.now()
        return False