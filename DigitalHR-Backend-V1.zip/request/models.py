from django.db import models
from employees.models import Employee
from django.utils import timezone

class BaseModel(models.Model):
    """
    Abstract base model with common fields
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

class Leave(BaseModel):
    LEAVE_TYPES = (
        ('SL', 'Sick Leave'),
        ('PL', 'Privilege Leave'),
        ('CL', 'Casual Leave'),
        ('HD', 'Half Day')
    )
    
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    id = models.AutoField(primary_key=True)
    leave_type = models.CharField(max_length=2, choices=LEAVE_TYPES)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    documents = models.URLField(blank=True, null=True)  # List of document URLs
    description = models.TextField()
    from_date = models.DateField()
    to_date = models.DateField()
    comments = models.TextField(blank=True, null=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='leaves')
    
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_leaves')

    def __str__(self):
        return f"{self.employee.full_name} - {self.leave_type} ({self.from_date} to {self.to_date})"


class WFH(BaseModel):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    id = models.AutoField(primary_key=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    from_date = models.DateField()
    to_date = models.DateField()
    description = models.TextField()
    comments = models.TextField(blank=True, null=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='wfh_requests')
    
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_wfh')

    def __str__(self):
        return f"{self.employee.full_name} - WFH ({self.from_date} to {self.to_date})"


class Reimbursement(BaseModel):
    CATEGORY_CHOICES = (
        ('travel', 'Travel'),
        ('food', 'Food'),
        ('fuel', 'Fuel'),
        ('device', 'Device'),
        ('accommodation', 'Accommodation'),
        ('supplies', 'Supplies'),
        ('stationery', 'Stationery'),
        ('medical', 'Medical'),
        ('course', 'Course'),
        ('training', 'Training'),
        ('conference', 'Conference'),
        ('seminar', 'Seminar'),
        ('workshop', 'Workshop'),
        ('other', 'Other'),
        ('other', 'Other')
    )
    
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    id = models.AutoField(primary_key=True)
    reimbursement_id = models.CharField(max_length=20, unique=True, null=True, blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    project = models.ForeignKey('projects.Project', on_delete=models.SET_NULL, null=True, blank=True)
    date = models.DateField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    bill_receipt_url = models.URLField(blank=True, null=True)
    payment_receipt_url = models.URLField(blank=True, null=True)
    description = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='reimbursements')
    
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_reimbursements')
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.employee.full_name} - {self.category} Reimbursement ({self.date})"


class TravelRequest(BaseModel):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    id = models.AutoField(primary_key=True)
    project = models.ForeignKey('projects.Project', on_delete=models.SET_NULL, null=True, blank=True)
    subject = models.CharField(max_length=200)
    from_date = models.DateField()
    to_date = models.DateField()
    travel_location = models.CharField(max_length=200)
    mode_of_transport = models.CharField(max_length=100)
    estimated_expense = models.DecimalField(max_digits=10, decimal_places=2)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='travel_requests')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_travels')
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.employee.full_name} - Travel to {self.travel_location}"


class EmergencyFundRequest(BaseModel):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    id = models.AutoField(primary_key=True)
    amount_requested = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.TextField()
    fund_needed_date = models.DateField(null=True, blank=True)
    fund_repayment_date = models.DateField(null=True, blank=True)
    repayment_plan = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='emergency_fund_requests')
    
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_emergency_funds')
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.employee.full_name} - Emergency Fund Request ({self.amount_requested})"


class CompOffCreditRequest(BaseModel):
    REQUEST_TYPES = (
        ('HD', 'Half Day'),
        ('FD', 'Full Day')
    )
    
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    id = models.AutoField(primary_key=True)
    request_type = models.CharField(max_length=2, choices=REQUEST_TYPES)
    date = models.DateField()
    project = models.ForeignKey('projects.Project', on_delete=models.SET_NULL, null=True, blank=True)
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='compoff_requests')
    
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_compoffs')
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.employee.full_name} - Comp Off {self.request_type} ({self.date})"


class Complaint(BaseModel):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    
    PRIORITY_CHOICES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent')
    )
    
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='complaints')
    title = models.CharField(max_length=200)
    date = models.DateField(blank=True, null=True)
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    
    # Common fields
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='resolved_complaints')
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.employee.full_name} - {self.title} ({self.date})"


class ComplaintAttachment(BaseModel):
    """
    Model to store multiple attachments for complaints
    """
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='attachments')
    file_url = models.URLField(max_length=500)
    file_name = models.CharField(max_length=255)
    file_type = models.CharField(max_length=100, blank=True, null=True)
    file_size = models.IntegerField(blank=True, null=True)  # Size in bytes
    
    def __str__(self):
        return f"Attachment for {self.complaint.title} - {self.file_name}"

class Separation(BaseModel):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    REASON_CHOICES = (
        ('personal_reasons', 'Personal Reasons'),
        ('better_opportunities', 'Better Opportunities'),
        ('family_reasons', 'Family Reasons'),
        ('health_issues', 'Health Issues'),
        ('location_change', 'Location Change'),
        ('higher_studies', 'Higher Studies'),
        ('other', 'Other')
    )
    
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='separation_requests')
    preferred_date = models.DateField(blank=True, null=True)
    reason = models.CharField(max_length=20, choices=REASON_CHOICES)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    comments = models.TextField(blank=True, null=True)
    notice_period_compliance = models.BooleanField(default=True)
    resignation_letter_url = models.URLField(blank=True, null=True)
    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_separations')
    

    def __str__(self):
        return f"{self.employee.full_name} - Separation ({self.reason})"

class DevicesPeripherals(BaseModel):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    )
    REQUESTED_ITEM_CHOICES = (
        ('laptop', 'Laptop'),
        ('desktop', 'Desktop'),
        ('monitor', 'Monitor'),
        ('keyboard', 'Keyboard'),
        ('mouse', 'Mouse'),
        ('printer', 'Printer'),
        ('docking_station', 'Docking Station'),
        ('headset', 'Headset'),
        ('webcam', 'Webcam'),
        ('microphone', 'Microphone'),
        ('speaker', 'Speaker'),
        ('pipettes', 'Pipettes'),
        ('gloves', 'Gloves'),
        ('microscope', 'Microscope'),
        ('microscope_accessories', 'Microscope Accessories'),
        ('centrifuge', 'Centrifuge'),
        ('centrifuge_accessories', 'Centrifuge Accessories'),
        ('other', 'Other')
    )
    
    URGENCY_CHOICES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    )
    
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='devices_peripherals')
    requested_item = models.CharField(max_length=200, choices=REQUESTED_ITEM_CHOICES)
    purpose = models.TextField(blank=True, null=True)
    preferred_brand = models.CharField(max_length=200, blank=True, null=True)
    preferred_quantity = models.IntegerField(default=1)
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    comments = models.TextField(blank=True, null=True)
    delivery_location = models.ForeignKey('policies.OfficeLocations', on_delete=models.SET_NULL, null=True, blank=True, related_name='devices_peripherals')

    # Common fields
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_devices_peripherals')
    
    
    def __str__(self):
        return f"{self.employee.full_name} - {self.requested_item} ({self.urgency})"



class IPPatentSupportAttachment(BaseModel):
    """
    Model to store multiple attachments for IP Patent Support Requests
    """
    ip_patent_request = models.ForeignKey('IPPatentSupportRequest', on_delete=models.CASCADE, related_name='attachments')
    file_url = models.URLField(max_length=500)
    file_name = models.CharField(max_length=255)
    file_type = models.CharField(max_length=100, blank=True, null=True)
    file_size = models.IntegerField(blank=True, null=True)  # Size in bytes
    
    def __str__(self):
        return f"Attachment for {self.ip_patent_request.project_name} - {self.file_name}"

class IPPatentSupportRequest(models.Model):
    PROTECTION_TYPE_CHOICES = [
        ('patent', 'Patent'),
        ('copyright', 'Copyright'),
        ('trademark', 'Trademark'),
        ('trade_secret', 'Trade Secret'),
        ('design', 'Design'),
        ('other', 'Other'),
    ]
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    project_name = models.CharField(max_length=255)
    description = models.TextField()
    protection_type = models.CharField(max_length=32, choices=PROTECTION_TYPE_CHOICES)
    team_members = models.ManyToManyField(Employee, blank=True, related_name='ip_requests')
    priority_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default='pending')
    created_by = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='created_ip_requests')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    approved_by = models.ForeignKey(Employee, null=True, blank=True, on_delete=models.SET_NULL, related_name='approved_ip_requests')
    approved_at = models.DateTimeField(null=True, blank=True)
    comments = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'ip_patent_support_requests'
        verbose_name = 'IP & Patent Support Request'
        verbose_name_plural = 'IP & Patent Support Requests'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.project_name} ({self.protection_type})"
    
    