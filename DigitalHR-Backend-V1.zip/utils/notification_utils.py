"""
Notification utility functions for DigitalHR project.
"""

import logging
import requests
import json
from django.conf import settings
from django.utils import timezone
from typing import List, Dict, Any, Optional, Tuple
from authentication.models import User
import firebase_admin
from firebase_admin import credentials,messaging
from employees.models import Employee

logger = logging.getLogger(__name__)

class NotificationService:
    """
    Service class for handling push notifications using Firebase Cloud Messaging
    """
    
    def __init__(self):
        # FCM configuration
        self.fcm_server_key = getattr(settings, 'FCM_SERVER_KEY', None)
        self.fcm_url = 'https://fcm.googleapis.com/fcm/send'
        
        # Try to initialize Firebase Admin SDK as fallback
        self.firebase_admin_available = False
        try:
            if not firebase_admin._apps:
                # Initialize Firebase Admin SDK
                cred = credentials.Certificate("digital-hr-staging-firebase-adminsdk-fbsvc-333365cf0e.json")
                firebase_admin.initialize_app(cred)
            self.firebase_admin_available = True
            self.messaging = messaging
            logger.info("Firebase Admin SDK initialized successfully")
        except Exception as e:
            logger.warning(f"Firebase Admin SDK not available: {e}")
        
        if not self.fcm_server_key and not self.firebase_admin_available:
            logger.warning("Neither FCM_SERVER_KEY nor Firebase Admin SDK is configured")
    
    def send_notification_to_user(self, user_email: str, title: str, body: str, 
                                 data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Send notification to a specific user
        
        Args:
            user_email (str): User's email address
            title (str): Notification title
            body (str): Notification body
            data (dict): Additional data to send with notification
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Get user's device token
            try:
                user = User.objects.get(email_id=user_email)
                if not user.device_token:
                    return False, f"No device token found for user {user_email}"
                
                return self.send_notification_to_tokens([user.device_token], title, body, data)
                
            except User.DoesNotExist:
                return False, f"User {user_email} not found"
            
        except Exception as e:
            error_msg = f"Failed to send notification to user {user_email}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def send_notification_to_all_users(self, title: str, body: str, 
                                      data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Send notification to all users with device tokens
        
        Args:
            title (str): Notification title
            body (str): Notification body
            data (dict): Additional data to send with notification
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Get all users with device tokens
            users_with_tokens = User.objects.filter(
                device_token__isnull=False,
                device_token__gt='',
                active=True
            )
            
            if not users_with_tokens.exists():
                return False, "No users with device tokens found"
            
            # Extract device tokens
            tokens = [user.device_token for user in users_with_tokens if user.device_token]
            
            if not tokens:
                return False, "No valid device tokens found"
            
            return self.send_notification_to_tokens(tokens, title, body, data)
            
        except Exception as e:
            error_msg = f"Failed to send notification to all users: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def send_notification_to_tokens(self, tokens: List[str], title: str, body: str,
                                   data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Send notification to specific device tokens
        
        Args:
            tokens (list): List of device tokens
            title (str): Notification title
            body (str): Notification body
            data (dict): Additional data to send with notification
            
        Returns:
            tuple: (success, error_message)
        """
        if not tokens:
            return False, "No device tokens provided"
        
        # Try Firebase Admin SDK first (more reliable)
        if self.firebase_admin_available:
            return self._send_via_firebase_admin(tokens, title, body, data)
        
        # Fallback to FCM server key
        if self.fcm_server_key:
            return self._send_via_fcm_server_key(tokens, title, body, data)
        
        return False, "No notification method configured"
    
    def _send_via_firebase_admin(self, tokens: List[str], title: str, body: str,
                                data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """Send notification using Firebase Admin SDK"""
        try:
            # For multiple tokens, send individually to avoid batch issues
            success_count = 0
            failure_count = 0
            
            for token in tokens:
                try:
                    # Use the simpler approach from test_notfication.py
                    message = messaging.Message(
                        notification=messaging.Notification(
                            title=title,
                            body=body,
                        ),
                        data=data or {},
                        token=token,
                        apns=messaging.APNSConfig(
                            payload=messaging.APNSPayload(
                                aps=messaging.Aps(
                                    sound="default",
                                    badge=1
                                )
                            )
                        )
                    )
                    
                    response = messaging.send(message)
                    success_count += 1
                    logger.info(f"Successfully sent message to token {token[:20]}...: {response}")
                    
                except messaging.UnregisteredError:
                    # Token is invalid, mark as failed
                    failure_count += 1
                    logger.warning(f"Invalid token {token[:20]}... - will be cleaned up")
                    # Clean up invalid token
                    User.objects.filter(device_token=token).update(device_token='')
                    
                except Exception as e:
                    failure_count += 1
                    logger.error(f"Failed to send to token {token[:20]}...: {str(e)}")
            
            logger.info(f"Firebase Admin notification sent: {success_count} success, {failure_count} failure")
            
            if success_count > 0:
                return True, f"Notification sent successfully. Success: {success_count}, Failure: {failure_count}"
            else:
                return False, f"All notifications failed. Success: {success_count}, Failure: {failure_count}"
            
        except Exception as e:
            error_msg = f"Firebase Admin SDK error: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def _send_via_fcm_server_key(self, tokens: List[str], title: str, body: str,
                                data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """Send notification using FCM server key"""
        try:
            headers = {
                'Authorization': f'key={self.fcm_server_key}',
                'Content-Type': 'application/json'
            }
            
            # Prepare notification payload
            payload = {
                'registration_ids': tokens,
                'notification': {
                    'title': title,
                    'body': body,
                    'sound': 'default',
                    'badge': 1,
                    'click_action': 'FLUTTER_NOTIFICATION_CLICK'
                },
                'data': data or {},
                'priority': 'high',
                'content_available': True
            }
            
            # Send request to FCM
            response = requests.post(
                self.fcm_url,
                headers=headers,
                data=json.dumps(payload),
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Handle FCM response
                success_count = result.get('success', 0)
                failure_count = result.get('failure', 0)
                
                logger.info(f"FCM notification sent: {success_count} success, {failure_count} failure")
                
                # Handle failed tokens
                if failure_count > 0 and 'results' in result:
                    self._handle_failed_tokens(tokens, result['results'])
                
                return True, f"Notification sent successfully. Success: {success_count}, Failure: {failure_count}"
            else:
                error_msg = f"FCM request failed with status {response.status_code}: {response.text}"
                logger.error(error_msg)
                return False, error_msg
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Network error sending notification: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
        except Exception as e:
            error_msg = f"Unexpected error sending notification: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def send_notification_to_multiple_users(self, user_emails: List[str], title: str, body: str,
                                          data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Send notification to multiple users
        
        Args:
            user_emails (list): List of user email addresses
            title (str): Notification title
            body (str): Notification body
            data (dict): Additional data to send with notification
            
        Returns:
            tuple: (success, error_message)
        """
        try:
            # Get all users with device tokens
            users_with_tokens = User.objects.filter(
                email_id__in=user_emails,
                device_token__isnull=False,
                device_token__gt='',
                active=True
            )
            
            if not users_with_tokens.exists():
                return False, f"No users with device tokens found for emails {user_emails}"
            
            tokens = [user.device_token for user in users_with_tokens if user.device_token]
            print(tokens)
            if not tokens:
                return False, "No valid device tokens found"
            
            return self.send_notification_to_tokens(tokens, title, body, data)
            
        except Exception as e:
            error_msg = f"Failed to send notification to multiple users: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def send_notification_to_hr_managers(self, title: str, body: str,
                                        data: Optional[Dict[str, Any]] = None,
                                        recipients: Optional[List[str]] = None) -> Tuple[bool, str]:
        """
        Send notification to all HR managers
        
        Args:
            title (str): Notification title
            body (str): Notification body
            data (dict): Additional data to send with notification
            
        Returns:
            tuple: (success, error_message)
        """
        try:            
            # Get HR managers
            hr_managers = Employee.objects.filter(is_hr_manager=True)
            hr_manager_emails = [emp.email for emp in hr_managers]
            if not recipients:
                recipients = hr_manager_emails
            if not recipients:
                return False, "No HR managers found"
            
            return self.send_notification_to_multiple_users(recipients, title, body, data)
            
        except Exception as e:
            error_msg = f"Failed to send notification to HR managers: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def _handle_failed_tokens(self, tokens: List[str], results: List[Dict]) -> None:
        """
        Handle failed tokens by clearing them from user records (FCM server key method)
        
        Args:
            tokens (list): List of device tokens
            results (list): FCM response results
        """
        try:
            for i, result in enumerate(results):
                if i < len(tokens):
                    token = tokens[i]
                    
                    # Check for specific error types that indicate invalid tokens
                    error = result.get('error')
                    if error in ['NotRegistered', 'InvalidRegistration', 'MismatchSenderId']:
                        # Clear the token from user records
                        User.objects.filter(device_token=token).update(device_token='')
                        logger.info(f"Cleared invalid token: {token[:20]}... (Error: {error})")
                        
        except Exception as e:
            logger.error(f"Error handling failed tokens: {str(e)}")
    

# Create a global instance
notification_service = NotificationService() 