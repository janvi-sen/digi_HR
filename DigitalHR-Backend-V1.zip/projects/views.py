from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.core.paginator import Paginator
from django.db.models import Q

from .models import Project
from .serializers import ProjectDetailedSerializer, ProjectSerializer, ProjectListSerializer
from employees.models import Employee
from epics.models import Epic
from utils.general_utils import ApiResponse

# Create your views here.

@swagger_auto_schema(
    method='post',
    operation_description="Create a new project with epics",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['name', 'project_manager_email', 'team_member_emails'],
        properties={
            'name': openapi.Schema(type=openapi.TYPE_STRING, description="Project name"),
            'description': openapi.Schema(type=openapi.TYPE_STRING, description="Project description"),
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="Project status", enum=['Planning', 'Active', 'On Hold', 'Completed', 'Cancelled']),
            'priority': openapi.Schema(type=openapi.TYPE_STRING, description="Project priority", enum=['Low', 'Medium', 'High', 'Critical']),
            'start_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Project start date"),
            'end_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Project end date"),
            'project_manager_email': openapi.Schema(type=openapi.TYPE_STRING, description="Email ID of the project manager"),
            'team_member_emails': openapi.Schema(
                type=openapi.TYPE_ARRAY,
                items=openapi.Schema(type=openapi.TYPE_STRING),
                description="List of email IDs for team members"
            ),
            'budget': openapi.Schema(type=openapi.TYPE_NUMBER, description="Project budget"),
            'notes': openapi.Schema(type=openapi.TYPE_STRING, description="Additional notes"),
            'epics': openapi.Schema(
                type=openapi.TYPE_ARRAY,
                description="List of epics to create with the project",
                items=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'name': openapi.Schema(type=openapi.TYPE_STRING, description="Epic name"),
                        'description': openapi.Schema(type=openapi.TYPE_STRING, description="Epic description"),
                        'tasks': openapi.Schema(type=openapi.TYPE_ARRAY, description="List of tasks for the epic", items=openapi.Schema(type=openapi.TYPE_STRING))
                    }
                )
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Project created successfully with epics",
            schema=ProjectSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="One or more employees not found"),
        409: openapi.Response(description="Project with this name already exists")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_project(request):
    """Create a new project with epics"""
    # Check if project with same name exists (case-insensitive)
    project_name = request.data.get('name')
    if Project.objects.filter(name__iexact=project_name).exists():
        return ApiResponse.error(
            message=f"Project with name '{project_name}' already exists",
            status_code=status.HTTP_409_CONFLICT
        )
    
    # Extract employee emails from request data
    project_manager_email = request.data.get('project_manager_email')
    team_member_emails = request.data.get('team_member_emails', [])
    
    # Create a copy of request data without email fields and epics
    project_data = request.data.copy()
    project_data.pop('project_manager_email', None)
    project_data.pop('team_member_emails', None)
    epics_data = project_data.pop('epics', [])
    
    # Validate and get project manager
    # try:
    #     project_manager = Employee.objects.get(email=project_manager_email)
    # except Employee.DoesNotExist:
    #     return ApiResponse.not_found(f"Project manager with email {project_manager_email} not found")
    
    # Validate and get team members
    team_members = []
    invalid_emails = []
    for email in team_member_emails:
        try:
            employee = Employee.objects.get(email=email)
            team_members.append(employee)
        except Employee.DoesNotExist:
            invalid_emails.append(email)
    
    if invalid_emails:
        return ApiResponse.not_found(
            f"Team members with following emails not found: {', '.join(invalid_emails)}"
        )
    
    # Add project manager and created_by to project data
    # project_data['project_manager'] = project_manager
    project_data['created_by'] = Employee.objects.get(email=request.user.email_id).id
    
    # Create project
    serializer = ProjectSerializer(data=project_data)
    if serializer.is_valid():
        project = serializer.save()
        
        # Add team members
        if team_members:
            project.team_members.set(team_members)
        
        # Create epics
        created_epics = []
        for epic_data in epics_data:
            # Get assigned employee
            assigned_to_email = epic_data.pop('assigned_to_email', None)
            if assigned_to_email:
                try:
                    assigned_to = Employee.objects.get(email=assigned_to_email)
                    epic_data['assigned_to'] = assigned_to
                except Employee.DoesNotExist:
                    return ApiResponse.not_found(f"Epic assignee with email {assigned_to_email} not found")
            
            # Check if epic with same name exists in the project
            epic_name = epic_data.get('name')
            existing_epic = Epic.objects.filter(
                name__iexact=epic_name
            ).first()
            
            if existing_epic:
                # Merge tasks if epic exists
                existing_tasks = set(existing_epic.tasks) if existing_epic.tasks else set()
                new_tasks = set(epic_data.get('tasks', []))
                merged_tasks = list(existing_tasks.union(new_tasks))
                
                # Update existing epic with merged tasks
                existing_epic.tasks = merged_tasks
                existing_epic.save()
                created_epics.append(existing_epic)
            else:
                # Create new epic
                epic = Epic.objects.create(
                    **epic_data,
                )
                created_epics.append(epic)
        
        # Add epics to project
        if created_epics:
            project.epics.set(created_epics)
        
        return ApiResponse.created(
            data=serializer.data,
            message="Project created successfully with epics"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='get',
    operation_description="Get list of projects with pagination and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('status', openapi.IN_QUERY, description="Filter by status", type=openapi.TYPE_STRING),
        openapi.Parameter('priority', openapi.IN_QUERY, description="Filter by priority", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search by name", type=openapi.TYPE_STRING),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter projects by employee Email ID (project manager or team member)", type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response(
            description="Projects retrieved successfully",
            schema=ProjectListSerializer(many=True)
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_projects(request):
    """Get paginated list of projects with filtering options"""
    # Get query parameters
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 30))
    status_filter = request.GET.get('status', '')
    priority_filter = request.GET.get('priority', '')
    search = request.GET.get('search', '')
    email_id = request.GET.get('email_id')
    
    # Build query
    queryset = Project.objects.all()
    
    # Filter by employee if employee_id is provided
    if email_id:
        try:
            employee = Employee.objects.get(email=email_id)
            queryset = queryset.filter(
                Q(project_manager=employee) | Q(team_members=employee)
            ).distinct()
        except Employee.DoesNotExist:
            return ApiResponse.not_found(f"Employee with ID {email_id} not found")
    
    # Apply filters
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    if priority_filter:
        queryset = queryset.filter(priority=priority_filter)
    
    if search:
        queryset = queryset.filter(
            Q(name__icontains=search) |
            Q(description__icontains=search)
        )
    
    # Order by created date
    queryset = queryset.order_by('-created_at')
    
    # Paginate
    paginator = Paginator(queryset, page_size)
    
    try:
        projects_page = paginator.page(page)
    except:
        return ApiResponse.error(
            message="Invalid page number",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Serialize data
    serializer = ProjectListSerializer(projects_page.object_list, many=True)
    
    # Build pagination response
    pagination_data = {
        'count': paginator.count,
        'page': page,
        'page_size': page_size,
        'total_pages': paginator.num_pages,
        'has_next': projects_page.has_next(),
        'has_previous': projects_page.has_previous(),
        'results': serializer.data
    }
    
    return ApiResponse.success(
        data=pagination_data,
        message="Projects retrieved successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get project details by ID",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Project details retrieved successfully",
            schema=ProjectSerializer
        ),
        404: openapi.Response(description="Project not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_project_detail(request, project_id):
    """Get detailed information about a specific project"""
    try:
        project = Project.objects.get(id=project_id)
    except Project.DoesNotExist:
        return ApiResponse.not_found("Project not found")
    
    serializer = ProjectDetailedSerializer(project)
    
    return ApiResponse.success(
        data=serializer.data,
        message="Project details retrieved successfully"
    )

@swagger_auto_schema(
    method='put',
    operation_description="Update project information",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'name': openapi.Schema(type=openapi.TYPE_STRING, description="Project name"),
            'description': openapi.Schema(type=openapi.TYPE_STRING, description="Project description"),
            'status': openapi.Schema(type=openapi.TYPE_STRING, description="Project status", enum=['Planning', 'Active', 'On Hold', 'Completed', 'Cancelled']),
            'priority': openapi.Schema(type=openapi.TYPE_STRING, description="Project priority", enum=['Low', 'Medium', 'High', 'Critical']),
            'start_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Project start date"),
            'end_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Project end date"),
            'project_manager_email': openapi.Schema(type=openapi.TYPE_STRING, description="Email ID of the project manager"),
            'team_member_emails': openapi.Schema(
                type=openapi.TYPE_ARRAY,
                items=openapi.Schema(type=openapi.TYPE_STRING),
                description="List of email IDs for team members"
            ),
            'budget': openapi.Schema(type=openapi.TYPE_NUMBER, description="Project budget"),
            'notes': openapi.Schema(type=openapi.TYPE_STRING, description="Additional notes"),
            'epics': openapi.Schema(
                type=openapi.TYPE_ARRAY,
                description="List of epics to create or update",
                items=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'name': openapi.Schema(type=openapi.TYPE_STRING, description="Epic name"),
                        'description': openapi.Schema(type=openapi.TYPE_STRING, description="Epic description"),
                        'status': openapi.Schema(type=openapi.TYPE_STRING, description="Epic status", enum=['Backlog', 'In Progress', 'Review', 'Done', 'Blocked']),
                        'priority': openapi.Schema(type=openapi.TYPE_STRING, description="Epic priority", enum=['Low', 'Medium', 'High', 'Critical']),
                        'assigned_to_email': openapi.Schema(type=openapi.TYPE_STRING, description="Email ID of the epic assignee"),
                        'start_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Epic start date"),
                        'due_date': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Epic due date"),
                        'estimated_hours': openapi.Schema(type=openapi.TYPE_NUMBER, description="Estimated hours for the epic"),
                        'notes': openapi.Schema(type=openapi.TYPE_STRING, description="Additional notes for the epic"),
                        'tasks': openapi.Schema(
                            type=openapi.TYPE_ARRAY,
                            description="List of tasks for the epic",
                            items=openapi.Schema(type=openapi.TYPE_STRING)
                        )
                    }
                )
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Project updated successfully",
            schema=ProjectDetailedSerializer
        ),
        404: openapi.Response(description="Project or employee not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_project(request, project_id):
    """Update project information"""
    try:
        project = Project.objects.get(id=project_id)
    except Project.DoesNotExist:
        return ApiResponse.not_found("Project not found")
    
    # Create a copy of request data
    project_data = request.data.copy()
    
    # Handle project manager update
    project_manager_email = project_data.pop('project_manager_email', None)
    if project_manager_email:
        try:
            project_manager = Employee.objects.get(email=project_manager_email)
            project_data['project_manager'] = project_manager.id
        except Employee.DoesNotExist:
            return ApiResponse.not_found(f"Project manager with email {project_manager_email} not found")
    
    # Handle team members update
    team_member_emails = project_data.pop('team_member_emails', None)
    if team_member_emails is not None:
        team_members = []
        invalid_emails = []
        for email in team_member_emails:
            try:
                employee = Employee.objects.get(email=email)
                team_members.append(employee)
            except Employee.DoesNotExist:
                invalid_emails.append(email)
        
        if invalid_emails:
            return ApiResponse.not_found(
                f"Team members with following emails not found: {', '.join(invalid_emails)}"
            )
    
    # Handle epics update
    epics_data = project_data.pop('epics', None)
    if epics_data is not None:
        created_epics = []
        for epic_data in epics_data:
            # Get assigned employee
            print(epic_data)
           
            # Check if epic with same name exists in the project
            epic_name = epic_data.get('name')
            existing_epic = Epic.objects.filter(
                name__iexact=epic_name
            ).first()
            
            if existing_epic:
                # Merge tasks if epic exists
                existing_tasks = set(existing_epic.tasks) if existing_epic.tasks else set()
                new_tasks = set(epic_data.get('tasks', []))
                merged_tasks = list(existing_tasks.union(new_tasks))
                
                # Update existing epic with merged tasks and other fields
                for key, value in epic_data.items():
                    setattr(existing_epic, key, value)
                existing_epic.tasks = merged_tasks
                existing_epic.save()
                created_epics.append(existing_epic)
            else:
                # Create new epic
                epic = Epic.objects.create(
                    **epic_data,
                )
                created_epics.append(epic)
    
    # Update project
    serializer = ProjectDetailedSerializer(project, data=project_data, partial=True)
    if serializer.is_valid():
        updated_project = serializer.save()
        
        # Update team members if provided
        if team_member_emails is not None:
            updated_project.team_members.set(team_members)
        
        # Update epics if provided
        if epics_data is not None:
            updated_project.epics.set(created_epics)
        
        return ApiResponse.success(
            data=serializer.data,
            message="Project updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='delete',
    operation_description="Delete a project",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(description="Project deleted successfully"),
        404: openapi.Response(description="Project not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_project(request, project_id):
    """Delete a project"""
    try:
        project = Project.objects.get(id=project_id)
    except Project.DoesNotExist:
        return ApiResponse.not_found("Project not found")
    
    project.delete()
    
    return ApiResponse.success(
        message="Project deleted successfully"
    )
