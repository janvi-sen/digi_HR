# Employee Update Field Restrictions

## Overview

The Employee model has two update endpoints with different permission levels:

## 1. Regular Update Endpoint: `/api/employees/{id}/update/`

### **Allowed Fields** (Can be updated by regular users)

- `full_name` - Employee's full name
- `mobile_number` - Contact number (validated for Indian format)
- `date_of_birth` - Employee's date of birth
- `gender` - Gender selection
- `address` - Residential address
- `profile_photo` - Profile photo file upload (max 5MB, jpg/png/gif)
- `profile_photo_url` - External profile photo URL (S3, CDN, etc.)
- `department` - Department assignment
- `designation` - Job designation/title
- `emergency_contact_name` - Emergency contact person
- `emergency_contact_number` - Emergency contact number
- `emergency_contact_relation` - Relationship with emergency contact

### **Restricted Fields** (Cannot be updated)

- `id` - Primary key (system generated)
- `employee_id` - Unique employee identifier (auto-generated)
- `email` - Email address (linked to user account)
- `date_of_joining` - Original joining date
- `employment_status` - Employment status (Active/Inactive/etc.)
- `is_verified` - Verification status
- `is_onboard` - Onboarding status
- `verification_date` - Date of verification
- `onboarding_date` - Date of onboarding
- `last_login` - Last login timestamp
- `salary` - Salary information
- `created_at` - Record creation timestamp
- `updated_at` - Record update timestamp
- `user_email` - Associated user's email
- `profile_photo_display_url` - Computed display URL (read-only)

## 2. Admin Update Endpoint: `/api/employees/{id}/admin-update/`

### **Access Level**: Admin/Staff only

### **Allowed Fields**: All fields including restricted ones

### **Use Cases**

- Correcting critical information
- Updating employment status
- Managing verification status
- Salary adjustments
- System-level corrections

## Security Features

### Field Validation

```python
# If restricted field is sent in regular update:
{
    "code": 400,
    "message": "Validation failed",
    "errors": [
        "Field 'email' cannot be updated through this endpoint."
    ]
}
```

### Admin Permission Check

```python
# If non-admin tries admin endpoint:
{
    "code": 403,
    "message": "Admin access required",
    "success": false
}
```

## API Examples

### Regular Update (Allowed)

```json
PUT /api/employees/1/update/
{
    "full_name": "Updated Name",
    "mobile_number": "9876543210",
    "department": "Tech",
    "designation": "Senior Developer",
    "profile_photo_url": "https://s3.amazonaws.com/bucket/photos/employee_1.jpg"
}
```

### Profile Photo Upload

```bash
# Upload file directly
POST /api/employees/1/profile-photo/
Content-Type: multipart/form-data

profile_photo: [file upload]

# Or set external URL
POST /api/employees/1/profile-photo/
Content-Type: application/json

{
    "profile_photo_url": "https://s3.amazonaws.com/bucket/photos/employee_1.jpg"
}

# Or both (URL takes priority for display)
POST /api/employees/1/profile-photo/
Content-Type: multipart/form-data

profile_photo: [file upload]
profile_photo_url: "https://s3.amazonaws.com/bucket/photos/employee_1.jpg"
```

### Regular Update (Restricted - Will Fail)

```json
PUT /api/employees/1/update/
{
    "full_name": "Updated Name",
    "email": "newemail@sciverse.co.in",  // ❌ Restricted
    "employment_status": "Terminated"    // ❌ Restricted
}
```

### Admin Update (All Fields)

```json
PUT /api/employees/1/admin-update/
{
    "full_name": "Updated Name",
    "email": "newemail@sciverse.co.in",  // ✅ Allowed for admin
    "employment_status": "Terminated",   // ✅ Allowed for admin
    "salary": 75000.00,                  // ✅ Allowed for admin
    "profile_photo_url": "https://s3.amazonaws.com/bucket/photos/employee_1.jpg"
}
```

## Rationale

### Why These Restrictions?

1. **Data Integrity**: Critical fields like employee_id and email shouldn't change frequently
2. **Security**: Salary and employment status should only be changed by authorized personnel
3. **Audit Trail**: System timestamps and verification dates need controlled access
4. **Business Logic**: Email changes affect user accounts and authentication

### Benefits

- Prevents accidental modification of critical data
- Provides clear separation of responsibilities
- Maintains data consistency
- Supports compliance and audit requirements
 