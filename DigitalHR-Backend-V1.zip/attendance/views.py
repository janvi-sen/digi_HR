import json
from django.shortcuts import render
from request.models import Leave, WFH, CompOffCreditRequest
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
import base64
import uuid
import os
from datetime import datetime, timedelta
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from utils.boto_utils import S3DocumentUploader
from .models import DailyAttendance, DailyTask
from .serializers import (
    DailyAttendanceSerializer, DailyTaskSerializer,
    DailyAttendanceListSerializer, DailyTaskListSerializer
)
from employees.models import Employee
from projects.models import Project
from epics.models import Epic
from policies.models import OfficeLocations
from utils.general_utils import ApiResponse
from utils.constants import EXAMPLE_EMAIL, DOCUMENT_TYPES
import math

def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Calculate distance between two coordinates using Haversine formula
    Returns distance in meters
    """
    # Convert latitude and longitude from degrees to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # Radius of earth in meters
    r = 6371000
    
    return c * r

def get_nearby_office_location(lat_long, max_distance_meters=50):
    """
    Find the nearest office location within the specified distance
    Returns the office location object if found, None otherwise
    """
    if not lat_long:
        return None
    
    try:
        # Parse the lat_long string
        lat_str, lon_str = lat_long.split(',')
        attendance_lat = float(lat_str.strip())
        attendance_lon = float(lon_str.strip())
        
        # Get all active office locations
        office_locations = OfficeLocations.objects.filter(is_active=True)
        
        nearest_location = None
        min_distance = float('inf')
        
        for location in office_locations:
            if location.lat_long:
                try:
                    # Parse office location coordinates
                    office_lat_str, office_lon_str = location.lat_long.split(',')
                    office_lat = float(office_lat_str.strip())
                    office_lon = float(office_lon_str.strip())
                    
                    # Calculate distance
                    distance = calculate_distance(
                        attendance_lat, attendance_lon,
                        office_lat, office_lon
                    )
                    
                    # Check if within max distance and closer than previous
                    if distance <= max_distance_meters and distance < min_distance:
                        min_distance = distance
                        nearest_location = location
                        
                except (ValueError, IndexError):
                    # Skip locations with invalid coordinates
                    continue
        
        return nearest_location
        
    except (ValueError, IndexError):
        # Invalid lat_long format
        return None

def save_selfie_image(base64_data, date, selfie_type):
    """
    Save base64 selfie image to file system
    Returns the URL path of the saved image
    """
    try:
        # Decode base64 data
        format, imgstr = base64_data.split(';base64,')
        ext = format.split('/')[-1]
        
        # Generate unique filename
        filename = f"{selfie_type}_{uuid.uuid4()}.{ext}"
        
        # Create directory path
        dir_path = f"media/daily_attendance/{date}"
        os.makedirs(dir_path, exist_ok=True)
        
        # Full file path
        file_path = os.path.join(dir_path, filename)
        
        # Save file
        with open(file_path, 'wb') as f:
            f.write(base64.b64decode(imgstr))
        
        # Return relative URL path
        return f"daily_attendance/{date}/{filename}"
    except Exception as e:
        raise Exception(f"Error saving selfie image: {str(e)}")

@swagger_auto_schema(
    method='post',
    operation_description="Clock in for the day with selfie",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'project_id',
            openapi.IN_FORM,
            description="Project ID",
            type=openapi.TYPE_INTEGER,
            required=True
        ),
        openapi.Parameter(
            'epic_id',
            openapi.IN_FORM,
            description="Epic ID",
            type=openapi.TYPE_INTEGER,
            required=True
        ),
        openapi.Parameter(
            'clock_in_location',
            openapi.IN_FORM,
            description="Clock in location",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'clock_in_selfie',
            openapi.IN_FORM,
            description="Clock in selfie image file",
            type=openapi.TYPE_FILE,
            required=True
        ),
        openapi.Parameter(
            'lat_long',
            openapi.IN_FORM,
            description="Latitude and longitude of the clock in location",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'device_token',
            openapi.IN_FORM,
            description="Device token for notifications",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Successfully clocked in",
            schema=DailyAttendanceSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        409: openapi.Response(description="Already clocked in for today")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def clock_in(request):
    """Clock in for the day with selfie"""
    try:
        # Get employee
        employee = Employee.objects.get(email=request.user.email_id)
        
        # Get current date
        current_date = timezone.now().date()
        
        # Check if already clocked in for today
        if DailyAttendance.objects.filter(
            employee__email=request.user.email_id,
            date=current_date
        ).exists():
            return ApiResponse.error(
                message="Already clocked in for today",
                status_code=status.HTTP_409_CONFLICT
            )
        
        on_leave = Leave.objects.filter(employee=employee, status='approved', from_date__lte=current_date, to_date__gte=current_date).exists()
        if on_leave:
            return ApiResponse.error(
                message="Employee is on leave",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate selfie image
        selfie_file = request.FILES.get('clock_in_selfie')
        if not selfie_file:
            return ApiResponse.error(
                message="Selfie image is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate file type
        if not selfie_file.content_type.startswith('image/'):
            return ApiResponse.error(
                message="Invalid file type. Only image files are allowed",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Upload selfie to S3
        uploader = S3DocumentUploader()
        success, result = uploader.upload_document(
            email_id=request.user.email_id,
            document_collection="selfies",
            other_prefix=current_date,
            document_type="clock_in",
            file=selfie_file,
        )
        
        if not success:
            pass
            # return ApiResponse.error(
            #     message=f"Failed to upload selfie: {result}",
            #     status_code=status.HTTP_400_BAD_REQUEST
            # )
        
        # Create attendance record
        attendance = DailyAttendance.objects.create(
            employee=employee,
            date=current_date,
            clock_in_time=timezone.now(),
            clock_in_location=request.data.get('clock_in_location'),
            clock_in_selfie=result,
            lat_long=request.data.get('lat_long'),
            # clock_in_selfie=request.data.get('clock_in_selfie'),
        )
        
        # Validate and get project and epic
        try:
            project = Project.objects.get(id=request.data.get('project_id'))
            epic = Epic.objects.get(id=request.data.get('epic_id'))
        except Project.DoesNotExist:
            return ApiResponse.not_found("Project not found")
        except Epic.DoesNotExist:
            return ApiResponse.not_found("Epic not found")
        
        # Create initial task record
        DailyTask.objects.create(
            employee=employee,
            attendance=attendance,  # Link to attendance record
            date=current_date,
            project=project,
            epic=epic,
            tasks_completed=[],
            start_time=timezone.now()
        )
        
        serializer = DailyAttendanceSerializer(attendance)
        return ApiResponse.created(
            data=serializer.data,
            message="Successfully clocked in"
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=str(e),
            status_code=status.HTTP_400_BAD_REQUEST
        )

@swagger_auto_schema(
    method='post',
    operation_description="Clock out for the day",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'attendance_id',
            openapi.IN_FORM,
            description="Attendance ID",
            type=openapi.TYPE_INTEGER,
            required=True
        ),
        openapi.Parameter(
            'clock_out_selfie',
            openapi.IN_FORM,
            description="Clock out selfie image file",
            type=openapi.TYPE_FILE,
            required=False
        ),
        openapi.Parameter(
            'clock_out_location',
            openapi.IN_FORM,
            description="Clock out location",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'tasks_completed',
            openapi.IN_FORM,
            description='JSON string of tasks completed. Example: [{"project_id": 1, "tasks": ["Task 1", "Task 2"]}]',
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'device_token',
            openapi.IN_FORM,
            description="Device token for notifications",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Clock out successful",
            schema=DailyAttendanceSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="No active attendance record found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def clock_out(request):
    """Clock out for the day"""
    try:
        # Get current date
        current_date = timezone.now().date()
        attendance_id = request.data.get('attendance_id')
        clock_out_selfie = request.FILES.get('clock_out_selfie')
        clock_out_location = request.data.get('clock_out_location')
        tasks_completed = request.data.get('tasks_completed', '[]')
        device_token = request.data.get('device_token')
        clock_out_time = timezone.now()
        # [{
            # "project_id": 1,
            # "tasks": ["Task 1", "Task 2"]
        # }]
        
        # Get today's attendance record
        attendance = DailyAttendance.objects.get(id=attendance_id)
        if attendance.is_clocked_out:
            return ApiResponse.error(
                message="Employee already clocked out",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        if clock_out_selfie:
            uploader = S3DocumentUploader()
            success, result = uploader.upload_document(
                email_id=request.user.email_id,
                document_collection="selfies",
                other_prefix=attendance.date,
                document_type="clock_out",
                file=clock_out_selfie,
            )
            if not success:
                pass
        else:
            result = None
        
        # Close all open tasks
        open_tasks = DailyTask.objects.filter(employee=attendance.employee, attendance=attendance, end_time=None)
        for task in open_tasks:
            task.end_time = timezone.now()
            task.save()
        
        # Update tasks with completed tasks if project_id is provided
        print(tasks_completed, type(tasks_completed))
        json_str = json.loads(tasks_completed)
        print(json_str, type(json_str))
        for task_data in json_str:
            project_id = task_data.get('project_id')
            tasks = task_data.get('tasks')
            print(project_id, tasks)
            project = Project.objects.get(id=project_id)
            tasks_records = DailyTask.objects.filter(employee=attendance.employee, attendance=attendance, project=project)
            for task_record in tasks_records:
                task_record.tasks_completed = tasks
                task_record.save()
        
        # Update attendance record
        attendance.clock_out_time = clock_out_time
        attendance.clock_out_location = clock_out_location
        attendance.is_clocked_out = True
        attendance.clock_out_selfie = result
        attendance.save()
        
        serializer = DailyAttendanceSerializer(attendance, context={'request': request})
        return ApiResponse.success(
            data=serializer.data,
            message="Clock out successful"
        )
        
    except DailyAttendance.DoesNotExist:
        return ApiResponse.not_found("No active attendance record found for today")
    except Project.DoesNotExist:
        return ApiResponse.not_found("Project not found")
    except Exception as e:
        return ApiResponse.error(
            message=str(e),
            status_code=status.HTTP_400_BAD_REQUEST
        )

# Daily Attendance Views

@swagger_auto_schema(
    method='get',
    operation_description="Get comprehensive list of attendance records with boolean flags (is_late, is_wfh, is_leave, is_compoff, is_absent)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('date', openapi.IN_QUERY, description="Filter by date", type=openapi.TYPE_STRING, format='date'),
        openapi.Parameter('month', openapi.IN_QUERY, description="Filter by month (1-12)", type=openapi.TYPE_INTEGER),
        openapi.Parameter('year', openapi.IN_QUERY, description="Filter by year", type=openapi.TYPE_INTEGER),
        openapi.Parameter('is_clocked_out', openapi.IN_QUERY, description="Filter by clock out status", type=openapi.TYPE_BOOLEAN),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email (HR only)", type=openapi.TYPE_STRING),
        openapi.Parameter('is_late', openapi.IN_QUERY, description="Filter by late arrival status", type=openapi.TYPE_BOOLEAN),
        openapi.Parameter('is_leave', openapi.IN_QUERY, description="Filter by leave status", type=openapi.TYPE_BOOLEAN),
        openapi.Parameter('is_wfh', openapi.IN_QUERY, description="Filter by WFH status", type=openapi.TYPE_BOOLEAN),
        openapi.Parameter('is_absent', openapi.IN_QUERY, description="Filter by absent status", type=openapi.TYPE_BOOLEAN),
    ],
    responses={
        200: openapi.Response(
            description="Attendance records retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Attendance records retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 25,
                        "page": 1,
                        "page_size": 20,
                        "total_pages": 2,
                        "has_next": True,
                        "has_previous": False,
                        "results": [
                            {
                                "id": 15,
                                "date": "2024-01-15",
                                "clock_in_time": "09:00:00",
                                "clock_out_time": "18:00:00",
                                "total_working_hours": 8.0,
                                "location": "Office",
                                "status": "completed",
                                "is_late": False,
                                "is_wfh": False,
                                "is_leave": False,
                                "is_compoff": False,
                                "is_absent": False
                            },
                            {
                                "date": "2024-01-14",
                                "clock_in_time": None,
                                "clock_out_time": None,
                                "total_working_hours": 0,
                                "location": None,
                                "status": "no_attendance",
                                "is_late": False,
                                "is_wfh": False,
                                "is_leave": True,
                                "is_compoff": False,
                                "is_absent": False,
                                "leave_type": "SL",
                                "leave_type_display": "Sick Leave",
                                "leave_description": "Fever"
                            },
                            {
                                "date": "2024-01-13",
                                "clock_in_time": None,
                                "clock_out_time": None,
                                "total_working_hours": 0,
                                "location": None,
                                "status": "absent",
                                "is_late": False,
                                "is_wfh": False,
                                "is_leave": False,
                                "is_compoff": False,
                                "is_absent": True
                            }
                        ],
                        "statistics": {
                            "total_entries": 25,
                            "present_days": 15,
                            "late_arrivals": 2,
                            "leave_days": 3,
                            "wfh_days": 2,
                            "compoff_days": 0,
                            "absent_days": 5,
                            "total_working_hours": 120.5,
                            "month": 1,
                            "year": 2024
                        }
                    }
                }
            }
        ),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_attendance(request):
    """Get paginated list of attendance records with boolean flags for special conditions"""
    # Get query parameters
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    date_filter = request.GET.get('date')
    month = request.GET.get('month')
    year = request.GET.get('year')
    is_clocked_out = request.GET.get('is_clocked_out')
    email_id = request.GET.get('email_id')
    is_late = request.GET.get('is_late')
    is_leave = request.GET.get('is_leave')
    is_wfh = request.GET.get('is_wfh')
    is_absent = request.GET.get('is_absent')
    
    today = timezone.now().date()
    
    try:
        # Get employee
        if email_id:
            employee = Employee.objects.get(email=email_id)
            # Check permission for HR managers
            requesting_employee = Employee.objects.get(email=request.user.email_id)
            if not requesting_employee.is_hr_manager and requesting_employee != employee:
                return ApiResponse.error(
                    message="Permission denied. You can only view your own attendance or be an HR manager",
                    status_code=status.HTTP_403_FORBIDDEN
                )
        else:
            employee = Employee.objects.get(email=request.user.email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Determine date range
    data_limited_to_today = False
    if date_filter:
        try:
            filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
            if filter_date > today:
                return ApiResponse.error(
                    message=f"Cannot view attendance for future date. Today is {today.isoformat()}",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            start_date = filter_date
            end_date = filter_date
        except ValueError:
            return ApiResponse.error(
                message="Invalid date format. Use YYYY-MM-DD",
                status_code=status.HTTP_400_BAD_REQUEST
            )
    elif month and year:
        try:
            month = int(month)
            year = int(year)
            if month < 1 or month > 12:
                raise ValueError()
            start_date = datetime(year, month, 1).date()
            if month == 12:
                requested_end_date = datetime(year + 1, 1, 1).date() - timedelta(days=1)
            else:
                requested_end_date = datetime(year, month + 1, 1).date() - timedelta(days=1)
            end_date = min(requested_end_date, today)  # Cap at today
            data_limited_to_today = end_date < requested_end_date
        except ValueError:
            return ApiResponse.error(
                message="Invalid month or year. Month must be between 1-12",
                status_code=status.HTTP_400_BAD_REQUEST
            )
    else:
        # Default to current month
        start_date = datetime(today.year, today.month, 1).date()
        if today.month == 12:
            requested_end_date = datetime(today.year + 1, 1, 1).date() - timedelta(days=1)
        else:
            requested_end_date = datetime(today.year, today.month + 1, 1).date() - timedelta(days=1)
        end_date = min(requested_end_date, today)  # Cap at today
        data_limited_to_today = end_date < requested_end_date
    
    # Get all attendance entries using the helper function
    all_entries = get_attendance_entries_for_period(employee, start_date, end_date)
    
    # Apply filters
    if is_clocked_out is not None:
        is_clocked_out = is_clocked_out.lower() == 'true'
        if is_clocked_out:
            all_entries = [entry for entry in all_entries if entry.get('status') == 'completed']
        else:
            all_entries = [entry for entry in all_entries if entry.get('status') != 'completed']
    
    if is_late is not None:
        is_late = is_late.lower() == 'true'
        all_entries = [entry for entry in all_entries if entry['is_late'] == is_late]
    
    if is_leave is not None:
        is_leave = is_leave.lower() == 'true'
        all_entries = [entry for entry in all_entries if entry['is_leave'] == is_leave]
    
    if is_wfh is not None:
        is_wfh = is_wfh.lower() == 'true'
        all_entries = [entry for entry in all_entries if entry['is_wfh'] == is_wfh]
    
    if is_absent is not None:
        is_absent = is_absent.lower() == 'true'
        all_entries = [entry for entry in all_entries if entry['is_absent'] == is_absent]
    
    # Sort by date (newest first)
    all_entries.sort(key=lambda x: x['date'], reverse=True)
    
    # Manual pagination
    total_count = len(all_entries)
    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    paginated_entries = all_entries[start_index:end_index]
    
    # Calculate pagination info
    total_pages = (total_count + page_size - 1) // page_size
    has_next = page < total_pages
    has_previous = page > 1
    
    # Build pagination response
    pagination_data = {
        'count': total_count,
        'page': page,
        'page_size': page_size,
        'total_pages': total_pages,
        'has_next': has_next,
        'has_previous': has_previous,
        'results': paginated_entries,
        'data_limited_to_today': data_limited_to_today
    }
    
    # Calculate statistics if month and year are provided
    if month and year:
        summary = get_monthly_attendance_summary(employee, int(year), int(month))
        statistics = {
            'total_entries': summary['total_entries'],
            'present_days': summary['present_days'],
            'late_arrivals': summary['late_arrivals'],
            'leave_days': summary['leave_days'],
            'wfh_days': summary['wfh_days'],
            'compoff_days': summary['compoff_days'],
            'absent_days': summary['absent_days'],
            'total_working_hours': summary['total_working_hours'],
            'month': month,
            'year': year,
            'data_up_to_date': summary['data_up_to_date']
        }
        pagination_data['statistics'] = statistics
    
    # Add informational message if data was capped
    message = "Attendance records retrieved successfully"
    if data_limited_to_today:
        message += f" (data limited to today: {today.isoformat()})"
    
    return ApiResponse.success(
        data=pagination_data,
        message=message
    )

@swagger_auto_schema(
    method='put',
    operation_description="Update attendance record (clock out)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['clock_out_time', 'clock_out_location', 'clock_out_selfie'],
        properties={
            'clock_out_time': openapi.Schema(type=openapi.TYPE_STRING, format='date-time', description="Clock out time"),
            'clock_out_location': openapi.Schema(type=openapi.TYPE_STRING, description="Clock out location"),
            'clock_out_selfie': openapi.Schema(type=openapi.TYPE_STRING, format='binary', description="Clock out selfie image"),
            'notes': openapi.Schema(type=openapi.TYPE_STRING, description="Additional notes")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Attendance record updated successfully",
            schema=DailyAttendanceSerializer
        ),
        404: openapi.Response(description="Attendance record not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_attendance(request, attendance_id):
    """Update attendance record (clock out)"""
    try:
        attendance = DailyAttendance.objects.get(id=attendance_id)
    except DailyAttendance.DoesNotExist:
        return ApiResponse.not_found("Attendance record not found")
    
    if attendance.is_clocked_out:
        return ApiResponse.error(
            message="Already clocked out",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    serializer = DailyAttendanceSerializer(attendance, data=request.data, partial=True, context={'request': request})
    
    if serializer.is_valid():
        attendance = serializer.save(is_clocked_out=True)
        return ApiResponse.success(
            data=serializer.data,
            message="Attendance record updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

# Daily Task Views

@swagger_auto_schema(
    method='post',
    operation_description="Create a new daily task record",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['project', 'epic', 'start_time'],
        properties={
            'project': openapi.Schema(type=openapi.TYPE_INTEGER, description="Project ID"),
            'epic': openapi.Schema(type=openapi.TYPE_INTEGER, description="Epic ID"),
            'tasks_completed': openapi.Schema(
                type=openapi.TYPE_ARRAY,
                items=openapi.Schema(type=openapi.TYPE_STRING),
                description="List of completed tasks",
            ),
            'attendance_id': openapi.Schema(type=openapi.TYPE_INTEGER, description="Attendance ID"),
            'notes': openapi.Schema(type=openapi.TYPE_STRING, description="Additional notes")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Task record created successfully",
            schema=DailyTaskSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="No active attendance record found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_task(request):
    """Create a new daily task record"""
    try:
        # Get current date
        current_date = timezone.now().date()
        
        # Get active attendance record
        attendance = DailyAttendance.objects.get(
            id=request.data.get('attendance_id')
        )
        
        if not attendance:
            return ApiResponse.not_found("Attendance record not found")
        
        if attendance.is_clocked_out:
            return ApiResponse.error(
                message="Employee already clocked out",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate project and epic
        project = Project.objects.get(id=request.data.get('project'))
        epic = Epic.objects.get(id=request.data.get('epic'))
        employee = Employee.objects.get(email=request.user.email_id)
        open_tasks = DailyTask.objects.filter(employee=employee, attendance=attendance, end_time=None)
        
        for task in open_tasks:
            task.end_time = timezone.now()
            task.save()
        
        # Create task record
        task = DailyTask.objects.create(
            employee=employee,
            attendance=attendance,  # Link to attendance record
            date=current_date,
            project=project,
            epic=epic,
            # tasks_completed=request.data.get('tasks_completed', []),
            start_time=timezone.now(),
            notes=request.data.get('notes')
        )
        
        serializer = DailyTaskSerializer(task, context={'request': request})
        return ApiResponse.created(
            data=serializer.data,
            message="Task record created successfully"
        )
        
    except DailyAttendance.DoesNotExist:
        return ApiResponse.not_found("No active attendance record found for today")
    except Project.DoesNotExist:
        return ApiResponse.not_found("Project not found")
    except Epic.DoesNotExist:
        return ApiResponse.not_found("Epic not found")
    except Exception as e:
        return ApiResponse.error(
            message=str(e),
            status_code=status.HTTP_400_BAD_REQUEST
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of task records with pagination and filtering",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('date', openapi.IN_QUERY, description="Filter by date", type=openapi.TYPE_STRING, format='date'),
        openapi.Parameter('project_id', openapi.IN_QUERY, description="Filter by project ID", type=openapi.TYPE_INTEGER),
        openapi.Parameter('epic_id', openapi.IN_QUERY, description="Filter by epic ID", type=openapi.TYPE_INTEGER),
        openapi.Parameter('email_id', openapi.IN_QUERY, description="Filter by employee email", type=openapi.TYPE_STRING),
        openapi.Parameter('attendance_id', openapi.IN_QUERY, description="Filter by attendance ID", type=openapi.TYPE_INTEGER),
    ],
    responses={
        200: openapi.Response(
            description="Task records retrieved successfully",
            schema=DailyTaskListSerializer(many=True)
        ),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_tasks(request):
    """Get paginated list of task records with filtering options"""
    # Get query parameters
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 20))
    date_filter = request.GET.get('date')
    project_id = request.GET.get('project_id')
    epic_id = request.GET.get('epic_id')
    email_id = request.GET.get('email_id')
    attendance_id = request.GET.get('attendance_id')
    
    # Build query
    queryset = DailyTask.objects.all()
    
    # Apply filters
    if date_filter:
        queryset = queryset.filter(date=date_filter)
    
    if project_id:
        queryset = queryset.filter(project_id=project_id)
    
    if epic_id:
        queryset = queryset.filter(epic_id=epic_id)
    
    if email_id:
        queryset = queryset.filter(employee__email=email_id)
        
    if attendance_id:
        queryset = queryset.filter(attendance_id=attendance_id)
    
    # Order by date and time
    queryset = queryset.order_by('-date', '-start_time')
    
    # Paginate
    paginator = Paginator(queryset, page_size)
    
    try:
        tasks_page = paginator.page(page)
    except:
        return ApiResponse.error(
            message="Invalid page number",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Serialize data
    serializer = DailyTaskListSerializer(tasks_page.object_list, many=True)
    
    # Build pagination response
    pagination_data = {
        'count': paginator.count,
        'page': page,
        'page_size': page_size,
        'total_pages': paginator.num_pages,
        'has_next': tasks_page.has_next(),
        'has_previous': tasks_page.has_previous(),
        'results': serializer.data
    }
    
    return ApiResponse.success(
        data=pagination_data,
        message="Task records retrieved successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get list of tasks grouped by project for a specific attendance record",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('date', openapi.IN_QUERY, description="Filter by date", type=openapi.TYPE_STRING, format='date'),
    ],
    responses={
        200: openapi.Response(
            description="Tasks retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Tasks retrieved successfully",
                    "success": True,
                    "data": {
                        "tasks": [
                            {
                                "project_name": "Project Alpha",
                                "total_time_spent": 4.5,
                                "tasks": [
                                    {
                                        "id": 1,
                                        "task_name": "Task 1",
                                        "description": "Description 1",
                                        "start_time": "2024-03-20T09:30:00Z",
                                        "end_time": "2024-03-20T11:30:00Z",
                                        "time_spent": 2.0
                                    },
                                    {
                                        "id": 2,
                                        "task_name": "Task 2",
                                        "description": "Description 2",
                                        "start_time": "2024-03-20T14:00:00Z",
                                        "end_time": "2024-03-20T16:00:00Z",
                                        "time_spent": 2.5
                                    }
                                ]
                            }
                        ]
                    }
                }
            }
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_grouped_tasks(request):
    """
    Get list of tasks for a specific attendance record, grouped by project
    
    Features:
    - Groups tasks by project
    - Sums up total time spent per project
    - Returns tasks under each project
    """
    # email_id = request.query_params.get('email_id')
    email_id = request.user.email_id
    # attendance_id = request.query_params.get('attendance_id')
    date_filter = request.GET.get('date')
    attendance_id = DailyAttendance.objects.filter(employee__email=email_id, date=date_filter).first().id
    
    if not email_id or not attendance_id:
        return ApiResponse.error(
            message="Validation error",
            errors={
                "email_id": ["This field is required."] if not email_id else None,
                "attendance_id": ["This field is required."] if not attendance_id else None
            },
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    try:
        attendance = DailyAttendance.objects.get(id=attendance_id, employee=employee)
    except DailyAttendance.DoesNotExist:
        return ApiResponse.not_found("Attendance record not found")
    
    # Get tasks for this attendance record
    tasks = DailyTask.objects.filter(attendance=attendance)
    
    # Group tasks by project
    project_tasks = {}
    for task in tasks:
        project_name = task.project.name if task.project else "No Project"
        
        if project_name not in project_tasks:
            project_tasks[project_name] = {
                "project_name": project_name,
                "total_time_spent": 0,
                "tasks": []
            }
        
        # Calculate time spent in hours
        time_spent = 0
        if task.start_time and task.end_time:
            duration = task.end_time - task.start_time
            time_spent = duration.total_seconds() / 3600  # Convert to hours
        
        project_tasks[project_name]["total_time_spent"] += time_spent
        
        appended_tasks = project_tasks[project_name]["tasks"]
        new_tasks = task.tasks_completed
        if new_tasks:
            appended_tasks += new_tasks
        project_tasks[project_name]["tasks"] = appended_tasks
    
    # Convert to list and round total time spent
    response_data = {
        "tasks": [
            {
                **project,
                "total_time_spent": round(project["total_time_spent"], 2)
            }
            for project in project_tasks.values()
        ]
    }
    
    return ApiResponse.success(
        data=response_data,
        message="Tasks retrieved successfully"
    )

@swagger_auto_schema(
    method='put',
    operation_description="Update task record (end task)",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['end_time'],
        properties={
            'end_time': openapi.Schema(type=openapi.TYPE_STRING, format='date-time', description="Task end time"),
            'notes': openapi.Schema(type=openapi.TYPE_STRING, description="Additional notes")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Task record updated successfully",
            schema=DailyTaskSerializer
        ),
        404: openapi.Response(description="Task record not found"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_task(request, task_id):
    """Update task record (end task)"""
    try:
        task = DailyTask.objects.get(id=task_id)
    except DailyTask.DoesNotExist:
        return ApiResponse.not_found("Task record not found")
    
    if task.end_time:
        return ApiResponse.error(
            message="Task already ended",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    serializer = DailyTaskSerializer(task, data=request.data, partial=True, context={'request': request})
    
    if serializer.is_valid():
        task = serializer.save()
        return ApiResponse.success(
            data=serializer.data,
            message="Task record updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='get',
    operation_description="Get last 7 days of hourly work data",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email ID",
            type=openapi.TYPE_STRING,
            required=True,
            example=EXAMPLE_EMAIL
        )
    ],
    responses={
        200: openapi.Response(
            description="Weekly hours data retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Weekly hours data retrieved successfully",
                    "success": True,
                    "data": {
                        "weekly_hours": [
                            {
                                "date": "2024-03-20",
                                "total_hours": 8.5,
                                "projects": [
                                    {
                                        "project_name": "Project Alpha",
                                        "hours": 4.5,
                                        "tasks": [
                                            {
                                                "task_name": "Task 1",
                                                "hours": 2.5
                                            },
                                            {
                                                "task_name": "Task 2",
                                                "hours": 2.0
                                            }
                                        ]
                                    },
                                    {
                                        "project_name": "Project Beta",
                                        "hours": 4.0,
                                        "tasks": [
                                            {
                                                "task_name": "Task 3",
                                                "hours": 4.0
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        "total_weekly_hours": 42.5
                    }
                }
            }
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_weekly_attendance(request):
    """
    Get last 7 days of hourly work data for an employee
    
    Features:
    - Returns daily hours worked for the last 7 days
    - Breaks down hours by project and tasks
    - Includes total weekly hours
    """
    email_id = request.query_params.get('email_id')
    
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={
                "email_id": ["This field is required."]
            },
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Calculate date range (last 7 days)
    end_date = timezone.now().date()
    start_date = end_date - timezone.timedelta(days=6)  # 7 days including today
    
    # Get all attendance records for the date range
    attendance_records = DailyAttendance.objects.filter(
        employee=employee,
        date__gte=start_date,
        date__lte=end_date,
        is_clocked_out=True  # Only include completed attendance
    ).order_by('date')
    
    response_object = {
        "weekly_hours": [],
        "total_weekly_hours": 0
    }
    for attendance in attendance_records:
        daily_obj = {}
        day_of_week = attendance.clock_in_time.strftime('%A')  # Gets full day name like 'Monday'
        daily_obj['date'] = day_of_week
        daily_obj['total_hours'] = attendance.total_working_hours
        response_object['total_weekly_hours'] += attendance.total_working_hours
        response_object['weekly_hours'].append(daily_obj)
    
    response_object['total_weekly_hours'] = round(response_object['total_weekly_hours']/len(response_object['weekly_hours']), 2)
        
    return ApiResponse.success(
        data=response_object,
        message="Weekly hours data retrieved successfully"
    )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_clock_in_data(request):
    """
    Get clock in data for an employee
    """
    email_id = request.query_params.get('email_id')
    
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={
                "email_id": ["This field is required."]
            },
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    start_date = timezone.now().date()
    end_date = start_date
    
    entries = get_attendance_entries_for_period(employee, start_date, end_date)
    
    return ApiResponse.success(
        data=entries, 
        message="Clock in data retrieved successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get clock-in status and related information for today",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email ID (optional, defaults to logged-in user)",
            type=openapi.TYPE_STRING,
            required=False,
            example=EXAMPLE_EMAIL
        )
    ],
    responses={
        200: openapi.Response(
            description="Clock-in status retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Clock-in status retrieved successfully",
                    "success": True,
                    "data": {
                        "is_clocked_in": True,
                        "clock_in_time": "2024-01-15T09:00:00Z",
                        "clock_in_location": "Office",
                        "lat_long": "12.9716,77.5946",
                        "attendance_id": 123,
                        "location_name": "Main Office",
                        "tasks": [
                            {
                                "id": 1,
                                "project_name": "Project Alpha",
                                "epic_name": "Epic 1",
                                "tasks_completed": ["Task 1", "Task 2"],
                                "start_time": "2024-01-15T09:00:00Z",
                                "end_time": "2024-01-15T11:00:00Z",
                                "total_time_spent": 2.0,
                                "notes": "Completed initial setup"
                            }
                        ],
                        "total_tasks": 1,
                        "total_time_spent": 2.0
                    }
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_clock_in_status(request):
    """
    Get clock-in status and related information for today
    """
    try:
        # Get employee email (default to logged-in user if not provided)
        email_id = request.query_params.get('email_id', request.user.email_id)
        
        # Validate employee exists
        try:
            employee = Employee.objects.get(email=email_id)
        except Employee.DoesNotExist:
            return ApiResponse.not_found("Employee not found")
        
        # Get current date
        current_date = timezone.now().date()
        
        # Check if employee has clocked in today
        try:
            attendance = DailyAttendance.objects.get(
                employee=employee,
                date=current_date
            )
            
            # Employee has clocked in
            is_clocked_in = True
            clock_in_time = attendance.clock_in_time
            clock_in_location = attendance.clock_in_location
            lat_long = attendance.lat_long
            attendance_id = attendance.id
            
            # Get related tasks for this attendance
            tasks = DailyTask.objects.filter(
                attendance=attendance
            ).select_related('project', 'epic').order_by('start_time')
            
            # Format task data
            task_data = []
            total_time_spent = 0.0
            
            for task in tasks:
                task_info = {
                    "id": task.id,
                    "project_id": task.project.id,
                    "project_name": task.project.name,
                    "epic_id": task.epic.id,
                    "epic_name": task.epic.name,
                    "tasks_completed": task.tasks_completed or [],
                    "start_time": task.start_time,
                    "end_time": task.end_time,
                    "total_time_spent": float(task.total_time_spent) if task.total_time_spent else 0.0,
                    "notes": task.notes
                }
                task_data.append(task_info)
                total_time_spent += task_info["total_time_spent"]
            
            response_data = {
                "is_clocked_in": is_clocked_in,
                "clock_in_time": clock_in_time,
                "clock_in_location": clock_in_location,
                "lat_long": lat_long,
                "attendance_id": attendance_id,
                "tasks": task_data,
                "total_tasks": len(task_data),
                "total_time_spent": round(total_time_spent, 2)
            }
            
        except DailyAttendance.DoesNotExist:
            # Employee has not clocked in today
            response_data = {
                "is_clocked_in": False,
                "clock_in_time": None,
                "clock_in_location": None,
                "lat_long": None,
                "attendance_id": None,
                "tasks": [],
                "total_tasks": 0,
                "total_time_spent": 0.0
            }
        
        return ApiResponse.success(
            data=response_data,
            message="Clock-in status retrieved successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"Error retrieving clock-in status: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

def get_attendance_entries_for_period(employee, start_date, end_date):
    """
    Get all attendance-related entries for an employee within a date range
    Enhanced with boolean flags for leave, WFH, late arrival, and absent status
    Note: end_date is capped at today's date to avoid showing future entries
    """
    # Cap end_date at today to avoid showing future entries
    today = timezone.now().date()
    end_date = min(end_date, today)
    
    # If start_date is after today, return empty list
    if start_date > today:
        return []
    
    entries = []
    
    # Get regular attendance records
    attendance_records = DailyAttendance.objects.filter(
        employee=employee,
        date__gte=start_date,
        date__lte=end_date
    ).order_by('date')
    
    # Get approved leaves for the period (only up to today)
    approved_leaves = Leave.objects.filter(
        employee=employee,
        status='approved',
        from_date__lte=end_date,
        to_date__gte=start_date
    )
    
    # Get approved WFH requests for the period (only up to today)
    approved_wfh = WFH.objects.filter(
        employee=employee,
        status='approved',
        from_date__lte=end_date,
        to_date__gte=start_date
    )
    
    # Get approved comp-off requests for the period (only up to today)
    approved_compoff = CompOffCreditRequest.objects.filter(
        employee=employee,
        status='approved',
        date__gte=start_date,
        date__lte=end_date
    )
    
    # Create date-wise lookup for leaves, WFH, and comp-offs (only up to today)
    leave_dates = set()
    wfh_dates = set()
    compoff_dates = set()
    
    for leave in approved_leaves:
        current_date = max(leave.from_date, start_date)
        end_leave_date = min(min(leave.to_date, end_date), today)  # Cap at today
        while current_date <= end_leave_date:
            leave_dates.add(current_date)
            current_date += timedelta(days=1)
    
    for wfh in approved_wfh:
        current_date = max(wfh.from_date, start_date)
        end_wfh_date = min(min(wfh.to_date, end_date), today)  # Cap at today
        while current_date <= end_wfh_date:
            wfh_dates.add(current_date)
            current_date += timedelta(days=1)
    
    for compoff in approved_compoff:
        if compoff.date <= today:  # Only include comp-offs up to today
            compoff_dates.add(compoff.date)
    
    # Get dates that already have attendance records
    attendance_dates = {attendance.date for attendance in attendance_records}
    
    # Process attendance records
    for attendance in attendance_records:
        entry = {
            'id': attendance.id,
            'date': attendance.date.isoformat(),
            'clock_in_time': attendance.clock_in_time.strftime('%H:%M:%S') if attendance.clock_in_time else None,
            'clock_out_time': attendance.clock_out_time.strftime('%H:%M:%S') if attendance.clock_out_time else None,
            'total_working_hours': float(attendance.total_working_hours) if attendance.total_working_hours else 0,
            'location': attendance.clock_in_location,
            'notes': attendance.notes,
            'status': 'completed' if attendance.is_clocked_out else 'active',
            'is_clocked_out': attendance.is_clocked_out
        }
        
        # Check if late arrival (after 10:30 AM)
        entry['is_late'] = False
        if attendance.clock_in_time:
            scheduled_time = attendance.clock_in_time.replace(hour=10, minute=30, second=0, microsecond=0)
            if attendance.clock_in_time > scheduled_time:
                entry['is_late'] = True
                late_minutes = int((attendance.clock_in_time - scheduled_time).total_seconds() / 60)
                entry['late_minutes'] = late_minutes
        
        # Check if on approved leave
        entry['is_leave'] = attendance.date in leave_dates
        
        # Check if on approved WFH
        entry['is_wfh'] = attendance.date in wfh_dates
        
        # Check if comp-off day
        entry['is_compoff'] = attendance.date in compoff_dates
        
        # Since there's an attendance record, not absent
        entry['is_absent'] = False
        
        # Add leave details if on leave
        if entry['is_leave']:
            leave_request = approved_leaves.filter(
                from_date__lte=attendance.date,
                to_date__gte=attendance.date
            ).first()
            if leave_request:
                entry['leave_type'] = leave_request.leave_type
                entry['leave_type_display'] = leave_request.get_leave_type_display()
                entry['leave_description'] = leave_request.description
                entry['leave_request_id'] = leave_request.id
        
        # Add WFH details if on WFH
        if entry['is_wfh']:
            wfh_request = approved_wfh.filter(
                from_date__lte=attendance.date,
                to_date__gte=attendance.date
            ).first()
            if wfh_request:
                entry['wfh_description'] = wfh_request.description
                entry['wfh_request_id'] = wfh_request.id
        
        # Add comp-off details if comp-off day
        if entry['is_compoff']:
            compoff_request = approved_compoff.filter(date=attendance.date).first()
            if compoff_request:
                entry['compoff_description'] = compoff_request.reason
                entry['compoff_request_id'] = compoff_request.id
        
        entries.append(entry)
    
    # Generate entries for all weekdays (Monday=0 to Saturday=5) in the date range
    all_weekdays = set()
    current_date = start_date
    while current_date <= end_date:
        # Only include weekdays (Monday to Friday)
        if current_date.weekday() < 6:
            all_weekdays.add(current_date)
        current_date += timedelta(days=1)
    
    # Process weekdays without attendance records
    for date in all_weekdays - attendance_dates:
        entry = {
            'date': date.isoformat(),
            'clock_in_time': None,
            'clock_out_time': None,
            'total_working_hours': 0,
            'location': None,
            'notes': None,
            'is_late': False,
            'is_leave': date in leave_dates,
            'is_wfh': date in wfh_dates,
            'is_compoff': date in compoff_dates,
        }
        
        # Determine if absent: no attendance AND no approved requests
        entry['is_absent'] = not (entry['is_leave'] or entry['is_wfh'] or entry['is_compoff'])
        
        # Set status based on conditions
        if entry['is_absent']:
            entry['status'] = 'absent'
        else:
            entry['status'] = 'no_attendance'  # Has approved request but no clock-in
        
        # Add leave details if on leave
        if entry['is_leave']:
            leave_request = approved_leaves.filter(
                from_date__lte=date,
                to_date__gte=date
            ).first()
            if leave_request:
                entry['leave_type'] = leave_request.leave_type
                entry['leave_type_display'] = leave_request.get_leave_type_display()
                entry['leave_description'] = leave_request.description
                entry['leave_request_id'] = leave_request.id
        
        # Add WFH details if on WFH
        if entry['is_wfh']:
            wfh_request = approved_wfh.filter(
                from_date__lte=date,
                to_date__gte=date
            ).first()
            if wfh_request:
                entry['wfh_description'] = wfh_request.description
                entry['wfh_request_id'] = wfh_request.id
                entry['location'] = 'Work From Home'
        
        # Add comp-off details if comp-off day
        if entry['is_compoff']:
            compoff_request = approved_compoff.filter(date=date).first()
            if compoff_request:
                entry['compoff_description'] = compoff_request.reason
                entry['compoff_request_id'] = compoff_request.id
        
        entry['is_clocked_out'] = False
        entries.append(entry)
    
    # Sort entries by date
    entries.sort(key=lambda x: x['date'])
    
    return entries

def get_monthly_attendance_summary(employee, year, month):
    """
    Get monthly attendance summary including all types of entries
    Note: Only includes data up to today's date
    """
    start_date = datetime(year, month, 1).date()
    if month == 12:
        end_date = datetime(year + 1, 1, 1).date() - timedelta(days=1)
    else:
        end_date = datetime(year, month + 1, 1).date() - timedelta(days=1)
    
    # Cap end_date at today
    today = timezone.now().date()
    end_date = min(end_date, today)
    
    entries = get_attendance_entries_for_period(employee, start_date, end_date)
    
    summary = {
        'total_entries': len(entries),
        'present_days': len([e for e in entries if e.get('clock_in_time') and not e['is_leave'] and not e['is_wfh'] and not e['is_compoff']]),
        'late_arrivals': len([e for e in entries if e['is_late']]),
        'leave_days': len([e for e in entries if e['is_leave']]),
        'wfh_days': len([e for e in entries if e['is_wfh']]),
        'compoff_days': len([e for e in entries if e['is_compoff']]),
        'absent_days': len([e for e in entries if e['is_absent']]),
        'total_working_hours': sum([e.get('total_working_hours', 0) for e in entries]),
        'month': month,
        'year': year,
        'data_up_to_date': today.isoformat()  # Indicate data cutoff date
    }
    
    return summary

@swagger_auto_schema(
    method='get',
    operation_description="Get attendance calendar view with boolean flags for special conditions (late arrival, WFH, leave, absent)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'start_date',
            openapi.IN_QUERY,
            description="Start date for calendar view (YYYY-MM-DD)",
            type=openapi.TYPE_STRING,
            format='date',
            required=False
        ),
        openapi.Parameter(
            'end_date',
            openapi.IN_QUERY,
            description="End date for calendar view (YYYY-MM-DD)",
            type=openapi.TYPE_STRING,
            format='date',
            required=False
        ),
        openapi.Parameter(
            'month',
            openapi.IN_QUERY,
            description="Filter by month (1-12) - alternative to date range",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'year',
            openapi.IN_QUERY,
            description="Filter by year - alternative to date range",
            type=openapi.TYPE_INTEGER,
            required=False
        ),
        openapi.Parameter(
            'employee_id',
            openapi.IN_QUERY,
            description="Employee ID (HR only - defaults to logged-in user)",
            type=openapi.TYPE_INTEGER,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Attendance calendar retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Attendance calendar retrieved successfully",
                    "success": True,
                    "data": {
                        "attendance_entries": [
                            {
                                "id": 1,
                                "date": "2024-01-15",
                                "clock_in_time": "09:00:00",
                                "clock_out_time": "18:00:00",
                                "total_working_hours": 8.0,
                                "location": "Office",
                                "notes": None,
                                "status": "completed",
                                "is_late": False,
                                "is_wfh": False,
                                "is_leave": False,
                                "is_compoff": False,
                                "is_absent": False
                            },
                            {
                                "id": 2,
                                "date": "2024-01-16",
                                "clock_in_time": "11:00:00",
                                "clock_out_time": "18:00:00",
                                "total_working_hours": 7.0,
                                "location": "Office",
                                "notes": None,
                                "status": "completed",
                                "is_late": True,
                                "late_minutes": 30,
                                "is_wfh": False,
                                "is_leave": False,
                                "is_compoff": False,
                                "is_absent": False
                            },
                            {
                                "date": "2024-01-17",
                                "clock_in_time": None,
                                "clock_out_time": None,
                                "total_working_hours": 0,
                                "location": None,
                                "notes": None,
                                "status": "no_attendance",
                                "is_late": False,
                                "is_wfh": False,
                                "is_leave": True,
                                "is_compoff": False,
                                "is_absent": False,
                                "leave_type": "SL",
                                "leave_type_display": "Sick Leave",
                                "leave_description": "Fever",
                                "leave_request_id": 123
                            },
                            {
                                "id": 3,
                                "date": "2024-01-18",
                                "clock_in_time": "09:30:00",
                                "clock_out_time": "17:30:00",
                                "total_working_hours": 8.0,
                                "location": "Work From Home",
                                "notes": "Working remotely",
                                "status": "completed",
                                "is_late": False,
                                "is_wfh": True,
                                "is_leave": False,
                                "is_compoff": False,
                                "is_absent": False,
                                "wfh_description": "Remote work approved",
                                "wfh_request_id": 456
                            },
                            {
                                "date": "2024-01-19",
                                "clock_in_time": None,
                                "clock_out_time": None,
                                "total_working_hours": 0,
                                "location": None,
                                "notes": None,
                                "status": "absent",
                                "is_late": False,
                                "is_wfh": False,
                                "is_leave": False,
                                "is_compoff": False,
                                "is_absent": True
                            }
                        ],
                        "date_range": {
                            "start_date": "2024-01-15",
                            "end_date": "2024-01-19"
                        },
                        "summary": {
                            "total_entries": 5,
                            "present_days": 2,
                            "late_arrivals": 1,
                            "leave_days": 1,
                            "wfh_days": 1,
                            "compoff_days": 0,
                            "absent_days": 1,
                            "total_working_hours": 23.0
                        }
                    }
                }
            }
        ),
        400: openapi.Response(description="Invalid parameters"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def attendance_calendar(request):
    """Get comprehensive attendance calendar view with all entry types"""
    try:
        # Get query parameters
        start_date_str = request.GET.get('start_date')
        end_date_str = request.GET.get('end_date')
        month = request.GET.get('month')
        year = request.GET.get('year')
        employee_id = request.GET.get('employee_id')
        
        today = timezone.now().date()
        
        # Determine date range
        if start_date_str and end_date_str:
            try:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                requested_end_date = end_date  # Keep track of original request
                end_date = min(end_date, today)  # Cap at today
            except ValueError:
                return ApiResponse.error(
                    message="Invalid date format. Use YYYY-MM-DD",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
        elif month and year:
            try:
                month = int(month)
                year = int(year)
                if month < 1 or month > 12:
                    raise ValueError()
                start_date = datetime(year, month, 1).date()
                if month == 12:
                    requested_end_date = datetime(year + 1, 1, 1).date() - timedelta(days=1)
                else:
                    requested_end_date = datetime(year, month + 1, 1).date() - timedelta(days=1)
                end_date = min(requested_end_date, today)  # Cap at today
            except ValueError:
                return ApiResponse.error(
                    message="Invalid month or year. Month must be between 1-12",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
        else:
            # Default to current month
            start_date = datetime(today.year, today.month, 1).date()
            if today.month == 12:
                requested_end_date = datetime(today.year + 1, 1, 1).date() - timedelta(days=1)
            else:
                requested_end_date = datetime(today.year, today.month + 1, 1).date() - timedelta(days=1)
            end_date = min(requested_end_date, today)  # Cap at today
        
        if start_date > end_date:
            return ApiResponse.error(
                message="start_date must be before or equal to end_date",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Determine which employee's data to fetch
        if employee_id:
            try:
                employee = Employee.objects.get(id=employee_id)
                # Check permission - only HR managers can view other employees' data
                requesting_employee = Employee.objects.get(email=request.user.email_id)
                if not requesting_employee.is_hr_manager and requesting_employee != employee:
                    return ApiResponse.error(
                        message="Permission denied. You can only view your own attendance or be an HR manager",
                        status_code=status.HTTP_403_FORBIDDEN
                    )
            except Employee.DoesNotExist:
                return ApiResponse.not_found("Employee not found")
        else:
            # Default to logged-in user
            employee = Employee.objects.get(email=request.user.email_id)
        
        # Get attendance entries
        attendance_entries = get_attendance_entries_for_period(employee, start_date, end_date)
        
        # Get summary if month/year provided
        summary = None
        if month and year:
            summary = get_monthly_attendance_summary(employee, year, month)
        
        response_data = {
            "attendance_entries": attendance_entries,
            "date_range": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat(),
                "requested_end_date": requested_end_date.isoformat() if 'requested_end_date' in locals() else end_date.isoformat(),
                "data_limited_to_today": end_date < requested_end_date if 'requested_end_date' in locals() else False
            }
        }
        
        if summary:
            response_data["summary"] = summary
        
        # Add informational message if data was capped
        message = "Attendance calendar retrieved successfully"
        if 'requested_end_date' in locals() and end_date < requested_end_date:
            message += f" (data limited to today: {today.isoformat()})"
        
        return ApiResponse.success(
            data=response_data,
            message=message
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"An error occurred: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        ) 