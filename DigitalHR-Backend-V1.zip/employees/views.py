import logging
import random
from django.shortcuts import render, get_object_or_404
from announcements.serializers import AnnouncementSerializer
from policies.models import OfficeLocations
from rest_framework import status, viewsets
from rest_framework.decorators import api_view, permission_classes, parser_classes, action
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.utils import timezone
from django.db.models import Count, Q
from django.core.paginator import Paginator
from rest_framework.parsers import MultiPartParser, FormParser
from utils import constants
from request.models import WFH
import requests
from utils.notification_utils import NotificationService, notification_service

from .models import Employee, EmployeeDocument, EmployeeLocation
from .serializers import (
    EmployeeSerializer, EmployeeListSerializer, EmployeeUpdateSerializer,
    EmployeeDocumentSerializer,
    EmployeeStatsSerializer, TeamMemberSerializer, EmployeeOnboardSerializer,
    AdminEmployeeUpdateSerializer, EmployeeLocationSerializer, EmployeeLocationCreateSerializer
)
from utils.general_utils import ApiResponse
from utils.email_utils import EmailService
from authentication.models import User
from utils.boto_utils import S3DocumentUploader
from utils.constants import EXAMPLE_EMAIL, DOCUMENT_TYPES
from attendance.models import DailyAttendance, DailyTask
from projects.models import Project

# Create your views here.

@swagger_auto_schema(
    method='post',
    operation_description="Onboard a new employee",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=[
            'email', 'full_name', 'mobile_number', 'date_of_birth', 'gender',
            'date_of_joining', 'department', 'designation', 'emergency_contact_name',
            'emergency_contact_number', 'emergency_contact_relation', 'current_address',
            'permanent_address', 'blood_group', 'personal_email', 'total_experience', 'device_token'
        ],
        properties={
            'email': openapi.Schema(type=openapi.TYPE_STRING, format='email', description="Employee email"),
            'full_name': openapi.Schema(type=openapi.TYPE_STRING, description="Full name"),
            'personal_email': openapi.Schema(type=openapi.TYPE_STRING, format='email', description="Personal email"),
            'mobile_number': openapi.Schema(type=openapi.TYPE_STRING, description="Mobile number"),
            'date_of_birth': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Date of birth"),
            'gender': openapi.Schema(type=openapi.TYPE_STRING, description="Gender"),
            'date_of_joining': openapi.Schema(type=openapi.TYPE_STRING, format='date', description="Date of joining"),
            'department': openapi.Schema(type=openapi.TYPE_STRING, description="Department"),
            'designation': openapi.Schema(type=openapi.TYPE_STRING, description="Designation"),
            'emergency_contact_name': openapi.Schema(type=openapi.TYPE_STRING, description="Emergency contact name"),
            'emergency_contact_number': openapi.Schema(type=openapi.TYPE_STRING, description="Emergency contact number"),
            'emergency_contact_relation': openapi.Schema(type=openapi.TYPE_STRING, description="Emergency contact relation"),
            'current_address': openapi.Schema(type=openapi.TYPE_STRING, description="Current address"),
            'permanent_address': openapi.Schema(type=openapi.TYPE_STRING, description="Permanent address"),
            'blood_group': openapi.Schema(type=openapi.TYPE_STRING, description="Blood group"),
            'employee_id': openapi.Schema(type=openapi.TYPE_STRING, description="Employee ID (optional, will be auto-generated if not provided)"),
            'total_experience': openapi.Schema(type=openapi.TYPE_INTEGER, description="Total experience in years"),
            'device_token': openapi.Schema(type=openapi.TYPE_STRING, description="Device token")
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Employee onboarded successfully",
            schema=EmployeeSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        409: openapi.Response(description="Employee with this email or employee_id already exists")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def onboard_employee(request):
    """Onboard a new employee"""
    try:
        # Check if employee with same email already exists
        if Employee.objects.filter(email=request.data.get('email')).exists():
            return ApiResponse.error(
                message="Employee with this email already exists",
                status_code=status.HTTP_409_CONFLICT
            )
        
        # Check if employee_id is provided and if it already exists
        employee_id = request.data.get('employee_id')
        email_id = request.data.get('email')
        if employee_id and Employee.objects.filter(employee_id=employee_id).exists():
            return ApiResponse.error(
                message="Employee with this ID already exists",
                status_code=status.HTTP_409_CONFLICT
            )
        else:
            employee_id = Employee.generate_employee_id()
        
        # Validate required fields
        required_fields = [
            'email', 'full_name', 'mobile_number', 'date_of_birth', 'gender', 'personal_email',
            'date_of_joining', 'department', 'designation', 'emergency_contact_name',
            'emergency_contact_number', 'emergency_contact_relation', 'current_address',
            'permanent_address', 'blood_group', 'total_experience', 'device_token'
        ]
        
        missing_fields = [field for field in required_fields if not request.data.get(field)]
        if missing_fields:
            return ApiResponse.error(
                message="Missing required fields",
                errors={field: [f"This field is required."] for field in missing_fields},
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Create or get user
        try:
            user = User.objects.get(email_id=request.data.get('email'))
            if user.is_onboarded:
                return ApiResponse.error(
                    message="User is already onboarded",
                    status_code=status.HTTP_409_CONFLICT
                )
            else:
                user.is_onboarded = True
                user.device_token = request.data.get('device_token')
                user.save()
                
        except User.DoesNotExist:
            # Create new user
            return ApiResponse.error(
                message="User does not exist",
                status_code=status.HTTP_409_CONFLICT
            )
        

        
        # Create employee
        employee = Employee.objects.create(
            user=user,  # Link to user
            email=email_id,
            full_name=request.data.get('full_name'),
            personal_email=request.data.get('personal_email'),
            mobile_number=request.data.get('mobile_number'),
            date_of_birth=request.data.get('date_of_birth'),
            gender=request.data.get('gender'),
            date_of_joining=request.data.get('date_of_joining'),
            department=request.data.get('department'),
            designation=request.data.get('designation'),
            emergency_contact_name=request.data.get('emergency_contact_name'),
            emergency_contact_number=request.data.get('emergency_contact_number'),
            emergency_contact_relation=request.data.get('emergency_contact_relation'),
            current_address=request.data.get('current_address'),
            permanent_address=request.data.get('permanent_address'),
            blood_group=request.data.get('blood_group'),
            total_experience=request.data.get('total_experience'),
            employee_id=employee_id,  # Will be auto-generated if not provided
        )
        
        serializer = EmployeeSerializer(employee, context={'request': request})
        
        try:
            documents = EmployeeDocument.objects.filter(email_id=email_id)
            for document in documents:
                document.employee = document.employee if document.employee else employee
                document.save()
        except EmployeeDocument.DoesNotExist:
            pass
        
        # Send notification to all the hr
        hr_managers = Employee.objects.filter(is_hr_manager=True)
        for hr_manager in hr_managers:
            notification_service.send_notification_to_user(
                user_email=hr_manager.email,
                title="New Employee Onboarding Request",
                    body=f"{employee.full_name} has requested for onboarding. Kindly review the request.",  
                    data={
                    'type': 'employee_onboarded',
                    'employee_id': employee.employee_id,
                    'onboarded_by': request.user.email_id,
                    'onboarded_at': str(timezone.now())
                }
            )
        return ApiResponse.created(
            data=serializer.data,
            message="Employee onboarded successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=str(e),
            status_code=status.HTTP_400_BAD_REQUEST
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get list of employees with pagination and filtering. Includes WFH (Work From Home) information for employees with approved or pending WFH requests.",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('page', openapi.IN_QUERY, description="Page number", type=openapi.TYPE_INTEGER),
        openapi.Parameter('page_size', openapi.IN_QUERY, description="Items per page", type=openapi.TYPE_INTEGER),
        openapi.Parameter('department', openapi.IN_QUERY, description="Filter by department", type=openapi.TYPE_STRING),
        openapi.Parameter('employment_status', openapi.IN_QUERY, description="Filter by employment status", type=openapi.TYPE_STRING),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search by name or email", type=openapi.TYPE_STRING),
        openapi.Parameter('group_by_team', openapi.IN_QUERY, description="Group employees by team", type=openapi.TYPE_BOOLEAN),
        
    ],
    responses={
        200: openapi.Response(
            description="Employees retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employees retrieved successfully",
                    "success": True,
                    "data": [
                        {
                            "id": 1,
                            "employee_id": "SCI20240001",
                            "full_name": "John Doe",
                            "email": "john.doe@sciverse.co.in",
                            "department": "Tech",
                            "designation": "Senior Developer",
                            "employment_status": "Active",
                            "is_verified": True,
                            "is_onboarded": True,
                            "active": True,
                            "attendance_percentage": 85,
                            "is_clocked_in": True,
                            "on_leave": False,
                            "wfh_info": {
                                "has_approved_wfh": True,
                                "wfh_from_date": "2024-01-15",
                                "wfh_to_date": "2024-01-17",
                                "wfh_description": "Working from home due to personal reasons",
                                "approved_by": "Jane Smith",
                                "approved_at": "2024-01-14T10:30:00Z",
                                "wfh_request_id": 1
                            }
                        },
                        {
                            "id": 2,
                            "employee_id": "SCI20240002",
                            "full_name": "Jane Smith",
                            "email": "jane.smith@sciverse.co.in",
                            "department": "HR",
                            "designation": "HR Manager",
                            "employment_status": "Active",
                            "is_verified": True,
                            "is_onboarded": True,
                            "active": True,
                            "attendance_percentage": 90,
                            "is_clocked_in": False,
                            "on_leave": False,
                            "on_wfh": False
                        },
                        {
                            "id": 3,
                            "employee_id": "SCI20240003",
                            "full_name": "Bob Wilson",
                            "email": "bob.wilson@sciverse.co.in",
                            "department": "Finance",
                            "designation": "Accountant",
                            "employment_status": "Active",
                            "is_verified": True,
                            "is_onboarded": True,
                            "active": True,
                            "attendance_percentage": 95,
                            "is_clocked_in": True,
                            "on_leave": False,
                            "on_wfh": False
                        }
                    ]
                }
            }
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_employees(request):
    """
    Get paginated list of employees with filtering options
    """
    # Get query parameters
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 30))
    department = request.GET.get('department', '')
    employment_status = request.GET.get('employment_status', '')
    search = request.GET.get('search', '')
    group_by_team = request.GET.get('group_by_team', 'false').lower() == 'true'
    
    # Start with all employees
    queryset = Employee.objects.all()
    
    # Apply filters
    if department:
        queryset = queryset.filter(department=department)
    
    if employment_status:
        queryset = queryset.filter(employment_status=employment_status)
    
    if search:
        queryset = queryset.filter(
            Q(full_name__icontains=search) |
            Q(email__icontains=search) |
            Q(employee_id__icontains=search)
        )
    
    # Order by created date
    queryset = queryset.order_by('-created_at')
    
    # Paginate
    paginator = Paginator(queryset, page_size)
    
    try:
        employees_page = paginator.page(page)
    except:
        return ApiResponse.error(
            message="Invalid page number",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    if group_by_team:
        # Group employees by team
        teams = {}
        teams['Core Team'] = []
        teams['WFH Team'] = []
        for employee in queryset:
            if employee.is_core:
                teams['Core Team'].append(EmployeeListSerializer(employee).data)
                continue
            team_name = f"{employee.department} Team" or 'Unassigned Team'
            if team_name not in teams:
                teams[team_name] = []
            teams[team_name].append(EmployeeListSerializer(employee).data)
            
            # Check if employee is on WFH using the same logic as the serializer
            is_on_wfh = WFH.objects.filter(
                employee=employee, 
                status='approved', 
                from_date__lte=timezone.now().date(), 
                to_date__gte=timezone.now().date()
            ).exists()
            
            if is_on_wfh:
                teams['WFH Team'].append(EmployeeListSerializer(employee).data)
                continue
        
        # Sort teams alphabetically
        sorted_teams = dict(sorted(teams.items()))
        
        return ApiResponse.success(
            data=sorted_teams,
            message="Employees retrieved successfully"
        )
    else:
        # Regular pagination
        page = int(request.GET.get('page', 1))
        page_size = int(request.GET.get('page_size', 30))
        paginator = Paginator(queryset, page_size)
        employees_page = paginator.get_page(page)
        
        serializer = EmployeeListSerializer(employees_page, many=True)
        return ApiResponse.success(
            data=serializer.data,
            message="Employees retrieved successfully"
        )


@swagger_auto_schema(
    method='get',
    operation_description="Get employee details by email",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Employee details retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employee details retrieved successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "employee_id": "SCI20240001",
                        "full_name": "Jatin Jagani",
                        "email": "jatin.jagani@sciverse.co.in",
                        "age": 27,
                        "years_of_experience": 3
                    }
                }
            }
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_employee_detail(request, email_id):
    """
    Get detailed information about a specific employee by email
    """
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    serializer = EmployeeSerializer(employee)
    
    return ApiResponse.success(
        data=serializer.data,
        message="Employee details retrieved successfully"
    )


@swagger_auto_schema(
    method='put',
    operation_description="Update employee information (restricted fields)",
    request_body=EmployeeUpdateSerializer,
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Employee updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employee updated successfully",
                    "success": True,
                    "data": {
                        "full_name": "Updated Name",
                        "mobile_number": "9876543210",
                        "department": "Tech",
                        "designation": "Senior Developer"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation failed",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "Field 'email' cannot be updated through this endpoint.",
                        "Field 'employee_id' cannot be updated through this endpoint."
                    ]
                }
            }
        )
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_employee(request, email_id):
    """
    Update employee information with field restrictions
    
    Allows updating:
    - full_name, mobile_number, date_of_birth, gender, address
    - department, designation
    - emergency_contact_name, emergency_contact_number, emergency_contact_relation
    
    Restricted fields (cannot be updated):
    - email, employee_id, date_of_joining, employment_status
    - is_verified, is_onboard, verification_date, onboarding_date
    - last_login, salary, created_at, updated_at
    """
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Use the restricted update serializer
    serializer = EmployeeUpdateSerializer(employee, data=request.data, partial=True)
    
    if serializer.is_valid():
        updated_employee = serializer.save()
        
        # Return full employee data using the read serializer
        response_data = EmployeeSerializer(updated_employee).data
        
        return ApiResponse.success(
            data=response_data,
            message="Employee updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)


@swagger_auto_schema(
    method='delete',
    operation_description="Soft delete an employee (mark as inactive)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email ID",
            type=openapi.TYPE_STRING,
            required=True,
            example=EXAMPLE_EMAIL
        )
    ],
    responses={
        200: openapi.Response(
            description="Employee deactivated successfully"
        )
    }
)
@api_view(['DELETE'])
@permission_classes([AllowAny])
def delete_employee(request, email_id):
    """
    Soft delete employee (mark as inactive)
    """
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Soft delete - mark as inactive
    employee.employment_status = 'Terminated'
    employee.deleted_at = timezone.now()
    employee.save()
    
    # Also deactivate user account
    employee.user.active = False
    employee.user.save()
    
    return ApiResponse.success(
        message="Employee deactivated successfully"
    )


@swagger_auto_schema(
    method='get',
    operation_description="Get employee statistics and metrics",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Employee statistics retrieved successfully"
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def employee_statistics(request):
    """
    Get comprehensive employee statistics
    """
    # Basic counts
    total_employees = Employee.objects.count()
    active_employees = Employee.objects.filter(employment_status='Active').count()
    verified_employees = Employee.objects.filter(is_verified=True).count()
    onboarded_employees = Employee.objects.filter(is_onboard=True).count()
    
    # Department distribution
    departments = dict(
        Employee.objects.filter(employment_status='Active')
        .values('department')
        .annotate(count=Count('department'))
        .values_list('department', 'count')
    )
    
    # Designation distribution
    designations = dict(
        Employee.objects.filter(employment_status='Active')
        .values('designation')
        .annotate(count=Count('designation'))
        .values_list('designation', 'count')
    )
    
    stats_data = {
        'total_employees': total_employees,
        'active_employees': active_employees,
        'verified_employees': verified_employees,
        'onboarded_employees': onboarded_employees,
        'departments': departments,
        'designations': designations
    }
    
    return ApiResponse.success(
        data=stats_data,
        message="Employee statistics retrieved successfully"
    )



# @swagger_auto_schema(
#     method='post',
#     operation_description="Upload employee document (PDF or JPEG only) to S3 with structured path",
#     manual_parameters=[
#         openapi.Parameter(
#             'Authorization',
#             openapi.IN_HEADER,
#             description="JWT token in format: Bearer <token>",
#             type=openapi.TYPE_STRING,
#             required=True
#         )
#     ],
#     request_body=openapi.Schema(
#         type=openapi.TYPE_OBJECT,
#         properties={
#             'document_type': openapi.Schema(
#                 type=openapi.TYPE_STRING,
#                 description='Type of document to upload',
#                 enum=[
#                     'PAN_Card', 'Aadhar_Card', '10th_Certificate', '12th_Certificate',
#                     'Graduation_Certificate', 'Latest_Experience_Letter', 'Past_Company_Salary_Slip',
#                     'Resume', 'ID_Proof', 'Address_Proof', 'Education_Certificate',
#                     'Experience_Letter', 'Offer_Letter', 'Contract', 'Passport', 'Other'
#                 ],
#                 example='Resume'
#             ),
#             'document_name': openapi.Schema(
#                 type=openapi.TYPE_STRING,
#                 description='Display name for the document',
#                 example='John Doe Resume 2024'
#             ),
#             'document_file': openapi.Schema(
#                 type=openapi.TYPE_STRING,
#                 format=openapi.FORMAT_BINARY,
#                 description='Document file (PDF or JPEG only, max 10MB)'
#             ),
#             'notes': openapi.Schema(
#                 type=openapi.TYPE_STRING,
#                 description='Optional notes about the document',
#                 example='Updated resume with latest experience'
#             )
#         },
#         required=['document_type', 'document_name', 'document_file']
#     ),
#     responses={
#         201: openapi.Response(
#             description="Document uploaded successfully to S3",
#             examples={
#                 "application/json": {
#                     "code": 201,
#                     "message": "Document uploaded successfully",
#                     "success": True,
#                     "data": {
#                         "id": 1,
#                         "document_type": "Resume",
#                         "document_name": "John Doe Resume 2024",
#                         "document_file_url": "https://digihr.s3.ap-south-1.amazonaws.com/sciverse/employees/john.doe%40sciverse.co.in/documents/Resume/a1b2c3d4-e5f6-7890-abcd-ef1234567890/resume.pdf",
#                         "is_verified": False,
#                         "verified_by": None,
#                         "verified_by_name": None,
#                         "verified_at": None,
#                         "uploaded_by": "john.doe@sciverse.co.in",
#                         "uploaded_by_name": "john.doe@sciverse.co.in",
#                         "notes": "Updated resume with latest experience",
#                         "file_size": "Available on S3",
#                         "created_at": "2024-03-15T10:30:00.000000+05:30",
#                         "updated_at": "2024-03-15T10:30:00.000000+05:30"
#                     }
#                 }
#             }
#         ),
#         400: openapi.Response(
#             description="Validation error - file type, size, or required fields",
#             examples={
#                 "application/json": {
#                     "code": 400,
#                     "message": "Validation failed",
#                     "success": False,
#                     "errors": [
#                         "File size cannot exceed 10MB.",
#                         "Only PDF and JPEG files are accepted. Got: .docx",
#                         "Document Name: This field is required."
#                     ]
#                 }
#             }
#         ),
#         404: openapi.Response(
#             description="Employee not found",
#             examples={
#                 "application/json": {
#                     "code": 404,
#                     "message": "Employee not found",
#                     "success": False
#                 }
#             }
#         ),
#         500: openapi.Response(
#             description="S3 upload failed",
#             examples={
#                 "application/json": {
#                     "code": 500,
#                     "message": "File upload failed: AWS S3 error: Access Denied",
#                     "success": False
#                 }
#             }
#         )
#     }
# )
# @api_view(['POST'])
# @permission_classes([IsAuthenticated])
# def upload_employee_document(request, email_id):
#     """
#     Upload a document for an employee
#     """
#     try:
#         employee = Employee.objects.get(email=email_id)
#     except Employee.DoesNotExist:
#         return ApiResponse.not_found("Employee not found")
    
#     # Add employee and uploaded_by to request data
#     request.data['employee'] = employee.id
#     request.data['uploaded_by'] = request.user.id
    
#     serializer = EmployeeDocumentSerializer(data=request.data)
    
#     if serializer.is_valid():
#         document = serializer.save(employee=employee, uploaded_by=request.user)
        
#         return ApiResponse.created(
#             data=serializer.data,
#             message="Document uploaded successfully"
#         )
    
#     return ApiResponse.validation_error(serializer.errors)


@swagger_auto_schema(
    method='get',
    operation_description="Get employee documents",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email ID",
            type=openapi.TYPE_STRING,
            required=True,
            example=EXAMPLE_EMAIL
        )
    ],
    responses={
        200: openapi.Response(
            description="Documents retrieved successfully"
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_employee_documents(request):
    """
    Get all documents for an employee
    """
    email_id = request.query_params.get('email_id')
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={"email_id": ["This field is required."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    documents = EmployeeDocument.objects.filter(employee=employee).order_by('-created_at')
    serializer = EmployeeDocumentSerializer(documents, many=True)
    
    return ApiResponse.success(
        data=serializer.data,
        message="Documents retrieved successfully"
    )


@swagger_auto_schema(
    method='get',
    operation_description="Get list of users available for onboarding",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('search', openapi.IN_QUERY, description="Search by email", type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response(
            description="Users available for onboarding retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Users available for onboarding retrieved successfully",
                    "success": True,
                    "data": [
                        {
                            "email_id": "newuser@sciverse.co.in",
                            "is_verified": True,
                            "active": True,
                            "is_onboarded": False,
                            "created_at": "2024-01-15T10:00:00.000000+05:30"
                        }
                    ]
                }
            }
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_pending_onboarding(request):
    """
    Get list of users who are not onboarded (available for onboarding)
    
    This endpoint returns users who have registered but haven't been onboarded yet.
    """
    search = request.GET.get('search', '')
    
    # Get users who are not onboarded
    queryset = User.objects.filter(is_onboarded=False, active=True)
    
    # Apply search filter
    if search:
        queryset = queryset.filter(email_id__icontains=search)
    
    # Order by created date
    queryset = queryset.order_by('-created_at')
    
    # Serialize data
    users_data = []
    for user in queryset:
        users_data.append({
            'email_id': user.email_id,
            'is_verified': user.is_verified,
            'active': user.active,
            'is_onboarded': user.is_onboarded,
            'created_at': user.created_at
        })
    
    return ApiResponse.success(
        data=users_data,
        message="Users available for onboarding retrieved successfully"
    )


@swagger_auto_schema(
    method='put',
    operation_description="Admin: Update employee information (all fields)",
    request_body=AdminEmployeeUpdateSerializer,
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter('email_id', openapi.IN_QUERY, description='Employees email to be updated for', type=openapi.TYPE_STRING),
    ],
    responses={
        200: openapi.Response(
            description="Employee updated successfully (admin)",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employee updated successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "employee_id": "SCI20240001",
                        "full_name": "Updated Name",
                        "email": "updated@sciverse.co.in",
                        "employment_status": "Active",
                        "salary": 50000.00
                    }
                }
            }
        ),
        403: openapi.Response(
            description="Permission denied",
            examples={
                "application/json": {
                    "code": 403,
                    "message": "Admin access required",
                    "success": False
                }
            }
        )
    }
)
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def admin_update_employee(request):
    """
    Admin-only endpoint to update all employee fields including restricted ones
    
    Can update all fields including:
    - email, employee_id, employment_status, salary
    - verification status, onboarding status
    - dates and timestamps
    - file uploads (profile photo, documents, etc.)
    
    Requires admin privileges.
    """
    # Check if user is admin/staff
    admin_email_id = request.user.email_id
    employee_email_id = request.query_params.get('email_id')
    
    admin_employee = Employee.objects.get(email=admin_email_id)
    if not admin_employee.is_hr_manager:
        return ApiResponse.error(
            message="Admin access required",
            status_code=status.HTTP_403_FORBIDDEN
        )
    
    try:
        employee = Employee.objects.get(email=employee_email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Map request data to serializer fields
    data = {
        'email_id': employee_email_id,
        'employee_id': request.data.get('employee_id'),
        'department': request.data.get('department'),
        'designation': request.data.get('designation'),
        'reporting_manager_email': request.data.get('reporting_manager_email'),
        'date_of_joining': request.data.get('date_of_joining'),
        'appraisal_date': request.data.get('appraisal_date'),
        'shift_type': request.data.get('shift_type'),
        'uan_number': request.data.get('uan_number'),
        'current_ctc': request.data.get('current_ctc'),
        'employment_type': request.data.get('employment_type'),
        'location_id': request.data.get('location_id'),
    }
    
    # Add any file fields from request.FILES
    if request.FILES:
        for field_name, file_obj in request.FILES.items():
            data[field_name] = file_obj
    
    # Use the admin update serializer
    serializer = AdminEmployeeUpdateSerializer(employee, data=data, partial=True)
    
    if serializer.is_valid():
        updated_employee = serializer.save()
        
        # Return full employee data using the read serializer
        response_data = EmployeeSerializer(updated_employee).data
        
        return ApiResponse.success(
            data=response_data,
            message="Employee updated successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)


@swagger_auto_schema(
    method='post',
    operation_description="Upload or update employee profile photo using S3",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'profile_photo',
            openapi.IN_FORM,
            description="Profile photo file (max 5MB, jpg/png/gif)",
            type=openapi.TYPE_FILE,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Profile photo updated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Profile photo updated successfully",
                    "success": True,
                    "data": {
                        "profile_photo_url": "https://s3.amazonaws.com/bucket/profile_photos/employee@sciverse.co.in/profile.jpg",
                        "profile_photo_display_url": "https://s3.amazonaws.com/bucket/profile_photos/employee@sciverse.co.in/profile.jpg"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation error",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation error",
                    "success": False,
                    "errors": {
                        "profile_photo": ["File size cannot exceed 5MB."]
                    }
                }
            }
        ),
        404: openapi.Response(
            description="Employee not found"
        )
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def upload_profile_photo(request):
    """
    Upload or update employee profile photo using S3 storage
    
    This endpoint:
    1. Validates the profile photo file
    2. Uploads it to S3 under the profile_photos collection
    3. Updates the employee's profile_photo_url with the S3 URL
    
    The profile photo will be stored in S3 with the following path:
    profile_photos/{email_id}/profile_photo.{extension}
    """
    email_id = request.user.email_id
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={"email_id": ["This field is required."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Validate profile photo file
    if 'profile_photo' not in request.FILES:
        return ApiResponse.error(
            message="Validation error",
            errors={"profile_photo": ["This field is required."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    profile_photo = request.FILES['profile_photo']
    
    # Validate file size (max 5MB)
    if profile_photo.size > 5 * 1024 * 1024:
        return ApiResponse.error(
            message="Validation error",
            errors={"profile_photo": ["File size cannot exceed 5MB."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Validate file type
    allowed_extensions = ['.jpg', '.jpeg', '.png', '.gif']
    import os
    ext = os.path.splitext(profile_photo.name)[1].lower()
    if ext not in allowed_extensions:
        return ApiResponse.error(
            message="Validation error",
            errors={"profile_photo": [f"File type not allowed. Allowed types: {', '.join(allowed_extensions)}"]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Upload to S3
    uploader = S3DocumentUploader()
    success, result = uploader.upload_document(
        email_id=email_id,
        document_type="profile_photo",
        file=profile_photo,
        document_collection="profile_photos",
    )
    
    if not success:
        return ApiResponse.error(
            message=f"File upload failed: {result}",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Update employee's profile photo URL
    employee.profile_photo_url = result
    employee.save(update_fields=['profile_photo_url'])
    
    response_data = {
        'profile_photo_url': employee.profile_photo_url,
        'profile_photo_display_url': employee.profile_photo_display_url
    }
    
    return ApiResponse.success(
        data=response_data,
        message="Profile photo updated successfully"
    )


@swagger_auto_schema(
    method='delete',
    operation_description="Admin: Completely delete an employee and associated user account",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'email_id': openapi.Schema(
                type=openapi.TYPE_STRING,
                description='Email address of user to delete',
                format=openapi.FORMAT_EMAIL
            )
        },
        required=['email_id']
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Employee and user account deleted successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employee and associated user account deleted successfully",
                    "success": True,
                    "data": {
                        "email_id": "user@sciverse.co.in",
                        "deleted_records": {
                            "employee": True,
                            "user": True,
                            "otp_records": 3
                        }
                    }
                }
            }
        ),
        403: openapi.Response(
            description="Permission denied",
            examples={
                "application/json": {
                    "code": 403,
                    "message": "Admin access required",
                    "success": False
                }
            }
        ),
        404: openapi.Response(
            description="Employee not found"
        )
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def admin_delete_employee_complete(request):
    """
    Admin-only endpoint to completely delete an employee and associated user account
    
    This endpoint performs a complete deletion of:
    - Employee record
    - Associated User account  
    - All related OTP records (deleted automatically via CASCADE)
    
    WARNING: This is a permanent deletion and cannot be undone.
    Requires admin privileges.
    """
    # Check if user is admin/staff
    # if not (request.user.is_staff or request.user.is_superuser):
    #     return ApiResponse.error(
    #         message="Admin access required",
    #         status_code=status.HTTP_403_FORBIDDEN
    #     )
    email_id = request.data.get('email_id')
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Store data for response before deletion
    employee_id_str = employee.employee_id
    # email_id = employee.email
    user = employee.user
    
    # Count OTP records before deletion
    from authentication.models import OTP
    otp_count = OTP.objects.filter(email_id=user).count()
    
    try:
        # Delete employee first
        employee.delete()
        
        # Delete user (this will automatically delete OTP records via CASCADE)
        user.delete()
        
        response_data = {
            'employee_id': employee_id_str,
            'email_id': email_id,
            'deleted_records': {
                'employee': True,
                'user': True,
                'otp_records': otp_count
            }
        }
        
        return ApiResponse.success(
            data=response_data,
            message="Employee and associated user account deleted successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"Error during deletion: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Download employee document with secure presigned URL",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'document_id',
            openapi.IN_PATH,
            description="Document ID to download",
            type=openapi.TYPE_INTEGER,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email ID",
            type=openapi.TYPE_STRING,
            required=True,
            example=EXAMPLE_EMAIL
        )
    ],
    responses={
        200: openapi.Response(
            description="Presigned URL generated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Presigned URL generated successfully",
                    "success": True,
                    "data": {
                        "download_url": "https://digitalhr-documents.s3.amazonaws.com/...",
                        "expires_in": "3600 seconds",
                        "document_name": "resume.pdf",
                        "document_type": "Resume"
                    }
                }
            }
        ),
        404: openapi.Response(
            description="Document not found"
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def download_employee_document(request, document_id):
    """
    Generate presigned URL for secure document download
    """
    email_id = request.query_params.get('email_id')
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={"email_id": ["This field is required."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    try:
        document = EmployeeDocument.objects.get(id=document_id, employee=employee)
    except EmployeeDocument.DoesNotExist:
        return ApiResponse.not_found("Document not found")
    
    if not document.document_file_url:
        return ApiResponse.error(
            message="Document file not available",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    # Generate presigned URL for secure download
    from utils.boto_utils import s3_uploader
    success, presigned_url = s3_uploader.generate_presigned_url(
        file_url=document.document_file_url,
        expiration=3600  # 1 hour
    )
    
    if not success:
        return ApiResponse.error(
            message=f"Could not generate download URL: {presigned_url}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    
    response_data = {
        'download_url': presigned_url,
        'expires_in': '3600 seconds',
        'document_name': document.document_name,
        'document_type': document.document_type
    }
    
    return ApiResponse.success(
        data=response_data,
        message="Presigned URL generated successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Upload or update employee document using form data (PDF or JPEG only)",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_FORM,
            description="Employee email ID",
            type=openapi.TYPE_STRING,
            required=True,
            example=EXAMPLE_EMAIL
        ),
        openapi.Parameter(
            'document_type',
            openapi.IN_FORM,
            description="Type of document (e.g., PAN_Card, Aadhar_Card, etc.)",
            type=openapi.TYPE_STRING,
            required=True,
            enum=DOCUMENT_TYPES
        ),
        openapi.Parameter(
            'document_file',
            openapi.IN_FORM,
            description="Document file (PDF or JPEG only, max 10MB)",
            type=openapi.TYPE_FILE,
            required=True
        ),
        openapi.Parameter(
            'notes',
            openapi.IN_FORM,
            description="Optional notes about the document",
            type=openapi.TYPE_STRING,
            required=False
        )
    ],
    responses={
        201: openapi.Response(
            description="Document uploaded successfully",
            examples={
                "application/json": {
                    "status": "success",
                    "message": "Document uploaded successfully",
                    "data": {
                        "id": 1,
                        "document_type": "PAN_Card",
                        "document_name": "PAN Card",
                        "document_file_url": "https://example-bucket.s3.amazonaws.com/sciverse/employees/john.doe@sciverse.co.in/documents/PAN_Card/550e8400-e29b-41d4-a716-446655440000/pan_card.pdf",
                        "is_verified": False,
                        "verified_by": None,
                        "verified_by_name": None,
                        "verified_at": None,
                        "uploaded_by": "john.doe@sciverse.co.in",
                        "uploaded_by_name": "john.doe@sciverse.co.in",
                        "notes": "Original PAN card",
                        "file_size": "Available on S3",
                        "created_at": "2024-03-20T10:30:00Z",
                        "updated_at": "2024-03-20T10:30:00Z"
                    }
                }
            }
        ),
        200: openapi.Response(
            description="Document updated successfully",
            examples={
                "application/json": {
                    "status": "success",
                    "message": "Document updated successfully",
                    "data": {
                        "id": 1,
                        "document_type": "PAN_Card",
                        "document_name": "Updated PAN Card",
                        "document_file_url": "https://example-bucket.s3.amazonaws.com/sciverse/employees/john.doe@sciverse.co.in/documents/PAN_Card/550e8400-e29b-41d4-a716-446655440000/updated_pan_card.pdf",
                        "is_verified": False,
                        "verified_by": None,
                        "verified_by_name": None,
                        "verified_at": None,
                        "uploaded_by": "john.doe@sciverse.co.in",
                        "uploaded_by_name": "john.doe@sciverse.co.in",
                        "notes": "Updated PAN card",
                        "file_size": "Available on S3",
                        "created_at": "2024-03-20T10:30:00Z",
                        "updated_at": "2024-03-20T11:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation error",
            examples={
                "application/json": {
                    "status": "error",
                    "message": "Validation error",
                    "errors": {
                        "email_id": ["This field is required."],
                        "document_type": ["This field is required."],
                        "document_file": ["No file was submitted."]
                    }
                }
            }
        ),
        401: openapi.Response(
            description="Authentication error",
            examples={
                "application/json": {
                    "status": "error",
                    "message": "Authentication credentials were not provided."
                }
            }
        ),
        404: openapi.Response(
            description="Employee not found",
            examples={
                "application/json": {
                    "status": "error",
                    "message": f"Employee with email {EXAMPLE_EMAIL} not found"
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def upload_employee_document_form(request):
    """
    Upload or update employee document using form data
    """
    try:
        # Get email_id from request data
        email_id = request.data.get('email_id')
        if not email_id:
            return ApiResponse.error(
                message="Validation error",
                errors={"email_id": ["This field is required."]},
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Get employee
        try:
            employee = Employee.objects.get(email=email_id)
        except Employee.DoesNotExist:
            employee = None
        
        # Validate required fields
        required_fields = ['document_type', 'document_file']
        missing_fields = [field for field in required_fields if field not in request.FILES and field not in request.data]
        
        if missing_fields:
            return ApiResponse.error(
                message="Validation error",
                errors={field: [f"This field is required."] for field in missing_fields},
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Get form data
        document_type = request.data.get('document_type')
        document_file = request.FILES.get('document_file')
        notes = request.data.get('notes', '')
        
        # Upload to S3
        uploader = S3DocumentUploader()
        success, result = uploader.upload_document(
            email_id=email_id,
            document_type=document_type,
            file=document_file,
            document_collection="personal_documents",
        )
        
        if not success:
            return ApiResponse.error(
                message=f"File upload failed: {result}",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Check if document of this type already exists
        try:
            document = EmployeeDocument.objects.get(
                employee=employee,
                document_type=document_type
            )
            # Update existing document
            document.document_file_url = result
            document.uploaded_by = request.user
            document.notes = notes
            document.is_verified = False  # Reset verification status
            document.verified_by = None
            document.verified_by_name = None
            document.verified_at = None
            document.email_id = email_id
            document.save()
            
            message = "Document updated successfully"
            status_code = status.HTTP_200_OK
            
        except EmployeeDocument.DoesNotExist:
            # Create new document
            document = EmployeeDocument.objects.create(
                employee=employee,
                document_type=document_type,
                document_file_url=result,
                uploaded_by=request.user,
                notes=notes
            )
            
            message = "Document uploaded successfully"
            status_code = status.HTTP_201_CREATED
        
        # Serialize the document for response
        serializer = EmployeeDocumentSerializer(document)
        
        return ApiResponse.success(
            message=message,
            data=serializer.data,
            status_code=status_code
        )
        
    except Employee.DoesNotExist:
        return ApiResponse.error(
            message=f"Employee with email {email_id} not found",
            status_code=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        return ApiResponse.error(
            message=str(e),
            status_code=status.HTTP_400_BAD_REQUEST
        )

@swagger_auto_schema(
    method='post',
    operation_description="Verify an employee using their email_id",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'email_id': openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Employee email ID to verify",
                example=constants.EXAMPLE_EMAIL
            )
        },
        required=['email_id']
    ),
    responses={
        200: openapi.Response(
            description="Employee verified successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employee verified successfully",
                    "success": True,
                    "data": {
                        "id": 1,
                        "employee_id": "SCI20240001",
                        "full_name": "John Doe",
                        "email": "john.doe@sciverse.co.in",
                        "is_verified": True,
                        "verification_date": "2024-03-20T10:30:00Z",
                        "verified_by": "admin@sciverse.co.in",
                        "user": {
                            "is_verified": True,
                            "is_onboarded": True,
                            "active": True
                        }
                    }
                }
            }
        ),
        404: openapi.Response(
            description="Employee not found",
            examples={
                "application/json": {
                    "code": 404,
                    "message": "Employee not found",
                    "success": False
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def verify_employee(request):
    """
    Verify an employee using their email_id
    
    This endpoint marks both the employee and their associated user as verified and records:
    - Verification status for both Employee and User
    - Verification date
    - Verifier (current user)
    - Sends notification to the employee
    """
    email_id = request.data.get('email_id')
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={"email_id": ["This field is required."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Check if already verified
        # if employee.is_verified:
        #     return ApiResponse.error(
        #         message="Employee is already verified",
        #         status_code=status.HTTP_400_BAD_REQUEST
        #     )
    
    # Update employee verification status
    employee.is_verified = True
    employee.verification_date = timezone.now()
    employee.verified_by = request.user
    employee.save()
    
    # Update associated user verification status
    user = employee.user
    user.is_verified = True
    user.save()
    
    # Send notification to the employee
    try:
        notification_title = "Account Verified"
        notification_body = f"Congratulations {employee.full_name}! Your account has been verified successfully. You can now access all features of the DigitalHR application."
        
        success, message = notification_service.send_notification_to_user(
            user_email=email_id,
            title=notification_title,
            body=notification_body,
            data={
                'type': 'account_verified',
                'employee_id': employee.employee_id,
                'verified_by': request.user.email_id,
                'verified_at': str(timezone.now())
            }
        )
        
        if not success:
            logging.warning(f"Failed to send verification notification to {email_id}: {message}")
            
    except Exception as e:
        logging.error(f"Error sending verification notification: {str(e)}")
    
    # Return updated employee data with user status
    serializer = EmployeeSerializer(employee)
    response_data = serializer.data
    
    # Add user status details
    response_data['user'] = {
        'is_verified': user.is_verified,
        'is_onboarded': user.is_onboarded,
        'active': user.active
    }
    
    return ApiResponse.success(
        data=response_data,
        message="Employee verified successfully"
    )

@swagger_auto_schema(
    method='get',
    operation_description="Get detailed information for a specific employee by email",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'email_id',
            openapi.IN_QUERY,
            description="Employee email ID",
            type=openapi.TYPE_STRING,
            required=True,
            example=EXAMPLE_EMAIL
        )
    ],
    responses={
        200: openapi.Response(
            description="Employee details retrieved successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employee details retrieved successfully",
                    "success": True,
                    "data": {
                        "employee_id": "SCI20240001",
                        "full_name": "John Doe",
                        "email_id": "john.doe@sciverse.co.in",
                        "date_of_birth": "1990-01-01",
                        "blood_group": "O+",
                        "mobile_number": "9876543210",
                        "emergency_contact_number": "9876543211",
                        "department": "IT",
                        "designation": "Senior Developer",
                        "reporting_manager": "Jane Smith",
                        "onboarding_date": "2024-01-01",
                        "appraisal_date": "2024-12-31",
                        "current_ctc": 1200000,
                        "shift": "9:30 AM - 6:30 PM",
                        "uan_number": "123456789012",
                        "project_contributions": [
                            {
                                "project_id": 1,
                                "project_name": "Project Alpha",
                                "completed_tasks": 15,
                                "total_tasks": 20,
                                "completion_percentage": 75.0
                            }
                        ]
                    }
                }
            }
        ),
        404: openapi.Response(
            description="Employee not found",
            examples={
                "application/json": {
                    "code": 404,
                    "message": "Employee not found",
                    "success": False
                }
            }
        )
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_employee_details(request):
    """
    Get detailed information for a specific employee including:
    - Basic information (DOB, email, blood group, etc.)
    - Contact information
    - Employment details
    - Project contributions
    """
    email_id = request.query_params.get('email_id')
    if not email_id:
        return ApiResponse.error(
            message="Validation error",
            errors={"email_id": ["This field is required."]},
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        employee = Employee.objects.get(email=email_id)
    except Employee.DoesNotExist:
        return ApiResponse.not_found("Employee not found")
    
    # Get basic employee information
    employee_data = {
        'employee_id': employee.employee_id,
        'full_name': employee.full_name,
        'email_id': employee.email,
        'gender': employee.gender,
        'profile_photo': employee.profile_photo_url,
        'personal_email': employee.personal_email,
        'date_of_birth': employee.date_of_birth,
        'blood_group': employee.blood_group,
        'mobile_number': employee.mobile_number,
        'emergency_contact_number': employee.emergency_contact_number,
        'department': employee.department,
        'designation': employee.designation,
        'reporting_manager': employee.reporting_manager.full_name if employee.reporting_manager else None,
        'onboarding_date': employee.onboarding_date,
        'date_of_joining': employee.date_of_joining,
        'appraisal_date': employee.appraisal_date,
        'current_ctc': employee.current_ctc,
        'shift': employee.shift or "9:30 AM - 6:30 PM",  # Default shift if not set
        'uan_number': employee.uan_number,
        'current_address': employee.current_address,
        'permanent_address': employee.permanent_address,
        'years_of_experience': employee.years_of_experience,
        'profile_photo': employee.profile_photo_url,
        'total_experience': employee.total_experience,
        'emergency_contact_name': employee.emergency_contact_name,
        'emergency_contact_relation': employee.emergency_contact_relation,
        'shift_type': employee.shift_type,
        'employment_type': employee.employment_type,
        'reporting_location': employee.reporting_location.location_name if employee.reporting_location else None,
        'projects': EmployeeSerializer(employee).data['projects']
    }

    # Get project contributions
    projects = Project.objects.filter(team_members=employee)
    project_data = []
    total_contributions = 0
    overall_tasks = 0
    for project in projects:
        tasks = DailyTask.objects.filter(
            employee=employee,
            project=project
        )
        completed_tasks = tasks.filter(end_time__isnull=False).count()
        total_tasks = tasks.count()
        total_contributions += completed_tasks
        overall_tasks += total_tasks
        project_data.append({
            'project_id': project.id,
            'project_name': project.name,
            'completed_tasks': completed_tasks,
            'total_tasks': total_tasks,
            'completion_percentage': int((completed_tasks / total_tasks * 100)) if total_tasks > 0 else 0
        })
    employee_data['project_contributions'] = project_data
    if overall_tasks > 0:
        employee_data['total_contributions'] = int(total_contributions/overall_tasks*100)
    else:
        employee_data['total_contributions'] = 0
    
    return ApiResponse.success(
        data=employee_data,
        message="Employee details retrieved successfully"
    )

# ViewSets
class EmployeeViewSet(viewsets.ModelViewSet):
    """
    ViewSet for Employee model
    """
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = Employee.objects.all()
        email = self.request.query_params.get('email', None)
        if email:
            queryset = queryset.filter(email=email)
        return queryset

class EmployeeDocumentViewSet(viewsets.ModelViewSet):
    """
    ViewSet for EmployeeDocument model
    """
    queryset = EmployeeDocument.objects.all()
    serializer_class = EmployeeDocumentSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = EmployeeDocument.objects.all()
        email = self.request.query_params.get('email', None)
        if email:
            queryset = queryset.filter(email_id=email)
        return queryset

@swagger_auto_schema(
    method='post',
    operation_description="Create a new employee location record with automatic address lookup",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        required=['lat_long'],
        properties={
            'lat_long': openapi.Schema(
                type=openapi.TYPE_STRING, 
                description="Latitude and longitude in format 'latitude,longitude' (e.g., '12.9716,77.5946')",
                example="12.9716,77.5946"
            )
        }
    ),
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        201: openapi.Response(
            description="Location record created successfully with address lookup",
            schema=EmployeeLocationSerializer
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        404: openapi.Response(description="Employee not found")
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_employee_location(request):
    """
    Create a new employee location record
    Automatically gets the address from coordinates using reverse geocoding
    """
    try:
        # Get the employee from the authenticated user
        employee = request.user.employee_profile
        
        serializer = EmployeeLocationCreateSerializer(data=request.data, context={'request': request})
        
        if serializer.is_valid():
            # Create the location record with employee
            serializer.save()
            
            return ApiResponse.created(
                data=serializer.data,
                message="Location record created successfully"
            )
        else:
            return ApiResponse.validation_error(serializer.errors)
            
    except Exception as e:
        return ApiResponse.error(
            message=f"Failed to create location record: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get employee location records with pagination",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'page', 
            openapi.IN_QUERY, 
            description="Page number", 
            type=openapi.TYPE_INTEGER
        ),
        openapi.Parameter(
            'page_size', 
            openapi.IN_QUERY, 
            description="Items per page", 
            type=openapi.TYPE_INTEGER
        ),
        openapi.Parameter(
            'email_id', 
            openapi.IN_QUERY, 
            description="Filter by employee email (HR managers only)", 
            type=openapi.TYPE_STRING
        ),
    ],
    responses={
        200: openapi.Response(
            description="Location records retrieved successfully",
            schema=EmployeeLocationSerializer(many=True)
        ),
        400: openapi.Response(description="Validation error"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_employee_locations(request):
    """
    Get employee location records
    HR managers can view all locations, others can only view their own
    """
    try:
        # Get query parameters
        page = int(request.GET.get('page', 1))
        page_size = int(request.GET.get('page_size', 10))
        email_id = request.GET.get('email_id')
        
        # Determine which employee's locations to show
        if request.user.employee_profile.is_hr_manager and email_id:
            # HR manager filtering by specific employee
            try:
                employee = Employee.objects.get(email=email_id)
                locations = EmployeeLocation.objects.filter(employee=employee)
            except Employee.DoesNotExist:
                return ApiResponse.not_found("Employee not found")
        else:
            # Regular user or HR manager viewing all
            if request.user.employee_profile.is_hr_manager:
                locations = EmployeeLocation.objects.all()
            else:
                # Regular user can only see their own locations
                locations = EmployeeLocation.objects.filter(employee=request.user.employee_profile)
        
        # Apply pagination
        paginator = Paginator(locations, page_size)
        try:
            locations_page = paginator.page(page)
        except (EmptyPage, InvalidPage):
            return ApiResponse.error(
                message="Invalid page number",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = EmployeeLocationSerializer(locations_page, many=True)
        
        return ApiResponse.success(
            data={
                'results': serializer.data,
                'pagination': {
                    'page': page,
                    'page_size': page_size,
                    'total_pages': paginator.num_pages,
                    'total_count': paginator.count,
                    'has_next': locations_page.has_next(),
                    'has_previous': locations_page.has_previous(),
                }
            },
            message="Location records retrieved successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"Failed to retrieve location records: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get a specific employee location record",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Location record retrieved successfully",
            schema=EmployeeLocationSerializer
        ),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied"),
        404: openapi.Response(description="Location record not found")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_employee_location(request, location_id):
    """
    Get a specific employee location record
    Users can only view their own locations, HR managers can view any
    """
    try:
        location = get_object_or_404(EmployeeLocation, id=location_id)
        
        # Check permissions
        if not request.user.employee_profile.is_hr_manager and location.employee != request.user.employee_profile:
            return ApiResponse.error(
                message="You can only view your own location records",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        serializer = EmployeeLocationSerializer(location)
        
        return ApiResponse.success(
            data=serializer.data,
            message="Location record retrieved successfully"
        )
        
    except EmployeeLocation.DoesNotExist:
        return ApiResponse.not_found("Location record not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"Failed to retrieve location record: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='delete',
    operation_description="Delete an employee location record",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(description="Location record deleted successfully"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        403: openapi.Response(description="Permission denied"),
        404: openapi.Response(description="Location record not found")
    }
)
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_employee_location(request, location_id):
    """
    Delete an employee location record
    Users can only delete their own locations, HR managers can delete any
    """
    try:
        location = get_object_or_404(EmployeeLocation, id=location_id)
        
        # Check permissions
        if not request.user.employee_profile.is_hr_manager and location.employee != request.user.employee_profile:
            return ApiResponse.error(
                message="You can only delete your own location records",
                status_code=status.HTTP_403_FORBIDDEN
            )
        
        location.delete()
        
        return ApiResponse.success(
            message="Location record deleted successfully"
        )
        
    except EmployeeLocation.DoesNotExist:
        return ApiResponse.not_found("Location record not found")
    except Exception as e:
        return ApiResponse.error(
            message=f"Failed to delete location record: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Test push notification with device token",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'device_token',
            openapi.IN_QUERY,
            description="Device token for push notification",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'title',
            openapi.IN_QUERY,
            description="Notification title (optional)",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'body',
            openapi.IN_QUERY,
            description="Notification body (optional)",
            type=openapi.TYPE_STRING,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Notification sent successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Test notification sent successfully",
                    "success": True,
                    "data": {
                        "device_token": "device_token_here",
                        "title": "Test Notification",
                        "body": "This is a test notification",
                        "sent_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Invalid device token or notification data"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        500: openapi.Response(description="Failed to send notification")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def test_push_notification(request):
    """
    Test push notification with device token
    This endpoint is for testing purposes only
    """
    try:
        # Get device token from query parameters
        device_token = request.GET.get('device_token')
        if not device_token:
            return ApiResponse.error(
                message="Device token is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Get notification content from query parameters
        title = request.GET.get('title', 'Test Notification')
        body = request.GET.get('body', 'This is a test notification from DigitalHR')
        
        # Import notification utilities
        
        # Send the notification
        success, message = notification_service.send_notification_to_tokens(
            tokens=[device_token],
            title=title,
            body=body,
            data={
                'type': 'get_location',
                'timestamp': str(timezone.now()),
            }
        )
        
        if success:
            return ApiResponse.success(
                data={
                    'device_token': device_token,
                    'title': title,
                    'body': body,
                    'sent_at': timezone.now(),
                    'message': message
                },
                message="Test notification sent successfully"
            )
        else:
            return ApiResponse.error(
                message=f"Failed to send notification: {message}",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
            
    except Exception as e:
        return ApiResponse.error(
            message=f"Error sending test notification: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@swagger_auto_schema(
    method='get',
    operation_description="Test push notification with device token",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'device_token',
            openapi.IN_QUERY,
            description="Device token for push notification",
            type=openapi.TYPE_STRING,
            required=True
        ),
        openapi.Parameter(
            'title',
            openapi.IN_QUERY,
            description="Notification title (optional)",
            type=openapi.TYPE_STRING,
            required=False
        ),
        openapi.Parameter(
            'body',
            openapi.IN_QUERY,
            description="Notification body (optional)",
            type=openapi.TYPE_STRING,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="Notification sent successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Test notification sent successfully",
                    "success": True,
                    "data": {
                        "device_token": "device_token_here",
                        "title": "Test Notification",
                        "body": "This is a test notification",
                        "sent_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        ),
        400: openapi.Response(description="Invalid device token or notification data"),
        401: openapi.Response(description="Authentication credentials were not provided"),
        500: openapi.Response(description="Failed to send notification")
    }
)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def test_force_clockout(request):
    """
    Test push notification with device token
    This endpoint is for testing purposes only
    """
    try:
        # Get device token from query parameters
        device_token = request.GET.get('device_token')
        if not device_token:
            return ApiResponse.error(
                message="Device token is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Get notification content from query parameters
        title = request.GET.get('title', 'Test Notification')
        body = request.GET.get('body', 'This is a test notification from DigitalHR')
        
        # Send the notification
        success, message = notification_service.send_notification_to_tokens(
            tokens=[device_token],
            title=title,
            body=body,
            data={
                'type': 'force_clockout',
                'timestamp': str(timezone.now()),
            }
        )
        
        if success:
            return ApiResponse.success(
                data={
                    'device_token': device_token,
                    'title': title,
                    'body': body,
                    'sent_at': timezone.now(),
                    'message': message
                },
                message="Test notification sent successfully"
            )
        else:
            return ApiResponse.error(
                message=f"Failed to send notification: {message}",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
            
    except Exception as e:
        return ApiResponse.error(
            message=f"Error sending test notification: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='get',
    operation_description="Get all employees whose birthday is today",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="JWT token in format: Bearer <token>",
            type=openapi.TYPE_STRING,
            required=False
        )
    ],
    responses={
        200: openapi.Response(
            description="List of employees with birthday today",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Employees with birthday today retrieved successfully",
                    "success": True,
                    "data": {
                        "count": 2,
                        "employees": [
                            {
                                "id": 1,
                                "employee_id": "SCI20240001",
                                "full_name": "John Doe",
                                "email": "john.doe@sciverse.co.in",
                                "date_of_birth": "1990-03-20",
                                "department": "Engineering",
                                "designation": "Software Engineer",
                                "profile_photo_url": "https://example.com/photo.jpg"
                            }
                        ]
                    }
                }
            }
        ),
        401: openapi.Response(
            description="Authentication required",
            examples={
                "application/json": {
                    "code": 401,
                    "message": "Authentication credentials were not provided",
                    "success": False
                }
            }
        )
    }
)
@api_view(['GET'])
@permission_classes([AllowAny])
def get_birthday_employees(request):
    """
    Get all employees whose birthday is today
    
    This endpoint returns a list of all employees who have their birthday on the current date.
    The comparison is done by matching the day and month of the date_of_birth field.
    """
    try:
        today = timezone.now().date()
        
        # Filter employees whose birthday is today (day and month match)
        birthday_employees = Employee.objects.filter(
            date_of_birth__day=today.day,
            date_of_birth__month=today.month,
            user__active=True
        ).select_related('user')
        
        # Serialize the data
        birthday_templates = {
            "template_1": "A very happy birthday to {} 🎉✨. Sciverse wishes you all the very best!",
            "template_2": "Wishing the happiest of birthdays to {} 🥳🎂. May your year be filled with joy and success!",
            "template_3": "Happy birthday, {}! 🎈🎁 Sciverse is grateful for your presence and contributions.",
            "template_4": "Sending birthday cheers to {} 🎊🎉. May this day mark the start of a fantastic journey!",
            "template_5": "Here’s to a joyful birthday, {} 🍰🌟. Your dedication lights up our workplace!",
            "template_6": "Many happy returns to {} 🎂🎉. May your year be as inspiring as you are!",
            "template_7": "Warmest birthday wishes to {} 🌸🎁. We’re proud to have you on the Sciverse team!",
            "template_8": "It’s celebration time for {} 🎊💫. May happiness and success follow you always!",
            "template_9": "Wishing you a fantastic birthday, {} ✨🎂. Keep shining and thriving!",
            "template_10": "Happy Birthday, {} 🎉🌟. May this year bring you closer to your dreams!"
        }
        employee_data = []
        for employee in birthday_employees:
            content = random.choice(list(birthday_templates.values())).format(employee.full_name)
            announcement_data = {
                "title": "Birthday Wishes 🎉🎂🥳",
                "content": content,
                "priority": "Low",
                "start_date": timezone.now().isoformat(),
                "end_date": (timezone.now().replace(hour=23, minute=59, second=59, microsecond=999999)).isoformat(),
                "is_active": True,
                "scheduled_time": timezone.now().isoformat()
                }
            serializer = AnnouncementSerializer(data=announcement_data, context={'request': request})
            print(serializer)
            if serializer.is_valid():
                # pass
                serializer.save()
            else:
                logging.error(f"Error creating announcement: {serializer.errors}")
            
            try:
                notification_service = NotificationService()
                
                # Prepare notification data
                notification_title = f"{serializer.data['title']}"
                notification_body = serializer.data['content'][:100] + "..." if len(serializer.data['content']) > 100 else serializer.data['content']
                
                # Additional data for the notification
                notification_data = {
                    'type': 'announcement',
                    # 'announcement_id': str(serializer.data['id']),
                    'title': serializer.data['title'],
                    # 'created_by': serializer.data['created_by'].email,
                    # 'scheduled_time': serializer.data['scheduled_time'].isoformat() if serializer.data['scheduled_time'] else '',
                }
                
                # Send notification to all users
                success, message = notification_service.send_notification_to_all_users(
                    title=notification_title,
                    body=notification_body,
                    data=notification_data
                )
                
                if success:
                    logging.info(f"Notification sent successfully for announcement {serializer.data['id']}: {message}")
                else:
                    logging.warning(f"Failed to send notification for announcement {serializer.data['id']}: {message}")
                    
            except Exception as e:
                logging.error(f"Error sending notification for announcement {serializer.data['id']}: {str(e)}")
        
            employee_data.append({
                'id': employee.id,
                'employee_id': employee.employee_id,
                'full_name': employee.full_name,
                'email': employee.email,
                'date_of_birth': employee.date_of_birth,
                'department': employee.department,
                'designation': employee.designation,
                'profile_photo_url': employee.profile_photo_url,
                'mobile_number': employee.mobile_number,
                'age': today.year - employee.date_of_birth.year if employee.date_of_birth else None
            })
        
        response_data = {
            'count': len(employee_data),
            'employees': employee_data,
            'today_date': str(today)
        }
        
        return ApiResponse.success(
            data=response_data,
            message=f"Found {len(employee_data)} employee(s) with birthday today"
        )
        
    except Exception as e:
        logging.error(f"Error fetching birthday employees: {str(e)}")
        return ApiResponse.error(
            message="Error fetching birthday employees",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
