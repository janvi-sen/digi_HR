"""
Constants used throughout the application
"""

# Example email for documentation
EXAMPLE_EMAIL = "pooja.molawade@sciverse.co.in"

# Document types
DOCUMENT_TYPES = [
    'PAN_Card',
    'Aadhar_Card',
    '10th_Certificate',
    '12th_Certificate',
    'Graduation_Certificate',
    'Latest_Experience_Letter',
    'Past_Company_Salary_Slip',
    'Resume',
    'ID_Proof',
    'Address_Proof',
    'Education_Certificate',
    'Experience_Letter',
    'Offer_Letter',
    'Contract',
    'Passport',
    'Other'
]

# File size limits (in bytes)
MAX_DOCUMENT_SIZE = 10 * 1024 * 1024  # 10MB
MAX_PROFILE_PHOTO_SIZE = 5 * 1024 * 1024  # 5MB

# Allowed file types
ALLOWED_DOCUMENT_TYPES = ['.pdf', '.jpg', '.jpeg']
ALLOWED_PROFILE_PHOTO_TYPES = ['.jpg', '.jpeg', '.png', '.gif'] 