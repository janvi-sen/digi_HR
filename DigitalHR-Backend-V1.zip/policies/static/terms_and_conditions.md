Welcome to **DigiHR**, the official human resources management application developed by **Sciverse Medtech Pvt. Ltd.** By accessing or using the DigiHR mobile application, you agree to be bound by the following Terms and Conditions. Please read them carefully.

If you do not agree with these Terms, you may not use the App.

---

## 1. Purpose of the Application

DigiHR is an internal application designed and developed by Sciverse to digitize and streamline human resource processes. Key functionalities include:

- Employee Clock-In and Clock-Out  
- Attendance tracking  
- Leave application and approval  
- Access and update to personal employee records  
- Centralized HR communications  

This application is intended for **authorized Sciverse employees only** and is not meant for public or commercial distribution.

---

## 2. Eligibility and Access

Only current employees of Sciverse Medtech Pvt. Ltd. who are granted access credentials are permitted to use this App. Unauthorized use or access is strictly prohibited and may result in disciplinary action or legal proceedings.

---

## 3. User Responsibilities

By using the App, you agree to:

- Maintain the confidentiality of your login credentials  
- Provide accurate and updated information in your employee profile  
- Use the app only for legitimate HR-related purposes  
- Adhere to Sciverse’s internal policies while using the app  
- Not misuse any feature for falsifying attendance, leave records, or any other information  

Any misuse, fraudulent behavior, or breach of these responsibilities may result in immediate suspension of access and disciplinary action.

---

## 4. Data Collection and Usage

DigiHR collects and stores information related to employee attendance, leave records, personal details, and activity logs. This data is used solely for HR operations and internal analytics.

We do not sell or share your personal data with third parties outside of Sciverse unless required by law.

Refer to our **[Privacy Policy]** for detailed information on data handling.

---

## 5. Clock-In/Clock-Out and Attendance Tracking

You are responsible for accurately clocking in and out each working day. Tampering with timestamps or using another user’s credentials to record attendance is strictly prohibited and may lead to disciplinary action.

In case of technical issues, employees are advised to immediately notify the HR team to ensure attendance is not affected.

---

## 6. Leave Requests and Approvals

All leave requests must be submitted through DigiHR. Approval or rejection will be managed by designated reporting managers or the HR department as per internal leave policies.

Leave balances and histories can be viewed by employees within the App. Misrepresentation of leave details may lead to consequences as per company policy.

---

## 7. Intellectual Property Rights

All content, code, logos, designs, features, and functionalities of DigiHR are the exclusive property of **Sciverse Medtech Pvt. Ltd.** Unauthorized reproduction, distribution, or reverse engineering of the application is strictly prohibited.

---

## 8. Modification or Termination of Services

Sciverse reserves the right to modify, suspend, or terminate any feature or the entire application at any time, with or without notice, for system upgrades, maintenance, or organizational restructuring.

---

## 9. Limitation of Liability

While every effort is made to maintain accuracy and uptime of the App, Sciverse is not liable for:

- Temporary unavailability or downtime  
- Data loss due to unforeseen technical issues  
- Employee grievances arising from improper use of the App  

Users are advised to regularly sync and back up critical information, and promptly report any issues to HR or IT support.

---

## 10. Disciplinary Measures for Non-Compliance

Failure to comply with the Terms & Conditions may result in:

- Suspension or revocation of access  
- HR warnings or disciplinary notices  
- Termination of employment in severe cases  
- Legal action, if deemed necessary by the organization

---

## 11. Amendments to Terms

Sciverse may update or revise these Terms from time to time. Employees will be notified of any changes via in-app notifications or official email. Continued use of the App after such updates constitutes acceptance of the revised Terms.

---

## 12. Governing Law

These Terms are governed by the laws of the **Republic of India**. Any disputes arising out of or related to the use of DigiHR shall be subject to the jurisdiction of the courts in **[Insert Jurisdiction, e.g., Pune, Maharashtra]**.

---

## 13. Contact Information

For any concerns, queries, or feedback regarding the DigiHR Application or these Terms, please contact:

**Human Resources Department**  
Sciverse Medtech Pvt. Ltd.  
V18, Balewadi High Street, Pune - 45  
Email: [hr@sciverse.co.in](mailto:hr@sciverse.co.in)  
Phone: 98765432
