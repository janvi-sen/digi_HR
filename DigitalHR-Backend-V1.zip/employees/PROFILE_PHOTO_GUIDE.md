# Employee Profile Photo Guide

## Overview

The Employee model now supports profile photos through two flexible approaches:

1. **Direct file upload** to the Django application
2. **External URL** for images stored in cloud services (S3, CDN, etc.)

## Fields

### 1. `profile_photo` (ImageField)

- Direct file upload to the Django server
- Upload path: `media/employee_profiles/{employee_id}/profile_{employee_id}.{ext}`
- Max file size: 5MB
- Allowed formats: JPG, JPEG, PNG, GIF
- Validated for file size and format

### 2. `profile_photo_url` (URLField)

- External URL for profile photos stored in cloud services
- Max length: 500 characters
- No file size validation (relies on external service)
- Examples:
  - `https://s3.amazonaws.com/bucket/photos/employee_1.jpg`
  - `https://cdn.example.com/profiles/emp123.png`
  - `https://storage.googleapis.com/bucket/photos/profile.jpg`

### 3. `profile_photo_display_url` (Property)

- **Read-only** computed field
- **Priority**: `profile_photo_url` > `profile_photo`
- Returns the URL that should be used for displaying the profile photo
- Returns `None` if no photo is available

## API Endpoints

### 1. Upload/Update Profile Photo

```
POST /api/employees/{id}/profile-photo/
```

**Supports multiple approaches:**

#### A. Direct File Upload

```bash
curl -X POST \
  http://localhost:8000/api/employees/1/profile-photo/ \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: multipart/form-data" \
  -F "profile_photo=@/path/to/photo.jpg"
```

#### B. External URL

```bash
curl -X POST \
  http://localhost:8000/api/employees/1/profile-photo/ \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "profile_photo_url": "https://s3.amazonaws.com/bucket/photos/employee_1.jpg"
  }'
```

#### C. Both (URL takes priority)

```bash
curl -X POST \
  http://localhost:8000/api/employees/1/profile-photo/ \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: multipart/form-data" \
  -F "profile_photo=@/path/to/photo.jpg" \
  -F "profile_photo_url=https://s3.amazonaws.com/bucket/photos/employee_1.jpg"
```

### 2. Update via Employee Update Endpoint

```
PUT /api/employees/{id}/update/
```

Profile photo fields are included in regular employee updates:

```json
{
  "full_name": "John Doe",
  "profile_photo_url": "https://s3.amazonaws.com/bucket/photos/john.jpg"
}
```

### 3. Get Employee with Profile Photo

```
GET /api/employees/{id}/
```

Response includes all profile photo fields:

```json
{
  "id": 1,
  "employee_id": "SCI20240001",
  "full_name": "John Doe",
  "profile_photo": "/media/employee_profiles/SCI20240001/profile_SCI20240001.jpg",
  "profile_photo_url": "https://s3.amazonaws.com/bucket/photos/john.jpg",
  "profile_photo_display_url": "https://s3.amazonaws.com/bucket/photos/john.jpg"
}
```

## Use Cases

### 1. Small Organizations (Direct Upload)

- Upload photos directly to Django server
- Simple setup, no external dependencies
- Files stored in `media/employee_profiles/`

### 2. Large Organizations (Cloud Storage)

- Upload photos to S3, Google Cloud Storage, etc.
- Set `profile_photo_url` to the cloud URL
- Better performance and scalability
- CDN integration for faster loading

### 3. Hybrid Approach

- Upload file as backup
- Set external URL for primary display
- Fallback mechanism if external URL fails

## Priority Logic

The `profile_photo_display_url` property follows this priority:

1. **`profile_photo_url`** (if set) - External URL takes precedence
2. **`profile_photo.url`** (if uploaded) - Local file as fallback
3. **`None`** - No photo available

## Frontend Integration

### Displaying Profile Photos

```javascript
// Get the display URL for showing in UI
const profilePhotoUrl = employee.profile_photo_display_url;

if (profilePhotoUrl) {
    // Show profile photo
    imageElement.src = profilePhotoUrl;
} else {
    // Show default avatar
    imageElement.src = '/static/default-avatar.png';
}
```

### Upload Form

```html
<!-- Direct file upload -->
<form enctype="multipart/form-data">
    <input type="file" name="profile_photo" accept="image/*" />
    <button type="submit">Upload Photo</button>
</form>

<!-- External URL -->
<form>
    <input type="url" name="profile_photo_url" placeholder="https://..." />
    <button type="submit">Set Photo URL</button>
</form>
```

## File Management

### Local Storage

- Files stored in: `{MEDIA_ROOT}/employee_profiles/{employee_id}/`
- Filename format: `profile_{employee_id}.{extension}`
- Automatic directory creation
- File overwrite on new uploads

### Cloud Storage Integration

For production environments, consider:

- AWS S3 with `django-storages`
- Google Cloud Storage
- Azure Blob Storage
- Cloudinary for image processing

## Validation

### File Upload Validation

- **Size limit**: 5MB maximum
- **Format check**: JPG, JPEG, PNG, GIF only
- **File integrity**: Basic file validation

### URL Validation

- **Format check**: Valid URL format
- **Length limit**: 500 characters maximum
- **No content validation**: Assumes external URLs are valid

## Security Considerations

1. **File uploads** are validated for size and format
2. **Upload directory** is isolated per employee
3. **External URLs** are not validated for content (trust external service)
4. **Media serving** is configured for development only

## Migration

The profile photo fields have been added as nullable fields, so existing employees will have:

- `profile_photo`: `null`
- `profile_photo_url`: `null`
- `profile_photo_display_url`: `null`

No data migration is required.
