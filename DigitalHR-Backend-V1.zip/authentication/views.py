from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from rest_framework_simplejwt.tokens import RefreshToken
from utils import constants # type: ignore
from .serializers import UserRegistrationSerializer, UserLoginSerializer, OTPGenerateSerializer, OTPVerifySerializer, PasswordResetSerializer
from utils.general_utils import ApiResponse, JWTUtils
from .models import User
from employees.models import Employee
# Basic email validation
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from utils.general_utils import EmailDomainValidator

# Create your views here.

def get_tokens_for_user(user):
    """
    Generate JWT tokens for a user
    """
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

@swagger_auto_schema(
    method='post',
    operation_description="Register a new user with email and password. If user exists but is not registered, will complete their registration.",
    request_body=UserRegistrationSerializer,
    responses={
        201: openapi.Response(
            description="User registered successfully",
            examples={
                "application/json": {
                    "code": 201,
                    "message": "User registered successfully",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "verified": False,
                        "active": True,
                        "is_onboarded": False,
                        "is_verified": False,
                        "is_registered": True,
                        "tokens": {
                            "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
                            "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
                        }
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation error",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "User with this email is already registered.",
                        "Password: This field is required."
                    ]
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    """
    Register a new user with email_id and password
    
    This endpoint creates a new user account with the provided email and password.
    The user will be created with verified=False and active=True by default.
    """
    serializer = UserRegistrationSerializer(data=request.data)
    
    if serializer.is_valid():
        user = serializer.save()
        tokens = get_tokens_for_user(user)
        user_data = {
            'email_id': user.email_id,
            'active': user.active,
            'is_onboarded': user.is_onboarded,
            'is_verified': user.is_verified,
            'tokens': tokens,
            
        }
        return ApiResponse.created(
            data=user_data,
            message="User registered successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='post',
    operation_description="Login user with email and password",
    request_body=UserLoginSerializer,
    responses={
        200: openapi.Response(
            description="Login successful",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Login successful",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "is_verified": False,
                        "active": True,
                        "last_login": "2024-01-15T14:30:25.123456+05:30",
                        "tokens": {
                            "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
                            "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
                        }
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Login failed",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "Invalid email or password."
                    ]
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    """
    Login user with email_id and password
    
    This endpoint authenticates a user with their email and password.
    Returns user data and JWT tokens if authentication is successful.
    """
    serializer = UserLoginSerializer(data=request.data)
    
    if serializer.is_valid():
        user = serializer.validated_data['user']
        
        # Update last_login timestamp
        user.last_login = timezone.now()
        user.device_token = request.data["device_token"]
        user.save(update_fields=['last_login', 'device_token'])
        
        # Generate JWT tokens
        tokens = get_tokens_for_user(user)
        # Get employee ID if exists
        try:
            employee = Employee.objects.filter(user=user).first()
            e_id = employee.id if employee else None
            employee.last_login = timezone.now()
            employee.save(update_fields=['last_login'])
        except:
            e_id = None
        
        user_data = {
            'email_id': user.email_id,
            'active': user.active,
            'last_login': user.last_login,
            'tokens': tokens,
            'is_onboarded': user.is_onboarded,
            'is_verified': user.is_verified,
            'id': e_id,
            'is_hr_manager': employee.is_hr_manager if e_id else False
        }
        return ApiResponse.success(
            data=user_data,
            message="Login successful"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='post',
    operation_description="Generate and send OTP to user's email for login or password reset",
    request_body=OTPGenerateSerializer,
    responses={
        200: openapi.Response(
            description="OTP generated successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Login OTP sent successfully",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "otp_type": "login",
                        "expires_at": "2024-01-15T14:40:25.123456+05:30",
                        "valid_for": "10 minutes"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation error",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "User with this email does not exist."
                    ]
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def send_otp(request):
    """
    Generate and send OTP to user's email for login or password reset
    
    This endpoint generates a 6-digit OTP and sends it to the user's email.
    OTP type can be 'login' or 'password_reset'.
    OTP is valid for 10 minutes. Previous unused OTPs of the same type are marked as used.
    """
    serializer = OTPGenerateSerializer(data=request.data)
    
    if serializer.is_valid():
        otp_data = serializer.save()
        
        otp_type_display = otp_data['otp_type'].replace('_', ' ').title()
        email_sent = otp_data.get('email_sent', False)
        
        response_data = {
            'email_id': otp_data['email_id'],
            'otp_type': otp_data['otp_type'],
            'expires_at': otp_data['expires_at'],
            'valid_for': '10 minutes',
            'email_sent': email_sent
        }
        
        # Determine message based on email send status
        if email_sent:
            message = f"{otp_type_display} OTP sent successfully to your email"
        else:
            message = f"{otp_type_display} OTP generated but email could not be sent"
        
        # In debug mode, include the OTP in response
        if request.data.get('debug', False):
            response_data['otp'] = otp_data['otp']
            response_data['debug_note'] = "OTP included for debugging purposes only"
        
        return ApiResponse.success(
            data=response_data,
            message=message
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='post',
    operation_description="Verify OTP for login or password reset",
    request_body=OTPVerifySerializer,
    responses={
        200: openapi.Response(
            description="OTP verified successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Login OTP verified successfully",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "otp_type": "login",
                        "is_verified": True,
                        "otp_verified_at": "2024-01-15T14:35:25.123456+05:30",
                        "tokens": {
                            "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
                            "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
                        }
                    }
                }
            }
        ),
        400: openapi.Response(
            description="OTP verification failed",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "Invalid or expired login OTP."
                    ]
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def verify_otp(request):
    """
    Verify OTP for login or password reset
    
    This endpoint verifies the provided OTP against the user's email for the specified type.
    OTP must be valid and not expired (within 10 minutes).
    For login OTP, JWT tokens are returned upon successful verification.
    """
    serializer = OTPVerifySerializer(data=request.data)
    
    if serializer.is_valid():
        user = serializer.validated_data['user']
        otp_instance = serializer.validated_data['otp_instance']
        otp_type = otp_instance.otp_type
        
        otp_type_display = otp_type.replace('_', ' ').title()
        
        # For login OTP, update last_login and generate tokens
        # if otp_type == 'login':
            # user.last_login = timezone.now()
            # user.save(update_fields=['last_login'])
        
        response_data = {
            'email_id': user.email_id,
            'otp_type': otp_type,
            'is_verified': user.is_verified,
            'is_registered': user.is_registered,
            'is_active': user.is_active,
            'otp_verified_at': timezone.now()
        }
        
        # Add tokens and last_login for login OTP
        if otp_type == 'login':
            response_data['last_login'] = user.last_login
            response_data['tokens'] = get_tokens_for_user(user)
        
        return ApiResponse.success(
            data=response_data,
            message=f"{otp_type_display} OTP verified successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='post',
    operation_description="Reset password after OTP verification",
    request_body=PasswordResetSerializer,
    responses={
        200: openapi.Response(
            description="Password reset successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Password reset successfully",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "password_reset_at": "2024-01-15T14:35:25.123456+05:30"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Password reset failed",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "Passwords do not match."
                    ]
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def reset_password(request):
    """
    Reset password after OTP verification
    
    This endpoint allows users to reset their password.
    Note: In a secure implementation, this should require a valid password reset OTP session.
    """
    serializer = PasswordResetSerializer(data=request.data)
    
    if serializer.is_valid():
        email_id = serializer.validated_data['email_id']
        new_password = serializer.validated_data['new_password']
        
        try:
            user = User.objects.get(email_id=email_id)
        except User.DoesNotExist:
            return ApiResponse.error(
                message="User not found",
                status_code=status.HTTP_404_NOT_FOUND
            )
        
        # Hash and update password
        user.password = make_password(new_password)
        user.save(update_fields=['password'])
        
        response_data = {
            'email_id': user.email_id,
            'password_reset_at': timezone.now()
        }
        
        return ApiResponse.success(
            data=response_data,
            message="Password reset successfully"
        )
    
    return ApiResponse.validation_error(serializer.errors)

@swagger_auto_schema(
    method='post',
    operation_description="Refresh JWT access token",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'refresh': openapi.Schema(type=openapi.TYPE_STRING, description='Refresh token')
        },
        required=['refresh']
    ),
    responses={
        200: openapi.Response(
            description="Token refreshed successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Token refreshed successfully",
                    "success": True,
                    "data": {
                        "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Token refresh failed",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Invalid or expired refresh token",
                    "success": False
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def refresh_token(request):
    """
    Refresh JWT access token using refresh token
    
    This endpoint allows users to get a new access token using their refresh token.
    """
    refresh_token = request.data.get('refresh')
    
    if not refresh_token:
        return ApiResponse.error(
            message="Refresh token is required",
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    new_access_token, error = JWTUtils.refresh_access_token(refresh_token)
    
    if error:
        return ApiResponse.error(
            message=error,
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    return ApiResponse.success(
        data={'access': new_access_token},
        message="Token refreshed successfully"
    )

@swagger_auto_schema(
    method='post',
    operation_description="Check if a user exists with the given email",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'email_id': openapi.Schema(
                type=openapi.TYPE_STRING,
                description='Email address to check',
                format=openapi.FORMAT_EMAIL
            )
        },
        required=['email_id']
    ),
    responses={
        200: openapi.Response(
            description="User existence check completed",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "User existence check completed",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "exists": True,
                        "is_verified": True,
                        "active": True,
                        "is_onboarded": False,
                        "created_at": "2024-01-15T10:00:00.000000+05:30"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation error",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "Email Id: This field is required.",
                        "Email Id: Enter a valid email address."
                    ]
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def check_user_exists(request):
    """
    Check if a user exists with the given email
    
    This endpoint checks if a user exists in the system with the provided email.
    Returns user existence status along with basic user information if found.
    
    Useful for:
    - Frontend validation before registration
    - Checking if user exists before sending OTP
    - Onboarding process validation
    """
    email_id = request.data.get('email_id', '')
    
    if not email_id:
        return ApiResponse.validation_error({'email_id': ['This field is required.']})
    

    
    try:
        validate_email(email_id)
    except ValidationError:
        return ApiResponse.validation_error({'email_id': ['Enter a valid email address.']})
    
    # Validate email domain if restriction is enabled
    is_valid_domain, domain_error = EmailDomainValidator.validate_email_domain(email_id)
    if not is_valid_domain:
        return ApiResponse.validation_error({'email_id': [domain_error]})
    
    try:
        user = User.objects.get(email_id=email_id)
        
        try:
            employee = Employee.objects.get(user=user)
        except Employee.DoesNotExist:
            employee = None
        if not employee:
            is_hr_manager = False
        else:
            is_hr_manager = employee.is_hr_manager
        # User exists, return user information
        user_data = {
            'email_id': user.email_id,
            'exists': True,
            'is_verified': user.is_verified,
            'active': user.active,
            'is_onboarded': user.is_onboarded,
            'created_at': user.created_at,
            'is_registered': user.is_registered,
            'is_hr_manager': is_hr_manager
        }
        
        return ApiResponse.success(
            data=user_data,
            message="User existence check completed"
        )
        
    except User.DoesNotExist:
        # User does not exist
        user_data = {
            'email_id': email_id,
            'exists': False,
            'is_verified': None,
            'active': False,
            'is_onboarded': False,
            'created_at': None,
            'is_registered': False
        }
        
        return ApiResponse.success(
            data=user_data,
            message="User existence check completed"
        )

@swagger_auto_schema(
    method='delete',
    operation_description="Completely delete a user and all associated data",
    request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'email_id': openapi.Schema(
                type=openapi.TYPE_STRING,
                description='Email address of user to delete',
                format=openapi.FORMAT_EMAIL
            )
        },
        required=['email_id']
    ),
    responses={
        200: openapi.Response(
            description="User and associated data deleted successfully",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "User and all associated data deleted successfully",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "deleted_records": {
                            "user": True,
                            "employee": True,
                            "otp_records": 3
                        }
                    }
                }
            }
        ),
        403: openapi.Response(
            description="Permission denied",
            examples={
                "application/json": {
                    "code": 403,
                    "message": "Admin access required",
                    "success": False
                }
            }
        ),
        404: openapi.Response(
            description="User not found"
        )
    }
)
@api_view(['DELETE'])
@permission_classes([AllowAny])
def admin_delete_user_complete(request):
    """
    Admin-only endpoint to completely delete a user and all associated data
    
    This endpoint performs a complete deletion of:
    - User account
    - Associated Employee record (if exists)
    - All related OTP records (deleted automatically via CASCADE)
    
    WARNING: This is a permanent deletion and cannot be undone.
    Requires admin privileges.
    """
    # Check if user is admin/staff
    # if not (request.user.is_staff or request.user.is_superuser):
    #     return ApiResponse.error(
    #         message="Admin access required",
    #         status_code=status.HTTP_403_FORBIDDEN
    #     )
    
    email_id = request.data.get('email_id', '')
    
    if not email_id:
        return ApiResponse.validation_error({'email_id': ['This field is required.']})
    
    # Basic email validation
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    
    try:
        validate_email(email_id)
    except ValidationError:
        return ApiResponse.validation_error({'email_id': ['Enter a valid email address.']})
    
    try:
        user = User.objects.get(email_id=email_id)
    except User.DoesNotExist:
        return ApiResponse.not_found("User not found")
    
    # Check if user has an associated employee record
    employee_exists = False
    employee_id = None
    try:
        employee = Employee.objects.get(user=user)
        employee_exists = True
        employee_id = employee.employee_id
    except Employee.DoesNotExist:
        employee_exists = False
    
    # Count OTP records before deletion
    from authentication.models import OTP
    otp_count = OTP.objects.filter(email_id=user).count()
    
    try:
        # Delete employee first if exists
        if employee_exists:
            employee.delete()
        
        # Delete user (this will automatically delete OTP records via CASCADE)
        user.delete()
        
        response_data = {
            'email_id': email_id,
            'employee_id': employee_id,
            'deleted_records': {
                'user': True,
                'employee': employee_exists,
                'otp_records': otp_count
            }
        }
        
        return ApiResponse.success(
            data=response_data,
            message="User and all associated data deleted successfully"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"Error during deletion: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@swagger_auto_schema(
    method='post',
    operation_description="Logout user by clearing device token",
    manual_parameters=[
        openapi.Parameter(
            'Authorization',
            openapi.IN_HEADER,
            description="Bearer token for authentication",
            type=openapi.TYPE_STRING,
            required=True
        )
    ],
    responses={
        200: openapi.Response(
            description="Logout successful",
            examples={
                "application/json": {
                    "code": 200,
                    "message": "Logout successful",
                    "success": True,
                    "data": {
                        "email_id": constants.EXAMPLE_EMAIL,
                        "device_token_cleared": True,
                        "logout_at": "2024-01-15T14:35:25.123456+05:30"
                    }
                }
            }
        ),
        400: openapi.Response(
            description="Validation error",
            examples={
                "application/json": {
                    "code": 400,
                    "message": "Validation failed",
                    "success": False,
                    "errors": [
                        "Email Id: This field is required."
                    ]
                }
            }
        ),
        401: openapi.Response(
            description="Authentication failed",
            examples={
                "application/json": {
                    "code": 401,
                    "message": "Authentication credentials were not provided or invalid",
                    "success": False
                }
            }
        ),
        404: openapi.Response(
            description="User not found",
            examples={
                "application/json": {
                    "code": 404,
                    "message": "User not found",
                    "success": False
                }
            }
        )
    }
)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def logout(request):
    """
    Logout user by clearing device token
    
    This endpoint logs out a user by clearing their device token.
    Requires authentication via bearer token and email_id in request body.
    """
    try:
        # Get email_id from request body
        email_id = request.user.email_id
        if not email_id:
            return ApiResponse.error(
                message="Email ID is required",
                status_code=status.HTTP_400_BAD_REQUEST
            )
        
        # Get the user and clear device token
        try:
            user = User.objects.get(email_id=email_id)
        except User.DoesNotExist:
            return ApiResponse.error(
                message="User not found",
                status_code=status.HTTP_404_NOT_FOUND
            )
        
        # Clear the device token
        user.device_token = None
        user.save(update_fields=['device_token'])
        
        logout_data = {
            'email_id': user.email_id,
            'device_token_cleared': True,
            'logout_at': timezone.now()
        }
        
        return ApiResponse.success(
            data=logout_data,
            message="Logout successful"
        )
        
    except Exception as e:
        return ApiResponse.error(
            message=f"Error during logout: {str(e)}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )