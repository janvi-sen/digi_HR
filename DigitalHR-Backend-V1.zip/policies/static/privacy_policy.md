**Sciverse** is committed to safeguarding the privacy and personal data of all users of the **DigiHR Application**. This Privacy Policy outlines the types of information we collect, how it is used, stored, and protected, and the choices you have regarding your personal data.

By accessing or using the DigiHR App, you agree to the terms of this Privacy Policy. If you do not agree, please refrain from using the application.

---

## 1. Scope of This Policy

This Privacy Policy applies to all users of the DigiHR Application, including employees, contractors, HR managers, and administrators within Sciverse. It governs the collection, use, and disclosure of information through the DigiHR App and associated HR services.

---

## 2. Information We Collect

We collect and process both personal and usage information necessary for the functioning of the application and HR operations.

### a. Personal Information

This includes, but is not limited to:

- Full Name  
- Employee ID  
- Email Address  
- Phone Number  
- Department & Role  
- Photograph (if submitted)  
- Attendance logs (Clock-In/Clock-Out timestamps)  
- Leave applications and approval records  
- Joining and separation dates  
- Employment history and performance notes (if applicable)

### b. Device & Usage Data

- Device type and operating system  
- IP address and location (for attendance validation)  
- App usage logs and crash data  
- Login and logout timestamps

---

## 3. Purpose of Data Collection

We collect and use your information to:

- Maintain accurate employee records  
- Enable clock-in/clock-out and attendance tracking  
- Process leave requests and approvals  
- Manage HR-related workflows efficiently  
- Ensure secure and authorized access to the App  
- Comply with internal HR policies and regulatory obligations  
- Improve the performance, security, and user experience of the App

---

## 4. Data Storage and Security

All data collected via the DigiHR App is securely stored on encrypted servers managed by Sciverse or its trusted third-party cloud service providers. We implement strong technical and organizational safeguards to prevent unauthorized access, alteration, or disclosure of personal data.

**Measures include:**

- Role-based access control (RBAC)  
- End-to-end encryption during data transfer  
- Regular security audits and updates  
- Multi-factor authentication for admin users

---

## 5. Data Sharing and Disclosure

We do not sell or rent any personal data to third parties.

Your information may be shared internally with authorized HR personnel and team managers strictly for employment-related purposes. We may also share information with:

- Service providers involved in application hosting or analytics  
- Government agencies or legal entities, if required by law  
- Internal audit or compliance teams  

All third-party access is governed by strict data protection agreements.

---

## 6. Your Rights and Choices

As a user, you have the right to:

- Access and review your personal data stored in the App  
- Request correction of inaccurate or incomplete information  
- Request deletion or deactivation of your profile (as per company exit policies)  
- Opt out of non-essential notifications  
- Raise concerns or complaints regarding data handling practices  

To exercise your rights, please contact the HR team at [Insert Internal Contact Email].

---

## 7. Intellectual Property Rights

We retain your personal data only as long as necessary to fulfill the purposes outlined above or to comply with legal, regulatory, or contractual obligations. Upon resignation, termination, or account deletion, we archive your data securely for a predefined period in accordance with Sciverse’s data retention policy.

---

## 8. Third-Party Links and Services

The DigiHR App is self-contained and does not embed third-party ads or external integrations. However, links or services provided within the application (e.g., payroll system or helpdesk) may be governed by their respective privacy policies. We encourage you to review those separately.

---

## 9. Children’s Privacy

The DigiHR App is intended strictly for use by employees of Sciverse. It is not designed for or directed at children under the age of 18.

---

## 10. Changes to This Privacy Policy

We may update this Privacy Policy periodically to reflect changes in our practices or legal obligations. Any updates will be notified via the App, and your continued use after such changes constitutes your acceptance.

---

## 11. Contact Us

For any questions, feedback, or data-related concerns, please reach out to:

**Human Resource Executive**  
Sciverse Solutions Pvt. Ltd.  
V18, Balewadi High Street, Pune - 45  
Email: [hr@sciverse.co.in](mailto:hr@sciverse.co.in)  
Phone: 9876543210
